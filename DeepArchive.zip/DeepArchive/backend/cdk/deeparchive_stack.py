"""DeepArchive deployment stack: private 2-host fleet behind an ALB.

Design (cost-optimal, secure, HA):
  * ALB (public subnets, TLS-ready) is the ONLY internet entry point. Point
    Route 53 (alias) or Cloudflare (CNAME) at its DNS name.
  * ASG of 2 hosts in PRIVATE subnets (no public IP). Reachable only from the
    ALB security group -- never directly from the internet.
  * S3 GATEWAY ENDPOINT ($0) carries the FULL data workload -- releases,
    manifests, tarballs, restore reads. Bulk archival bytes never touch NAT.
  * ONE NAT gateway carries only the small egress (SSM keyless mgmt, SES/SNS
    notifications, dnf). Its data charge is ~$0 because S3 bypasses it.
  * Restores use presigned S3 URLs -> clients pull straight from S3, bypassing
    the hosts, the ALB, and NAT entirely.
  * ROLLING deploy on every `cdk deploy`: one host at a time, ALB connection
    DRAINING lets in-flight requests finish before a host is replaced. No hook.
"""
from __future__ import annotations

import os

import aws_cdk as cdk
from aws_cdk import Duration
from aws_cdk import aws_autoscaling as autoscaling
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from aws_cdk import aws_iam as iam
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_s3_deployment as s3deploy
from constructs import Construct

_SERVICES = [
    ("identity", 8001),
    ("billing", 8002),
    ("ingest", 8003),
    ("restore", 8004),
    ("metadata", 8005),
    ("gateway", 8000),
]

_GATEWAY_PORT = 8000  # default target for anything not matched by a path rule
_ASG_SIZE = 2

# Public path prefixes -> service (mirrors deeparchive/services/gateway/main.py).
# Order matters: more specific paths first (higher ALB rule priority).
# /internal/* is intentionally ABSENT -- those endpoints stay host-internal.
_PATH_ROUTES = [
    ("/v1/files/*/content", "metadata"),  # single-file get (before /v1/files)
    ("/v1/accounts/*", "identity"),
    ("/v1/orgs/*", "identity"),
    ("/scim/*", "identity"),
    ("/v1/billing/*", "billing"),
    ("/v1/packs/*", "ingest"),
    ("/v1/files", "ingest"),          # find-file lookup (?path=)
    ("/v1/files/*", "ingest"),
    ("/v1/thumbnails/*", "ingest"),
    ("/v1/catalog", "metadata"),
    ("/v1/catalog/*", "metadata"),
    ("/v1/folders", "metadata"),
    ("/v1/folders/*", "metadata"),
    ("/v1/restore/*", "restore"),
    ("/v1/restore", "restore"),
]


class DeepArchiveStack(cdk.Stack):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        data_bucket_name: str,
        certificate_arn: str | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)  # type: ignore[arg-type]

        releases = s3.Bucket(
            self,
            "ReleasesBucket",
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            versioned=True,
            removal_policy=cdk.RemovalPolicy.RETAIN,
        )

        # --- Package + upload app source (the build+publish step) -----------
        # --- Ship the BUILT ARTIFACT (a wheelhouse), not raw source ---------
        # `scripts/build.sh` must run first: it gates on tests, then builds the
        # app + all deps into cdk/artifact/ as wheels. We ship those wheels --
        # small, clean, prebuilt, reproducible. Hosts install them OFFLINE (no
        # compile, no PyPI at boot, identical across the fleet). If the artifact
        # dir is missing, synth fails loudly -> run scripts/build.sh first.
        repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        artifact_dir = os.path.join(repo_root, "cdk", "artifact")
        app_deploy = s3deploy.BucketDeployment(
            self,
            "AppSource",
            sources=[s3deploy.Source.asset(artifact_dir)],
            destination_bucket=releases,
            destination_key_prefix="releases/current",
            prune=True,
        )
        app_version = cdk.Fn.select(0, app_deploy.object_keys)

        # --- IAM instance role (keyless) ------------------------------------
        role = iam.Role(
            self,
            "InstanceRole",
            assumed_by=iam.ServicePrincipal("ec2.amazonaws.com"),
            description="DeepArchive host role: SSM + S3 + SES/SNS, no SSH keys",
        )
        role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "AmazonSSMManagedInstanceCore"
            )
        )
        releases.grant_read(role)
        data_bucket = s3.Bucket.from_bucket_name(self, "DataBucket", data_bucket_name)
        data_bucket.grant_read_write(role)
        # Remember the real data bucket so the hosts point Storage at it (this
        # activates the single-bucket region override -> fixes catalog 503).
        self._data_bucket_name = data_bucket_name
        role.add_to_policy(
            iam.PolicyStatement(
                actions=["ses:SendEmail", "ses:SendRawEmail", "sns:Publish"],
                resources=["*"],
            )
        )
        # DynamoDB: shared account/key/org/job state across hosts. Scoped to our
        # tables (and their indexes) by name prefix. Includes CreateTable so the
        # identity service can create them on first boot (idempotent).
        role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "dynamodb:CreateTable", "dynamodb:DescribeTable", "dynamodb:ListTables",
                    "dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:Query",
                    "dynamodb:UpdateItem", "dynamodb:DeleteItem", "dynamodb:BatchWriteItem",
                ],
                resources=["*"],  # ListTables needs *; others are prefix-named tables
            )
        )

        # --- VPC: public (ALB + NAT) + PRIVATE (hosts), 1 NAT, S3 endpoint --
        vpc = ec2.Vpc(
            self,
            "Vpc",
            max_azs=2,
            nat_gateways=1,  # ONE NAT (small egress only; S3 bypasses it)
            subnet_configuration=[
                ec2.SubnetConfiguration(
                    name="public", subnet_type=ec2.SubnetType.PUBLIC, cidr_mask=24
                ),
                ec2.SubnetConfiguration(
                    name="private",
                    subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS,
                    cidr_mask=24,
                ),
            ],
        )
        # THE data path: free S3 gateway endpoint. All bulk archival traffic
        # (releases, manifests, tarballs, restores) routes here, NOT through NAT.
        vpc.add_gateway_endpoint(
            "S3Endpoint", service=ec2.GatewayVpcEndpointAwsService.S3
        )

        # --- Security groups: hosts reachable ONLY from the ALB -------------
        alb_sg = ec2.SecurityGroup(
            self, "AlbSg", vpc=vpc, description="ALB: public 443 in",
            allow_all_outbound=True,
        )
        alb_sg.add_ingress_rule(ec2.Peer.any_ipv4(), ec2.Port.tcp(443), "HTTPS in")
        alb_sg.add_ingress_rule(ec2.Peer.any_ipv4(), ec2.Port.tcp(80), "HTTP in")

        host_sg = ec2.SecurityGroup(
            self, "HostSg", vpc=vpc,
            description="Hosts: private, only ALB may reach the gateway port",
            allow_all_outbound=True,
        )
        # Only the ALB may reach the gateway port. NO internet, NO SSH.
        host_sg.add_ingress_rule(
            alb_sg, ec2.Port.tcp(_GATEWAY_PORT), "gateway from ALB only"
        )
        # Hosts may reach each other's service ports (gateway peer failover).
        host_sg.add_ingress_rule(
            host_sg, ec2.Port.tcp_range(8000, 8005), "inter-host services"
        )

        # --- UserData + Launch Template + ASG (private) ---------------------
        user_data = ec2.UserData.for_linux()
        user_data.add_commands(
            *self._user_data_commands(releases.bucket_name, app_version)
        )
        # Use a LAUNCH TEMPLATE (not the deprecated LaunchConfiguration, which
        # newer AWS accounts reject). All instance config lives on the template.
        launch_template = ec2.LaunchTemplate(
            self,
            "FleetLaunchTemplate",
            instance_type=ec2.InstanceType.of(
                ec2.InstanceClass.BURSTABLE4_GRAVITON, ec2.InstanceSize.SMALL
            ),
            # t4g is arm64 (Graviton) -> MUST use an arm64 AMI, not the x86_64 default.
            machine_image=ec2.MachineImage.latest_amazon_linux2023(
                cpu_type=ec2.AmazonLinuxCpuType.ARM_64
            ),
            role=role,
            security_group=host_sg,
            user_data=user_data,
            require_imdsv2=True,  # security best practice
        )
        asg = autoscaling.AutoScalingGroup(
            self,
            "Fleet",
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(
                subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS
            ),
            launch_template=launch_template,
            min_capacity=_ASG_SIZE,
            max_capacity=_ASG_SIZE,
            desired_capacity=_ASG_SIZE,
            signals=autoscaling.Signals.wait_for_min_capacity(
                timeout=Duration.minutes(15)
            ),
            update_policy=autoscaling.UpdatePolicy.rolling_update(
                max_batch_size=1,
                min_instances_in_service=1,
                pause_time=Duration.minutes(15),
                wait_on_resource_signals=True,
            ),
        )
        cdk.Tags.of(asg).add("App", "deeparchive")

        asg_logical_id = self.get_logical_id(asg.node.default_child)  # type: ignore[arg-type]
        user_data.add_commands(
            (
                f"/opt/aws/bin/cfn-signal -e $RESULT --stack {self.stack_name} "
                f"--resource {asg_logical_id} --region {self.region} || true"
            )
        )
        asg.node.add_dependency(app_deploy)

        # --- ALB: public entry, health-checked, connection DRAINING ---------
        alb = elbv2.ApplicationLoadBalancer(
            self, "Alb", vpc=vpc, internet_facing=True, security_group=alb_sg
        )

        # One target group per service; the ASG registers on ALL of them, so
        # every host serves every service and the ALB load-balances each service
        # across BOTH hosts (this gives cross-host failover natively -- if a
        # service is unhealthy on one host, the ALB routes to the other).
        def _target_group(name: str, port: int) -> elbv2.ApplicationTargetGroup:
            tg = elbv2.ApplicationTargetGroup(
                self,
                f"Tg{name.capitalize()}",
                vpc=vpc,
                port=port,
                protocol=elbv2.ApplicationProtocol.HTTP,
                targets=[asg],
                health_check=elbv2.HealthCheck(
                    path="/v1/health",
                    healthy_http_codes="200",
                    interval=Duration.seconds(15),
                    healthy_threshold_count=2,
                    unhealthy_threshold_count=3,
                ),
                deregistration_delay=Duration.seconds(30),  # connection draining
            )
            return tg

        target_groups = {name: _target_group(name, port) for name, port in _SERVICES}

        # --- Listeners: HTTP always serves; HTTPS added when a cert exists ---
        # For now BOTH http and https serve the routes (no forced redirect) --
        # HTTP is the working fallback; add a cert to also serve HTTPS. Migrate
        # to an HTTP->HTTPS redirect later once HTTPS is verified.
        listeners: list[elbv2.ApplicationListener] = []
        listeners.append(
            alb.add_listener(
                "Http", port=80, default_target_groups=[target_groups["gateway"]]
            )
        )
        if certificate_arn:
            listeners.append(
                alb.add_listener(
                    "Https",
                    port=443,
                    certificates=[
                        elbv2.ListenerCertificate.from_arn(certificate_arn)
                    ],
                    default_target_groups=[target_groups["gateway"]],
                )
            )

        # --- Path-based routing rules applied to EVERY listener --------------
        for li, listener in enumerate(listeners):
            for i, (path, svc) in enumerate(_PATH_ROUTES):
                listener.add_action(
                    f"Route{li}_{i}",
                    priority=10 + i,  # specific paths first (list order)
                    conditions=[elbv2.ListenerCondition.path_patterns([path])],
                    action=elbv2.ListenerAction.forward([target_groups[svc]]),
                )

        cdk.CfnOutput(self, "ReleasesBucketName", value=releases.bucket_name)
        cdk.CfnOutput(self, "AsgName", value=asg.auto_scaling_group_name)
        cdk.CfnOutput(
            self,
            "AlbDnsName",
            value=alb.load_balancer_dns_name,
            description="Point Route53 (alias) or Cloudflare (CNAME) at this",
        )

    def _user_data_commands(self, releases_bucket: str, app_version: str) -> list[str]:
        return [
            "set -euxo pipefail",
            f"# app_version={app_version}",
            "dnf -y update",
            "dnf -y install python3.11 python3.11-pip tar gzip aws-cfn-bootstrap",
            "install -d -m 0755 /opt/deeparchive",
            "cat > /opt/deeparchive/deploy.sh <<'DEPLOY'",
            "#!/usr/bin/env bash",
            "set -euxo pipefail",
            f"BUCKET={releases_bucket}",
            "cd /opt/deeparchive",
            # Pull the BUILT ARTIFACT (the deeparchive wheel) uploaded by CDK.
            "rm -rf artifact && mkdir artifact",
            "aws s3 sync s3://$BUCKET/releases/current/ artifact/",
            "python3.11 -m venv venv",
            "./venv/bin/pip install --upgrade pip",
            # Install the prebuilt deeparchive wheel; its deps (fastapi, uvicorn,
            # boto3, ...) resolve from PyPI over the host's NAT egress. The app
            # itself is the tested, versioned artifact -- deps are pinned by the
            # wheel's metadata so installs are consistent.
            "./venv/bin/pip install artifact/deeparchive-*.whl",
            "systemctl daemon-reload",
            "systemctl restart deeparchive.target || true",
            "DEPLOY",
            "chmod +x /opt/deeparchive/deploy.sh",
            "cat > /etc/systemd/system/deeparchive.target <<'TARGET'",
            "[Unit]",
            "Description=DeepArchive services",
            "Wants=network-online.target",
            "After=network-online.target",
            "TARGET",
            *self._systemd_units(),
            "systemctl daemon-reload",
            *[f"systemctl enable deeparchive-{name}.service" for name, _ in _SERVICES],
            "if /opt/deeparchive/deploy.sh; then RESULT=0; else RESULT=1; fi",
        ]

    def _systemd_units(self) -> list[str]:
        lines: list[str] = []
        asgi = {
            "identity": "deeparchive.services.identity.main:app",
            "billing": "deeparchive.services.billing_svc.asgi:app",
            "ingest": "deeparchive.services.ingest_svc.asgi:app",
            "restore": "deeparchive.services.restore_svc.asgi:app",
            "metadata": "deeparchive.services.metadata_svc.asgi:app",
            "gateway": "deeparchive.services.gateway.asgi:app",
        }
        for name, port in _SERVICES:
            unit = f"/etc/systemd/system/deeparchive-{name}.service"
            lines += [
                f"cat > {unit} <<'UNIT'",
                "[Unit]",
                f"Description=DeepArchive {name}",
                "PartOf=deeparchive.target",
                "After=network-online.target",
                "[Service]",
                "Environment=DEEPARCHIVE_AUDIT_ENABLED=1",
                "Environment=DEEPARCHIVE_USE_DDB=1",
                f"Environment=DEEPARCHIVE_BUCKET={self._data_bucket_name}",
                f"Environment=DEEPARCHIVE_REGION={self.region}",
                "WorkingDirectory=/opt/deeparchive",
                # Graceful shutdown: uvicorn finishes in-flight requests on
                # SIGTERM within this window before the host is replaced.
                "TimeoutStopSec=30",
                (
                    "ExecStart=/opt/deeparchive/venv/bin/uvicorn "
                    f"{asgi[name]} --host 0.0.0.0 --port {port} "
                    "--timeout-graceful-shutdown 25"
                ),
                "Restart=always",
                "RestartSec=3",
                "[Install]",
                "WantedBy=deeparchive.target",
                "UNIT",
            ]
        return lines
