#!/usr/bin/env python3
"""CDK app for DeepArchive: a single, keyless (SSM-only) EC2 host running all
six microservices, fed releases from an S3 bucket.

Deploy:
    cd cdk && cdk deploy
Push a new release:
    aws s3 cp deeparchive-<ver>.tar.gz s3://<releases-bucket>/releases/latest.tar.gz
    aws ssm send-command --document-name AWS-RunShellScript \\
        --targets Key=tag:App,Values=deeparchive \\
        --parameters commands='/opt/deeparchive/deploy.sh'
"""
import os

import aws_cdk as cdk

from deeparchive_stack import DeepArchiveStack

app = cdk.App()
DeepArchiveStack(
    app,
    "DeepArchiveStack",
    data_bucket_name=os.environ.get("DEEPARCHIVE_BUCKET", "deep-archive-lab"),
    # HTTPS activates when an ACM cert ARN is provided (no Route53 needed):
    #   cdk deploy -c certificate_arn=arn:aws:acm:REGION:ACCT:certificate/ID
    certificate_arn=app.node.try_get_context("certificate_arn"),
    env=cdk.Environment(
        account=os.environ.get("CDK_DEFAULT_ACCOUNT"),
        region=os.environ.get("CDK_DEFAULT_REGION", "us-east-1"),
    ),
)
app.synth()
