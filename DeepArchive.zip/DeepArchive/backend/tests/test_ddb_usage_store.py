"""Tests for the DynamoDB-backed UsageMeter (shared across hosts), via moto.

The key property: an entitlement set on one "host" (store instance) is visible
on another -- the fix for purchases not sticking across the multi-host fleet.
"""
import boto3
import pytest
from moto import mock_aws

from deeparchive.billing.plans import CATALOG, Entitlement, PlanId, make_entitlement
from deeparchive.billing.usage import NoEntitlementError, QuotaExceededError
from deeparchive.persistence import DdbUsageMeter, create_tables


def _ent(account_id: str = "acc1") -> Entitlement:
    return make_entitlement(account_id, CATALOG[PlanId("individual-100-30y")])


@mock_aws
def test_entitlement_shared_across_hosts() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)

    host_a = DdbUsageMeter(resource=res)
    host_a.set_entitlement(_ent("acc1"))

    # A DIFFERENT instance (another host) sees the plan -> the bug is fixed.
    host_b = DdbUsageMeter(resource=res)
    assert host_b.remaining_quota("acc1") == 100 * 1024 ** 3


@mock_aws
def test_no_entitlement_raises() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    meter = DdbUsageMeter(resource=res)
    with pytest.raises(NoEntitlementError):
        meter.remaining_quota("ghost")


@mock_aws
def test_upload_records_and_persists() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    a = DdbUsageMeter(resource=res)
    a.set_entitlement(_ent("acc1"))
    a.check_and_record_upload("acc1", 5000)

    # Usage visible from another host, and quota reflects it.
    b = DdbUsageMeter(resource=res)
    assert b.usage("acc1").stored_bytes == 5000
    assert b.remaining_quota("acc1") == 100 * 1024 ** 3 - 5000


@mock_aws
def test_upload_over_quota_rejected() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    meter = DdbUsageMeter(resource=res)
    meter.set_entitlement(_ent("acc1"))
    with pytest.raises(QuotaExceededError):
        meter.check_and_record_upload("acc1", 200 * 1024 ** 3)


@mock_aws
def test_set_entitlement_preserves_usage() -> None:
    # Re-purchasing (new entitlement) must not wipe recorded usage.
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    meter = DdbUsageMeter(resource=res)
    meter.set_entitlement(_ent("acc1"))
    meter.check_and_record_upload("acc1", 1234)
    meter.set_entitlement(_ent("acc1"))  # renew
    assert meter.usage("acc1").stored_bytes == 1234


@mock_aws
def test_egress_and_delete() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    meter = DdbUsageMeter(resource=res)
    meter.set_entitlement(_ent("acc1"))
    meter.check_and_record_upload("acc1", 10_000)
    meter.record_egress("acc1", 500)
    meter.record_delete("acc1", 4000)
    u = meter.usage("acc1")
    assert u.stored_bytes == 6000
    assert u.egress_bytes == 500
