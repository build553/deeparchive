"""Tests for the single-bucket deployment override in region resolution."""
from deeparchive import config, regions


def test_no_override_uses_registry_bucket(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    # Default library bucket => no override => registry bucket used.
    monkeypatch.setattr(config, "BUCKET", "deep-archive-lab")
    info = regions.resolve("US")
    assert info.bucket == "deeparchive-us-east-1"


def test_override_points_all_regions_at_configured_bucket(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    # A real deployment bucket => every resolved region uses it.
    monkeypatch.setattr(config, "BUCKET", "deep-archive-lab-197446684294")
    monkeypatch.setattr(config, "REGION", "us-east-1")
    us = regions.resolve("US")
    de = regions.resolve("DE")
    assert us.bucket == "deep-archive-lab-197446684294"
    assert de.bucket == "deep-archive-lab-197446684294"
    # Residency still enforced: an unserved country still raises.
    import pytest
    with pytest.raises(regions.CountryNotServedError):
        regions.resolve("NG")
