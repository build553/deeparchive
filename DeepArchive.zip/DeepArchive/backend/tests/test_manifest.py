"""Tests for the manifest schema: JSON round-trip + illegal states rejected."""
import pytest

from deeparchive.manifest import FileEntry, Manifest, RetentionClass

_HASH = "a" * 64


def _sample_manifest() -> Manifest:
    return Manifest(
        pack_id="pack_01",
        org_id="hdfc",
        created_at="2026-09-21T11:00:00Z",
        tarball_key="data/hdfc/7y/pack-000.tar",
        tarball_sha256=_HASH,
        tarball_bytes=268435456,
        retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[
            FileEntry(
                path="statements/cust_47_jan.pdf",
                offset=0,
                length=204800,
                sha256=_HASH,
                modified="2026-01-31T00:00:00Z",
                tags={"customer_id": "47"},
            )
        ],
    )


def test_manifest_json_round_trip() -> None:
    original = _sample_manifest()
    restored = Manifest.from_json(original.to_json())
    assert restored == original


def test_retention_class_is_enum_not_string() -> None:
    with pytest.raises(ValueError):
        RetentionClass("banana")


def test_file_entry_rejects_bad_sha() -> None:
    with pytest.raises(ValueError):
        FileEntry(path="x", offset=0, length=1, sha256="tooshort", modified="t")


def test_file_entry_rejects_empty_path() -> None:
    with pytest.raises(ValueError):
        FileEntry(path="", offset=0, length=1, sha256=_HASH, modified="t")


def test_manifest_requires_at_least_one_file() -> None:
    with pytest.raises(ValueError):
        Manifest(
            pack_id="p",
            org_id="o",
            created_at="t",
            tarball_key="data/x.tar",
            tarball_sha256=_HASH,
            tarball_bytes=1,
            retention_class=RetentionClass.ONE_YEAR,
            legal_hold=False,
            files=[],
        )
