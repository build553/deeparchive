"""Tests for the DynamoDB-backed KeyStore (shared across hosts), via moto."""
import boto3
import pytest
from moto import mock_aws

from deeparchive.persistence import DdbKeyStore, create_tables
from deeparchive.services.api.auth import AuthError


@mock_aws
def test_ddb_key_store_add_and_authenticate() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)

    store = DdbKeyStore(resource=res)
    store.add_key("dak_secret", org_id="acc_123")

    # A DIFFERENT store instance (simulating another host) sees the same key.
    other = DdbKeyStore(resource=res)
    assert other.authenticate("dak_secret").org_id == "acc_123"


@mock_aws
def test_ddb_key_store_rejects_bad_keys() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbKeyStore(resource=res)

    with pytest.raises(AuthError):
        store.authenticate("nope")
    with pytest.raises(AuthError):
        store.authenticate(None)
