"""Tests for the SDK transport + client scaffold (fake HTTP, no network)."""
from typing import Any, Optional

import pytest

from deeparchive.sdk import AuthError, Client, ClientError, Config, QuotaError
from deeparchive.sdk.transport import Transport


class FakeResponse:
    def __init__(self, status_code: int, payload: Optional[dict[str, Any]] = None) -> None:
        self.status_code = status_code
        self._payload = payload or {}
        self.content = b"{}"

    def json(self) -> dict[str, Any]:
        return self._payload


class FakeHttp:
    """Records requests; returns queued responses (supports retry sequences)."""

    def __init__(self, responses: list[FakeResponse]) -> None:
        self._responses = responses
        self.calls: list[dict[str, Any]] = []

    def request(self, method, url, headers, json=None, content=None):  # type: ignore[no-untyped-def]
        self.calls.append({"method": method, "url": url, "headers": headers,
                           "json": json, "content": content})
        return self._responses[min(len(self.calls) - 1, len(self._responses) - 1)]


def _transport(responses: list[FakeResponse]) -> tuple[Transport, FakeHttp]:
    http = FakeHttp(responses)
    return Transport("dak_key", Config(endpoint="https://api.test"), http), http


def test_sends_bearer_auth_header() -> None:
    t, http = _transport([FakeResponse(200, {"ok": True})])
    t.call("GET", "/v1/health")
    assert http.calls[0]["headers"]["Authorization"] == "Bearer dak_key"


def test_401_maps_to_auth_error() -> None:
    t, _ = _transport([FakeResponse(401, {"detail": "invalid API key"})])
    with pytest.raises(AuthError):
        t.call("GET", "/v1/accounts/me")


def test_402_maps_to_quota_error() -> None:
    t, _ = _transport([FakeResponse(402, {"detail": "quota exceeded"})])
    with pytest.raises(QuotaError):
        t.call("POST", "/v1/packs/complete")


def test_500_maps_to_client_error_after_retries() -> None:
    t, http = _transport([FakeResponse(500, {"detail": "boom"})])
    with pytest.raises(ClientError):
        t.call("GET", "/v1/health")
    assert len(http.calls) == 4  # 1 + 3 retries


def test_retries_then_succeeds() -> None:
    t, http = _transport([FakeResponse(503), FakeResponse(200, {"ok": True})])
    resp = t.call("GET", "/v1/health")
    assert resp.status_code == 200
    assert len(http.calls) == 2


def test_client_builds_with_country() -> None:
    c = Client(api_key="dak_x", org_id="hdfc", country="IN",
               http=FakeHttp([FakeResponse(200)]))
    assert c.country == "IN"


class RecordingHttp:
    """Fake http that records all requests and returns a presigned URL then OKs."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def request(self, method, url, headers, json=None, content=None):  # type: ignore[no-untyped-def]
        self.calls.append({"method": method, "url": url, "json": json,
                           "content": content})
        if url.endswith("/v1/packs/upload-url"):
            return FakeResponse(200, {"url": "https://s3.example/put-here?sig=x",
                                      "tarball_key": "data/hdfc/7y/p.tar"})
        return FakeResponse(200, {"status": "ok"})


def test_put_then_flush_packs_and_uploads() -> None:
    http = RecordingHttp()
    c = Client(api_key="dak_x", org_id="hdfc", country="US",
               config=Config(endpoint="https://api.test"), http=http)
    c.put("statements/jan.pdf", data=b"hello" * 1000, retention="7y")
    c.put("statements/feb.pdf", data=b"world" * 1000, retention="7y")
    n = c.flush()
    assert n == 1  # both files packed into one tarball
    methods = [(x["method"], x["url"]) for x in http.calls]
    # Flow: upload-url (POST) -> presigned PUT -> complete (POST)
    assert any(m == "POST" and u.endswith("/v1/packs/upload-url") for m, u in methods)
    assert any(m == "PUT" and u.startswith("https://s3.example") for m, u in methods)
    assert any(m == "POST" and u.endswith("/v1/packs/complete") for m, u in methods)


def test_flush_empty_is_noop() -> None:
    http = RecordingHttp()
    c = Client(api_key="dak_x", org_id="hdfc", http=http)
    assert c.flush() == 0
    assert http.calls == []


def test_context_manager_flushes_on_exit() -> None:
    http = RecordingHttp()
    with Client(api_key="dak_x", org_id="hdfc", config=Config(endpoint="https://api.test"),
                http=http) as c:
        c.put("f.txt", data=b"data" * 500)
    # On exit, flush ran -> an upload-url call happened.
    assert any(x["url"].endswith("/v1/packs/upload-url") for x in http.calls)
