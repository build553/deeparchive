"""Tests for the packer: grouping, checksums, and offset-based extraction."""
import hashlib
import os

from deeparchive.manifest import RetentionClass
from deeparchive.packer import SourceFile, pack


def _write(path: str, data: bytes) -> None:
    with open(path, "wb") as f:
        f.write(data)


def _make_sources(tmp_path: object) -> list[SourceFile]:
    base = str(tmp_path)
    _write(os.path.join(base, "a.bin"), b"AAAA" * 100)
    _write(os.path.join(base, "b.bin"), b"BBBB" * 100)
    _write(os.path.join(base, "c.bin"), b"CCCC" * 100)
    return [
        SourceFile(os.path.join(base, "a.bin"), "a.bin", RetentionClass.SEVEN_YEAR),
        SourceFile(os.path.join(base, "b.bin"), "b.bin", RetentionClass.SEVEN_YEAR),
        SourceFile(os.path.join(base, "c.bin"), "c.bin", RetentionClass.ONE_YEAR),
    ]


def test_groups_by_retention_class(tmp_path: object) -> None:
    out = os.path.join(str(tmp_path), "out")
    packs = pack(_make_sources(tmp_path), out_dir=out, org_id="test")
    # 7y group (a,b) + 1y group (c) => 2 tarballs, never mixed.
    classes = {p.manifest.retention_class for p in packs}
    assert classes == {RetentionClass.SEVEN_YEAR, RetentionClass.ONE_YEAR}
    assert len(packs) == 2


def test_manifest_records_all_files(tmp_path: object) -> None:
    out = os.path.join(str(tmp_path), "out")
    packs = pack(_make_sources(tmp_path), out_dir=out, org_id="test")
    total_files = sum(len(p.manifest.files) for p in packs)
    assert total_files == 3


def test_file_sha256_matches_source(tmp_path: object) -> None:
    out = os.path.join(str(tmp_path), "out")
    packs = pack(_make_sources(tmp_path), out_dir=out, org_id="test")
    expected = hashlib.sha256(b"AAAA" * 100).hexdigest()
    all_entries = [e for p in packs for e in p.manifest.files]
    a_entry = next(e for e in all_entries if e.path == "a.bin")
    assert a_entry.sha256 == expected


def test_offset_and_length_extract_correct_bytes(tmp_path: object) -> None:
    """The recorded offset+length must slice the exact file bytes from the tarball."""
    out = os.path.join(str(tmp_path), "out")
    packs = pack(_make_sources(tmp_path), out_dir=out, org_id="test")
    for p in packs:
        with open(p.tarball_path, "rb") as f:
            raw = f.read()
        for entry in p.manifest.files:
            sliced = raw[entry.offset : entry.offset + entry.length]
            assert hashlib.sha256(sliced).hexdigest() == entry.sha256
