"""Tests for SsmKeyStore using moto (offline SSM Parameter Store)."""
import boto3
import pytest
from moto import mock_aws

from deeparchive.crypto import SsmKeyStore


@mock_aws
def test_get_or_create_persists_and_is_stable() -> None:
    ssm = boto3.client("ssm", region_name="us-east-1")
    store = SsmKeyStore(region="us-east-1", ssm=ssm)
    k1 = store.get_or_create_key("hdfc")
    assert len(k1) == 32
    # Stable: same customer -> same key (read back from SSM).
    store2 = SsmKeyStore(region="us-east-1", ssm=ssm)
    assert store2.get_key("hdfc") == k1


@mock_aws
def test_distinct_keys_per_customer() -> None:
    ssm = boto3.client("ssm", region_name="us-east-1")
    store = SsmKeyStore(region="us-east-1", ssm=ssm)
    assert store.get_or_create_key("hdfc") != store.get_or_create_key("icici")


@mock_aws
def test_get_missing_key_raises() -> None:
    ssm = boto3.client("ssm", region_name="us-east-1")
    store = SsmKeyStore(region="us-east-1", ssm=ssm)
    with pytest.raises(KeyError):
        store.get_key("nobody")


@mock_aws
def test_stored_as_securestring() -> None:
    ssm = boto3.client("ssm", region_name="us-east-1")
    store = SsmKeyStore(region="us-east-1", ssm=ssm)
    store.get_or_create_key("hdfc")
    param = ssm.get_parameter(Name="/deeparchive/keys/hdfc")
    assert param["Parameter"]["Type"] == "SecureString"
