"""Tests for backup/DR config (residency-aware replication)."""
import pytest

from deeparchive.backup import (
    ResidencyViolationError,
    build_replication_plan,
    replica_region_for,
    replication_config,
    versioning_config,
)


def test_versioning_enabled() -> None:
    assert versioning_config() == {"Status": "Enabled"}


def test_replica_stays_in_jurisdiction() -> None:
    # India -> India, EU -> EU, US -> US. Never crosses a jurisdiction.
    assert replica_region_for("ap-south-1") == "ap-south-2"
    assert replica_region_for("eu-central-1").startswith("eu-")
    assert replica_region_for("us-east-1").startswith("us-")


def test_unknown_region_rejected() -> None:
    # An unmapped region has no residency-safe replica -> refuse (don't guess).
    with pytest.raises(ResidencyViolationError):
        replica_region_for("cn-north-1")


def test_plan_builds_dr_bucket_name() -> None:
    plan = build_replication_plan("ap-south-1", "deep-archive-in")
    assert plan.dest_region == "ap-south-2"
    assert plan.dest_bucket == "deep-archive-in-dr-ap-south-2"
    # Both regions Indian -> residency preserved.
    assert plan.source_region.startswith("ap-south")
    assert plan.dest_region.startswith("ap-south")


def test_replication_config_shape() -> None:
    plan = build_replication_plan("us-east-1", "deep-archive-us")
    cfg = replication_config(plan, role_arn="arn:aws:iam::123:role/repl")
    rule = cfg["Rules"][0]  # type: ignore[index]
    assert rule["Status"] == "Enabled"
    assert rule["Filter"]["Prefix"] == "data/"          # only archived data
    assert rule["Destination"]["StorageClass"] == "DEEP_ARCHIVE"  # cheap replica
    assert "deep-archive-us-dr-us-west-2" in rule["Destination"]["Bucket"]
