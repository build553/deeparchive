"""Tests for the metadata service (browse catalog + folders)."""
import io
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.manifest import FileEntry, Manifest, RetentionClass
from deeparchive.services.metadata_svc import build_metadata_app
from deeparchive.storage import Storage


class FakeIdentity:
    def validate(self, api_key: str) -> dict[str, Any]:
        if not api_key.startswith("good-"):
            raise PermissionError("invalid")
        _, country, acct = api_key.split("-", 2)
        return {"account_id": acct, "country": country}


class FakeS3:
    def __init__(self, ready: bool = False, tarball_bytes: bytes = b"") -> None:
        self.objects: dict[str, bytes] = {}
        self.ready = ready
        self.tarball_bytes = tarball_bytes

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def get_object(self, Bucket, Key, Range=None):  # type: ignore[no-untyped-def]  # noqa: N803
        if Key.endswith(".tar"):
            data = self.tarball_bytes
            if Range:  # bytes=START-END
                se = Range.replace("bytes=", "").split("-")
                return {"Body": io.BytesIO(data[int(se[0]):int(se[1]) + 1])}
            return {"Body": io.BytesIO(data)}
        return {"Body": io.BytesIO(self.objects[Key])}

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"StorageClass": "DEEP_ARCHIVE",
                "Restore": f'ongoing-request="{"false" if self.ready else "true"}"'}

    def list_objects_v2(self, Bucket, Prefix):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Contents": [{"Key": k} for k in self.objects if k.startswith(Prefix)]}


def _seed(s3: FakeS3, acct: str) -> None:
    m = Manifest(
        pack_id="p1", org_id=acct, created_at="2026-01-01T00:00:00Z",
        tarball_key=f"data/{acct}/7y/p1.tar", tarball_sha256="a" * 64,
        tarball_bytes=4096, retention_class=RetentionClass.SEVEN_YEAR, legal_hold=False,
        files=[
            FileEntry("statements/jan.pdf", 512, 1024, "b" * 64, "t"),
            FileEntry("photos/x.jpg", 2048, 512, "c" * 64, "t"),
        ],
    )
    s3.objects[f"db/{acct}/p1.json"] = m.to_json().encode()


def _client(ready: bool = False, tarball_bytes: bytes = b"") -> TestClient:
    s3 = FakeS3(ready=ready, tarball_bytes=tarball_bytes)
    _seed(s3, "acc1")
    return TestClient(build_metadata_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda c: Storage(regions.resolve(c), s3=s3),  # type: ignore[arg-type]
    ))


def _auth() -> dict[str, str]:
    return {"Authorization": "Bearer good-IN-acc1"}


def test_health() -> None:
    assert _client().get("/v1/health").json()["service"] == "metadata"


def test_browse_all_files() -> None:
    resp = _client().get("/v1/catalog", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["count"] == 2
    paths = [f["path"] for f in resp.json()["files"]]
    assert "statements/jan.pdf" in paths


def test_browse_folder() -> None:
    resp = _client().get("/v1/catalog?prefix=statements/", headers=_auth())
    assert resp.json()["count"] == 1
    assert resp.json()["files"][0]["tarball_key"] == "data/acc1/7y/p1.tar"


def test_list_folders() -> None:
    resp = _client().get("/v1/folders", headers=_auth())
    assert set(resp.json()["folders"]) == {"photos", "statements"}


def test_requires_auth() -> None:
    assert _client().get("/v1/catalog").status_code == 401


def test_get_file_404_when_not_in_catalog() -> None:
    resp = _client(ready=True).get("/v1/files/nope.pdf/content", headers=_auth())
    assert resp.status_code == 404


def test_get_file_409_when_not_restored() -> None:
    resp = _client(ready=False).get("/v1/files/statements/jan.pdf/content", headers=_auth())
    assert resp.status_code == 409


def test_get_file_returns_bytes_when_restored() -> None:
    # jan.pdf is at offset 512, length 1024 in the (unencrypted) tarball.
    tarball = b"X" * 512 + b"J" * 1024 + b"Z" * 100
    resp = _client(ready=True, tarball_bytes=tarball).get(
        "/v1/files/statements/jan.pdf/content", headers=_auth()
    )
    assert resp.status_code == 200
    assert resp.content == b"J" * 1024  # exactly the file's bytes, extracted by offset


class FakeAudit:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def record(self, event: Any) -> None:
        self.events.append(event)


def test_audit_records_file_retrieval() -> None:
    tarball = b"X" * 512 + b"J" * 1024 + b"Z" * 100
    s3 = FakeS3(ready=True, tarball_bytes=tarball)
    _seed(s3, "acc1")
    aud = FakeAudit()
    c = TestClient(build_metadata_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda cc: Storage(regions.resolve(cc), s3=s3),  # type: ignore[arg-type]
        audit=aud,  # type: ignore[arg-type]
    ))
    c.get("/v1/files/statements/jan.pdf/content", headers=_auth())
    assert [e.action for e in aud.events] == ["file.retrieve"]
    assert aud.events[0].actor == "acc1"
    assert aud.events[0].target == "statements/jan.pdf"
