"""Tests for the staging / threshold layer."""
import time

from deeparchive.manifest import RetentionClass
from deeparchive.staging import StagedFile, StagingBuffer


def _f(size: int, staged_at: float) -> StagedFile:
    return StagedFile(
        local_path="/x", archive_path="x", size=size,
        retention=RetentionClass.SEVEN_YEAR, staged_at=staged_at,
    )


def test_empty_buffer_does_not_qualify() -> None:
    buf = StagingBuffer(org_id="acc_1")
    assert buf.qualifies() is False


def test_small_fresh_buffer_does_not_qualify() -> None:
    now = time.time()
    buf = StagingBuffer(org_id="acc_1", threshold_bytes=1000, max_age_seconds=999999)
    buf.add(_f(100, now))
    assert buf.qualifies(now=now) is False


def test_qualifies_by_size() -> None:
    now = time.time()
    buf = StagingBuffer(org_id="acc_1", threshold_bytes=1000, max_age_seconds=999999)
    buf.add(_f(600, now))
    buf.add(_f(500, now))               # total 1100 >= 1000
    assert buf.qualifies(now=now) is True


def test_qualifies_by_age() -> None:
    now = time.time()
    buf = StagingBuffer(org_id="acc_1", threshold_bytes=10_000_000, max_age_seconds=100)
    buf.add(_f(50, now - 200))          # aged 200s > 100s max age
    assert buf.qualifies(now=now) is True


def test_drain_returns_and_clears() -> None:
    now = time.time()
    buf = StagingBuffer(org_id="acc_1", threshold_bytes=1000)
    buf.add(_f(600, now))
    buf.add(_f(500, now))
    drained = buf.drain()
    assert len(drained) == 2
    assert buf.files == []
    assert buf.qualifies(now=now) is False
