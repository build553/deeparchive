"""Tests for the billing API + quota enforcement in the upload path."""
from fastapi import FastAPI
from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.billing import BillingService, FakeProcessor, UsageMeter
from deeparchive.manifest import FileEntry, Manifest, RetentionClass
from deeparchive.services.api import create_app
from deeparchive.services.api.auth import KeyStore
from deeparchive.services.api.billing_api import build_billing_router
from deeparchive.storage import Storage

_KEY = "bk"
_GB = 1024 * 1024 * 1024


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body


def _setup() -> tuple[TestClient, UsageMeter]:
    meter = UsageMeter()
    billing = BillingService(processor=FakeProcessor(), meter=meter)
    keys = KeyStore()
    keys.add_key(_KEY, org_id="hdfc")

    app: FastAPI = create_app(
        storage_provider=lambda c: Storage(regions.resolve(c), s3=FakeS3()),  # type: ignore[arg-type]
        key_store=keys, usage_meter=meter,
    )
    app.include_router(build_billing_router(keys, billing, meter))
    return TestClient(app), meter


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {_KEY}"}


def _manifest(pack_id: str, size: int) -> str:
    return Manifest(
        pack_id=pack_id, org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key=f"data/hdfc/7y/{pack_id}.tar", tarball_sha256="a" * 64,
        tarball_bytes=size, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("f", 0, 10, "a" * 64, "2026-01-01T00:00:00Z")],
    ).to_json()


def test_purchase_then_account() -> None:
    client, _ = _setup()
    buy = client.post("/v1/billing/purchase",
                      json={"plan_id": "individual-100-30y", "payment_token": "tok"},
                      headers=_auth())
    assert buy.status_code == 200
    assert buy.json()["quota_bytes"] == 100 * _GB

    acct = client.get("/v1/billing/account", headers=_auth()).json()
    assert acct["active"] is True
    assert acct["remaining_bytes"] == 100 * _GB


def test_declined_card_402() -> None:
    client, _ = _setup()
    resp = client.post("/v1/billing/purchase",
                       json={"plan_id": "individual-100-30y", "payment_token": "decline"},
                       headers=_auth())
    assert resp.status_code == 402


def test_upload_without_plan_rejected() -> None:
    client, _ = _setup()
    resp = client.post("/v1/packs/complete",
                       json={"country": "US", "manifest_json": _manifest("p1", 1 * _GB)},
                       headers=_auth())
    assert resp.status_code == 402  # no active plan


def test_upload_within_quota_ok_then_over_quota_rejected() -> None:
    client, _ = _setup()
    client.post("/v1/billing/purchase",
                json={"plan_id": "individual-100-30y", "payment_token": "tok"},
                headers=_auth())
    # 60GB ok...
    ok = client.post("/v1/packs/complete",
                     json={"country": "US", "manifest_json": _manifest("p1", 60 * _GB)},
                     headers=_auth())
    assert ok.status_code == 200
    # ...another 60GB exceeds the 100GB quota.
    over = client.post("/v1/packs/complete",
                       json={"country": "US", "manifest_json": _manifest("p2", 60 * _GB)},
                       headers=_auth())
    assert over.status_code == 402


def test_webhook_payment_succeeded_grants_entitlement() -> None:
    client, _ = _setup()
    resp = client.post("/v1/billing/webhook", json={
        "event_type": "payment.succeeded",
        "account_id": "hdfc",
        "plan_id": "individual-100-30y",
    })
    assert resp.status_code == 200
    assert resp.json()["status"] == "granted"
    # Entitlement now active -> upload allowed.
    up = client.post("/v1/packs/complete",
                     json={"country": "US", "manifest_json": _manifest("pw", 10 * _GB)},
                     headers=_auth())
    assert up.status_code == 200


def test_webhook_ignores_other_events() -> None:
    client, _ = _setup()
    resp = client.post("/v1/billing/webhook", json={
        "event_type": "payment.pending", "account_id": "hdfc",
        "plan_id": "individual-100-30y",
    })
    assert resp.json()["status"] == "ignored"


def test_subscribe_then_cancel() -> None:
    client, _ = _setup()
    sub = client.post("/v1/billing/subscribe",
                      json={"plan_id": "individual-100-monthly", "payment_token": "tok"},
                      headers=_auth())
    assert sub.status_code == 200
    assert sub.json()["status"] == "subscribed"
    cancel = client.post("/v1/billing/cancel", headers=_auth())
    assert cancel.status_code == 200
    assert cancel.json()["status"] == "canceled"


def test_recurring_invoice_renews() -> None:
    client, _ = _setup()
    client.post("/v1/billing/subscribe",
                json={"plan_id": "individual-100-monthly", "payment_token": "tok"},
                headers=_auth())
    resp = client.post("/v1/billing/webhook", json={
        "event_type": "invoice.payment_succeeded", "account_id": "hdfc",
        "plan_id": "individual-100-monthly",
    })
    assert resp.json()["status"] == "renewed"


def test_recurring_invoice_failed_marks_past_due() -> None:
    client, _ = _setup()
    client.post("/v1/billing/subscribe",
                json={"plan_id": "individual-100-monthly", "payment_token": "tok"},
                headers=_auth())
    resp = client.post("/v1/billing/webhook", json={
        "event_type": "invoice.payment_failed", "account_id": "hdfc",
        "plan_id": "individual-100-monthly",
    })
    assert resp.json()["status"] == "past_due"


def test_webhook_rejects_bad_signature_when_secret_set() -> None:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    from deeparchive.billing import BillingService, FakeProcessor, UsageMeter
    from deeparchive.services.api.auth import KeyStore
    from deeparchive.services.api.billing_api import build_billing_router

    meter = UsageMeter()
    keys = KeyStore()
    keys.add_key(_KEY, org_id="hdfc")
    app = FastAPI()
    app.include_router(build_billing_router(
        keys, BillingService(processor=FakeProcessor(), meter=meter), meter,
        webhook_secret="whsec_test",
    ))
    client = TestClient(app)
    # No/invalid Stripe-Signature header -> verification fails -> 400.
    resp = client.post("/v1/billing/webhook", content=b'{"type":"payment.succeeded"}',
                       headers={"Stripe-Signature": "bad"})
    assert resp.status_code == 400
