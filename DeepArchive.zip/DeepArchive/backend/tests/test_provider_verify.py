"""Tests for the actual verify() logic of the real social providers.

The provider libraries (google-auth, requests, PyJWT) are imported lazily inside
verify(); here we inject fakes via sys.modules so we exercise the real branching
(valid / invalid / wrong-app) without any network.
"""
import sys
import types

import pytest

from deeparchive.accounts.social import (
    AppleTokenVerifier,
    AuthError,
    FacebookTokenVerifier,
    GoogleTokenVerifier,
)


def test_facebook_valid_token(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    calls = {"n": 0}

    class Resp:
        def __init__(self, payload: dict[str, object]) -> None: self._p = payload
        def json(self) -> dict[str, object]: return self._p

    def fake_get(url: str, params: dict[str, object], timeout: int) -> "Resp":
        calls["n"] += 1
        if "debug_token" in url:
            return Resp({"data": {"is_valid": True, "app_id": "123"}})
        return Resp({"id": "fb-42", "email": "u@fb.com"})

    fake_requests = types.SimpleNamespace(get=fake_get)
    monkeypatch.setitem(sys.modules, "requests", fake_requests)

    ident = FacebookTokenVerifier(app_id="123", app_secret="s").verify("tok")
    assert ident.provider == "facebook"
    assert ident.provider_user_id == "fb-42"
    assert ident.email == "u@fb.com"
    assert calls["n"] == 2  # debug_token + /me


def test_facebook_invalid_token(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    class Resp:
        def json(self) -> dict[str, object]: return {"data": {"is_valid": False}}

    monkeypatch.setitem(sys.modules, "requests",
                        types.SimpleNamespace(get=lambda *a, **k: Resp()))
    with pytest.raises(AuthError):
        FacebookTokenVerifier(app_id="123", app_secret="s").verify("bad")


def test_facebook_wrong_app_rejected(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    class Resp:
        def json(self) -> dict[str, object]: return {"data": {"is_valid": True, "app_id": "999"}}

    monkeypatch.setitem(sys.modules, "requests",
                        types.SimpleNamespace(get=lambda *a, **k: Resp()))
    with pytest.raises(AuthError):
        FacebookTokenVerifier(app_id="123", app_secret="s").verify("tok")


def _install_module(monkeypatch, dotted: str, module: object) -> None:  # type: ignore[no-untyped-def]
    """Register a dotted module path + all its parent packages in sys.modules."""
    parts = dotted.split(".")
    for i in range(1, len(parts)):
        parent = ".".join(parts[:i])
        if parent not in sys.modules:
            monkeypatch.setitem(sys.modules, parent, types.ModuleType(parent))
    monkeypatch.setitem(sys.modules, dotted, module)


def test_google_valid_token(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    id_token_mod = types.SimpleNamespace(
        verify_oauth2_token=lambda token, req, cid: {"sub": "g-7", "email": "u@gmail.com"}
    )
    _install_module(monkeypatch, "google.oauth2.id_token", id_token_mod)
    _install_module(monkeypatch, "google.auth.transport.requests",
                    types.SimpleNamespace(Request=lambda: object()))
    ident = GoogleTokenVerifier(client_id="cid").verify("tok")
    assert ident.provider == "google"
    assert ident.provider_user_id == "g-7"


def test_google_invalid_token(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    def boom(token: str, req: object, cid: str) -> dict[str, object]:
        raise ValueError("bad token")

    _install_module(monkeypatch, "google.oauth2.id_token",
                    types.SimpleNamespace(verify_oauth2_token=boom))
    _install_module(monkeypatch, "google.auth.transport.requests",
                    types.SimpleNamespace(Request=lambda: object()))
    with pytest.raises(AuthError):
        GoogleTokenVerifier(client_id="cid").verify("bad")


def test_apple_invalid_token(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    class FakeJwk:
        def get_signing_key_from_jwt(self, token: str) -> object:
            raise ValueError("no key")

    fake_jwt = types.SimpleNamespace(
        decode=lambda *a, **k: {}, PyJWKClient=lambda url: FakeJwk()
    )
    _install_module(monkeypatch, "jwt", fake_jwt)
    with pytest.raises(AuthError):
        AppleTokenVerifier(client_id="com.example").verify("bad")
