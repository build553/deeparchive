"""Tests for the accounts core: account_id spine + key/region wiring."""
import os

import pytest

from deeparchive import regions
from deeparchive.accounts import AccountService, AccountStore, AccountType
from deeparchive.crypto import LocalKeyStore
from deeparchive.services.api.auth import KeyStore as ApiKeyStore


def _service(tmp_path: object) -> AccountService:
    return AccountService(
        accounts=AccountStore(),
        api_keys=ApiKeyStore(),
        crypto_keys=LocalKeyStore(os.path.join(str(tmp_path), "keys.json")),
    )


def test_create_mints_id_and_wires_keys_and_region(tmp_path: object) -> None:
    svc = _service(tmp_path)
    result = svc.create(country="IN", email="a@example.com")

    acc = result.account
    assert acc.account_id.startswith("acc_")
    assert acc.region == "ap-south-1"          # region from country (residency)
    assert acc.account_type is AccountType.INDIVIDUAL
    assert result.api_key.startswith("dak_")   # api key returned once

    # The api key authenticates back to this account_id.
    principal = svc.api_keys.authenticate(result.api_key)
    assert principal.org_id == acc.account_id
    # An encryption key now exists for the account.
    assert len(svc.crypto_keys.get_key(acc.account_id)) == 32


def test_unserved_country_refused(tmp_path: object) -> None:
    svc = _service(tmp_path)
    with pytest.raises(regions.CountryNotServedError):
        svc.create(country="NG", email="x@example.com")


def test_lookup_by_email_and_phone(tmp_path: object) -> None:
    svc = _service(tmp_path)
    r = svc.create(country="US", email="Bob@Example.com", phone="+15551234567")
    by_email = svc.accounts.find_by_email("bob@example.com")
    by_phone = svc.accounts.find_by_phone("+15551234567")
    assert by_email is not None and by_email.account_id == r.account.account_id
    assert by_phone is not None and by_phone.account_id == r.account.account_id


def test_each_account_gets_distinct_keys(tmp_path: object) -> None:
    svc = _service(tmp_path)
    a = svc.create(country="US", email="a@example.com")
    b = svc.create(country="US", email="b@example.com")
    assert a.account.account_id != b.account.account_id
    assert a.api_key != b.api_key
    assert svc.crypto_keys.get_key(a.account.account_id) != svc.crypto_keys.get_key(
        b.account.account_id
    )
