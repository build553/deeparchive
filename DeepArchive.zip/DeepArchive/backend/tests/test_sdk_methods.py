"""Tests for the SDK read/restore methods."""
from typing import Any, Optional

import pytest

from deeparchive.sdk import Client, Config, NotFoundError, QuotaError


class Resp:
    def __init__(self, status: int, payload: Optional[dict[str, Any]] = None) -> None:
        self.status_code = status
        self._p = payload or {}
        self.content = b"{}"

    def json(self) -> dict[str, Any]:
        return self._p


class RouteHttp:
    """Returns a response based on (method, url substring)."""

    def __init__(self, routes: dict[str, Resp]) -> None:
        self._routes = routes
        self.calls: list[tuple[str, str]] = []

    def request(self, method, url, headers, json=None, content=None):  # type: ignore[no-untyped-def]
        self.calls.append((method, url))
        for frag, resp in self._routes.items():
            if frag in url:
                return resp
        return Resp(200, {})


def _client(routes: dict[str, Resp]) -> Client:
    return Client(api_key="dak", org_id="hdfc", config=Config(endpoint="https://api.test"),
                  http=RouteHttp(routes))


def test_find_file_returns_location() -> None:
    c = _client({"/v1/files": Resp(200, {"tarball_key": "data/hdfc/7y/p.tar",
                                         "offset": 512, "length": 2048})})
    loc = c.find_file("statements/jan.pdf")
    assert loc["tarball_key"] == "data/hdfc/7y/p.tar"
    assert loc["offset"] == 512


def test_find_file_missing_raises_not_found() -> None:
    c = _client({"/v1/files": Resp(404, {"detail": "not found"})})
    with pytest.raises(NotFoundError):
        c.find_file("nope.pdf")


def test_restore_returns_state() -> None:
    c = _client({"/v1/restore": Resp(200, {"tarball_key": "data/hdfc/7y/p.tar",
                                           "state": "RESTORING", "sla_hours": 48})})
    job = c.restore("data/hdfc/7y/p.tar")
    assert job["state"] == "RESTORING"
    assert job["sla_hours"] == 48


def test_account_returns_usage() -> None:
    c = _client({"/v1/billing/account": Resp(200, {"active": True,
                                                   "remaining_bytes": 100})})
    acct = c.account()
    assert acct["active"] is True


def test_purchase_quota_error_maps() -> None:
    c = _client({"/v1/billing/purchase": Resp(402, {"detail": "card declined"})})
    with pytest.raises(QuotaError):
        c.purchase("individual-100-30y", payment_token="decline")
