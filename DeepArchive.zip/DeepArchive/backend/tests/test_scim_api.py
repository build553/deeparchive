"""Tests for the SCIM HTTP endpoints."""
from fastapi import FastAPI
from fastapi.testclient import TestClient

from deeparchive.accounts.orgs import Organization, Role
from deeparchive.accounts.scim import ScimService
from deeparchive.services.api.auth import KeyStore
from deeparchive.services.api.scim_api import build_scim_router

_KEY = "scim_key"


def _client() -> tuple[TestClient, Organization]:
    org = Organization(account_id="hdfc", name="HDFC")
    svc = ScimService(org=org)
    keys = KeyStore()
    keys.add_key(_KEY, org_id="hdfc")
    app = FastAPI()
    app.include_router(build_scim_router(keys, lambda org_id: svc))
    return TestClient(app), org


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {_KEY}"}


def test_scim_create_adds_member() -> None:
    client, org = _client()
    resp = client.post("/scim/v2/Users", json={"userName": "alice@hdfc"}, headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["userName"] == "alice@hdfc"
    assert org.role_of("alice@hdfc") is Role.MEMBER


def test_scim_list_and_get() -> None:
    client, _ = _client()
    created = client.post("/scim/v2/Users", json={"userName": "bob@hdfc"}, headers=_auth())
    sid = created.json()["id"]
    assert client.get("/scim/v2/Users", headers=_auth()).json()["totalResults"] == 1
    assert client.get(f"/scim/v2/Users/{sid}", headers=_auth()).json()["userName"] == "bob@hdfc"


def test_scim_delete_deprovisions() -> None:
    client, org = _client()
    sid = client.post("/scim/v2/Users", json={"userName": "carol@hdfc"},
                      headers=_auth()).json()["id"]
    assert client.delete(f"/scim/v2/Users/{sid}", headers=_auth()).status_code == 200
    assert org.role_of("carol@hdfc") is None  # access revoked


def test_scim_requires_auth() -> None:
    client, _ = _client()
    assert client.get("/scim/v2/Users").status_code == 401
