"""Tests for the account/registration API endpoints."""
import os

from fastapi import FastAPI
from fastapi.testclient import TestClient

from deeparchive.accounts import (
    AccountService,
    AccountStore,
    MobileOtp,
    OrgService,
    OrgStore,
    SocialAuth,
)
from deeparchive.accounts.otp import FakeSender
from deeparchive.accounts.social import FakeVerifier
from deeparchive.crypto import LocalKeyStore
from deeparchive.services.api.accounts_api import AccountsDeps, build_accounts_router
from deeparchive.services.api.auth import KeyStore as ApiKeyStore


def _client(tmp_path: object) -> tuple[TestClient, FakeVerifier, FakeSender]:
    api_keys = ApiKeyStore()
    account_service = AccountService(
        accounts=AccountStore(),
        api_keys=api_keys,
        crypto_keys=LocalKeyStore(os.path.join(str(tmp_path), "keys.json")),
    )
    google = FakeVerifier(provider="google")
    sender = FakeSender()
    deps = AccountsDeps(
        account_service=account_service,
        social=SocialAuth(accounts=account_service, verifiers={"google": google}),
        otp=MobileOtp(accounts=account_service, sender=sender),
        orgs=OrgService(accounts=account_service, orgs=OrgStore()),
        api_keys=api_keys,
    )
    app = FastAPI()
    app.include_router(build_accounts_router(deps))
    return TestClient(app), google, sender


def test_social_sign_in_creates_then_reuses(tmp_path: object) -> None:
    client, google, _ = _client(tmp_path)
    google.register_token("tok", user_id="g-1", email="u@gmail.com")

    r1 = client.post("/v1/accounts/social",
                     json={"provider": "google", "token": "tok", "country": "US"})
    assert r1.status_code == 200
    assert r1.json()["new_account"] is True
    assert r1.json()["api_key"].startswith("dak_")

    r2 = client.post("/v1/accounts/social",
                     json={"provider": "google", "token": "tok", "country": "US"})
    assert r2.json()["new_account"] is False
    assert r2.json()["api_key"] is None
    assert r2.json()["account_id"] == r1.json()["account_id"]


def test_otp_request_then_verify(tmp_path: object) -> None:
    client, _, sender = _client(tmp_path)
    phone = "+15551234567"
    assert client.post("/v1/accounts/otp/request", json={"phone": phone}).status_code == 200

    code = sender.sent[phone]
    r = client.post("/v1/accounts/otp/verify",
                    json={"phone": phone, "code": code, "country": "IN"})
    assert r.status_code == 200
    assert r.json()["new_account"] is True


def test_otp_bad_code_rejected(tmp_path: object) -> None:
    client, _, _ = _client(tmp_path)
    client.post("/v1/accounts/otp/request", json={"phone": "+15550000000"})
    r = client.post("/v1/accounts/otp/verify",
                    json={"phone": "+15550000000", "code": "000000", "country": "IN"})
    assert r.status_code == 401


def test_create_org_and_me(tmp_path: object) -> None:
    client, _, _ = _client(tmp_path)
    r = client.post("/v1/orgs",
                    json={"name": "HDFC", "country": "IN", "admin_user_ref": "cto@hdfc"})
    assert r.status_code == 200
    api_key = r.json()["api_key"]

    me = client.get("/v1/accounts/me", headers={"Authorization": f"Bearer {api_key}"})
    assert me.status_code == 200
    assert me.json()["type"] == "ENTERPRISE"
    assert me.json()["region"] == "ap-south-1"


def test_me_requires_auth(tmp_path: object) -> None:
    client, _, _ = _client(tmp_path)
    assert client.get("/v1/accounts/me").status_code == 401
