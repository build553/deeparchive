"""Tests for localized (per-country) pricing."""
import pytest

from deeparchive.billing import CATALOG, PlanId, localized_price
from deeparchive.billing.localized import CountryNotPricedError


def test_us_priced_in_usd() -> None:
    lp = localized_price(CATALOG[PlanId.INDIVIDUAL_100_30Y], "US")
    assert lp.currency == "USD"
    assert lp.amount_minor > 0


def test_india_priced_in_inr_and_cheaper_ppp() -> None:
    plan = CATALOG[PlanId.INDIVIDUAL_100_30Y]
    inr = localized_price(plan, "IN")
    usd = localized_price(plan, "US")
    assert inr.currency == "INR"
    # PPP 0.5 + FX 83 -> INR amount is large in rupees but PPP-discounted vs a
    # naive FX conversion of the USD price.
    naive_inr = usd.amount_minor * 83
    assert inr.amount_minor < naive_inr


def test_eu_priced_in_eur() -> None:
    lp = localized_price(CATALOG[PlanId.INDIVIDUAL_100_30Y], "DE")
    assert lp.currency == "EUR"


def test_unknown_country_raises() -> None:
    with pytest.raises(CountryNotPricedError):
        localized_price(CATALOG[PlanId.INDIVIDUAL_100_30Y], "ZZ")


def test_monthly_uses_higher_margin() -> None:
    monthly = localized_price(CATALOG[PlanId.INDIVIDUAL_100_MONTHLY], "US")
    # Monthly (70%) vs prepaid-30y (50%) are different tiers; both priced.
    assert monthly.amount_minor > 0
