"""Tests for the DDB connection helper + table creation, using moto (offline)."""
import boto3
from moto import mock_aws

from deeparchive.persistence import create_tables, table_name


@mock_aws
def test_create_tables_idempotent() -> None:
    ddb = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(ddb)
    names = {t.name for t in ddb.tables.all()}
    assert table_name("accounts") in names
    assert table_name("orgs") in names
    assert table_name("jobs") in names
    assert table_name("keys") in names
    assert table_name("billing") in names

    # Idempotent: running again does not error or duplicate.
    create_tables(ddb)
    assert len({t.name for t in ddb.tables.all()}) == 5
