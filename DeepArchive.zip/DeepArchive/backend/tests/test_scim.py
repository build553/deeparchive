"""Tests for SCIM auto member provisioning."""
import pytest

from deeparchive.accounts.orgs import Organization, Role
from deeparchive.accounts.scim import ScimService


def _svc() -> ScimService:
    return ScimService(org=Organization(account_id="acc_1", name="HDFC"))


def test_create_user_adds_member() -> None:
    svc = _svc()
    res = svc.create_user("alice@hdfc")
    assert res["userName"] == "alice@hdfc"
    assert res["active"] is True
    assert svc.org.role_of("alice@hdfc") is Role.MEMBER  # default role


def test_get_and_list_users() -> None:
    svc = _svc()
    r = svc.create_user("alice@hdfc")
    svc.create_user("bob@hdfc")
    assert svc.get_user(r["id"])["userName"] == "alice@hdfc"
    listing = svc.list_users()
    assert listing["totalResults"] == 2


def test_deprovision_removes_member() -> None:
    svc = _svc()
    r = svc.create_user("alice@hdfc")
    assert svc.org.role_of("alice@hdfc") is Role.MEMBER
    svc.deprovision(r["id"])                          # offboarding
    assert svc.org.role_of("alice@hdfc") is None       # access revoked


def test_unknown_scim_id_raises() -> None:
    with pytest.raises(KeyError):
        _svc().get_user("nope")
