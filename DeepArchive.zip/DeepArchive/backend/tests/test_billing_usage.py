"""Tests for usage metering + quota enforcement."""
import pytest

from deeparchive.billing import (
    CATALOG,
    NoEntitlementError,
    PlanId,
    QuotaExceededError,
    UsageMeter,
    make_entitlement,
)

_GB = 1024 * 1024 * 1024


def _meter_with_entitlement(now: float = 0.0) -> UsageMeter:
    m = UsageMeter()
    ent = make_entitlement("acc_1", CATALOG[PlanId.INDIVIDUAL_100_30Y], now=now)
    m.set_entitlement(ent)
    return m


def test_upload_within_quota_records() -> None:
    m = _meter_with_entitlement()
    m.check_and_record_upload("acc_1", 10 * _GB, now=0.0)
    assert m.usage("acc_1").stored_bytes == 10 * _GB
    assert m.remaining_quota("acc_1", now=0.0) == 90 * _GB


def test_over_quota_rejected() -> None:
    m = _meter_with_entitlement()
    with pytest.raises(QuotaExceededError):
        m.check_and_record_upload("acc_1", 101 * _GB, now=0.0)


def test_no_entitlement_rejected() -> None:
    m = UsageMeter()
    with pytest.raises(NoEntitlementError):
        m.check_and_record_upload("stranger", 1, now=0.0)


def test_expired_entitlement_rejected() -> None:
    m = _meter_with_entitlement(now=0.0)
    ent = m._entitlements["acc_1"]
    with pytest.raises(NoEntitlementError):
        m.check_and_record_upload("acc_1", 1, now=ent.expires_at + 1)


def test_egress_metered() -> None:
    m = _meter_with_entitlement()
    m.record_egress("acc_1", 5 * _GB)
    assert m.usage("acc_1").egress_bytes == 5 * _GB


def test_delete_frees_quota() -> None:
    m = _meter_with_entitlement()
    m.check_and_record_upload("acc_1", 50 * _GB, now=0.0)
    m.record_delete("acc_1", 20 * _GB)
    assert m.usage("acc_1").stored_bytes == 30 * _GB
