"""Tests for DdbOrgStore and DdbJobStore using moto (offline DynamoDB)."""
import time

import boto3
import pytest
from moto import mock_aws

from deeparchive.accounts.orgs import Organization, RetentionPolicy, Role
from deeparchive.manifest import RetentionClass
from deeparchive.persistence import DdbJobStore, DdbOrgStore, create_tables
from deeparchive.restore.orchestrator import JobStatus, RestoreRecord


@mock_aws
def test_org_store_round_trip_with_members() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbOrgStore(resource=res)

    org = Organization(
        account_id="acc_org",
        name="HDFC",
        policy=RetentionPolicy(RetentionClass.INDEFINITE, default_legal_hold=True),
    )
    org.add_member("admin@hdfc", Role.ADMIN)
    org.add_member("clerk@hdfc", Role.MEMBER)
    store.put(org)

    got = store.get("acc_org")
    assert got.name == "HDFC"
    assert got.policy.default_retention is RetentionClass.INDEFINITE
    assert got.policy.default_legal_hold is True
    assert got.role_of("admin@hdfc") is Role.ADMIN
    assert got.may_restore("clerk@hdfc") and not got.may_delete("clerk@hdfc")


@mock_aws
def test_org_missing_raises() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    with pytest.raises(KeyError):
        DdbOrgStore(resource=res).get("nope")


def _rec(job_id: str, status: JobStatus) -> RestoreRecord:
    now = time.time()
    return RestoreRecord(
        job_id=job_id, org_id="acc_1", tarball_key="data/acc_1/7y/p.tar",
        status=status, created_at=now, updated_at=now, attempts=1,
    )


@mock_aws
def test_job_store_round_trip_and_list_by_status() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbJobStore(resource=res)

    store.put(_rec("rst_1", JobStatus.RESTORING))
    store.put(_rec("rst_2", JobStatus.FAILED))
    store.put(_rec("rst_3", JobStatus.FAILED))

    assert store.get("rst_1").status is JobStatus.RESTORING
    failed = store.list_by_status(JobStatus.FAILED)
    assert {r.job_id for r in failed} == {"rst_2", "rst_3"}


@mock_aws
def test_job_persists_across_instances() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    DdbJobStore(resource=res).put(_rec("rst_persist", JobStatus.READY))
    reloaded = DdbJobStore(resource=res).get("rst_persist")
    assert reloaded.status is JobStatus.READY
