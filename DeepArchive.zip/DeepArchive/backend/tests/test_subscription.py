"""Tests for recurring subscriptions + renewal."""
from deeparchive.billing import (
    PlanId,
    SubscriptionService,
    SubStatus,
    UsageMeter,
)

_MONTH = 30 * 24 * 3600
_GB = 1024 * 1024 * 1024


def _svc() -> tuple[SubscriptionService, UsageMeter]:
    meter = UsageMeter()
    return SubscriptionService(meter=meter), meter


def test_start_grants_entitlement() -> None:
    svc, meter = _svc()
    sub = svc.start("acc_1", PlanId.INDIVIDUAL_100_MONTHLY, now=0.0)
    assert sub.status is SubStatus.ACTIVE
    assert sub.current_period_end == _MONTH
    # Entitlement active -> upload allowed within the month.
    meter.check_and_record_upload("acc_1", 10 * _GB, now=100.0)


def test_renew_extends_period_and_entitlement() -> None:
    svc, meter = _svc()
    svc.start("acc_1", PlanId.INDIVIDUAL_100_MONTHLY, now=0.0)
    # Near period end, a successful recurring charge renews.
    sub = svc.renew("acc_1", now=_MONTH - 10)
    assert sub.current_period_end == 2 * _MONTH  # extended from the prior end
    # Still usable after the original month would have lapsed.
    meter.check_and_record_upload("acc_1", 1 * _GB, now=_MONTH + 100)


def test_failed_charge_marks_past_due() -> None:
    svc, _ = _svc()
    svc.start("acc_1", PlanId.INDIVIDUAL_100_MONTHLY, now=0.0)
    sub = svc.mark_past_due("acc_1")
    assert sub.status is SubStatus.PAST_DUE
    # Access continues until period end (grace/dunning).
    assert sub.is_active(now=_MONTH - 10)


def test_cancel_stops_renewal_but_keeps_access_until_period_end() -> None:
    svc, _ = _svc()
    svc.start("acc_1", PlanId.INDIVIDUAL_100_MONTHLY, now=0.0)
    sub = svc.cancel("acc_1")
    assert sub.status is SubStatus.CANCELED
    assert sub.is_active(now=_MONTH - 10) is True    # still within paid period
    assert sub.is_active(now=_MONTH + 10) is False   # lapses after period end
