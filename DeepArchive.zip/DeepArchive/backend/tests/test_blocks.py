"""Tests for content-addressable block splitting."""
from deeparchive.blocks import (
    Block,
    block_hash,
    block_list,
    reassemble,
    split,
)


def _store(blocks: list[Block]) -> dict[str, bytes]:
    return {b.hash: b.data for b in blocks}


def test_split_and_reassemble_round_trip() -> None:
    data = b"A" * 10_000_000  # ~10 MiB -> 3 blocks at 4 MiB
    blocks = split(data)
    assert len(blocks) == 3
    assert reassemble([b.hash for b in blocks], _store(blocks)) == data


def test_small_data_one_block() -> None:
    data = b"just a little"
    blocks = split(data)
    assert len(blocks) == 1
    assert blocks[0].data == data


def test_empty_data_no_blocks() -> None:
    assert split(b"") == []


def test_identical_blocks_share_hash() -> None:
    # Two files of identical content -> identical block hashes (dedup basis).
    data = b"repeat" * 1_000_000
    assert block_list(data) == block_list(data)


def test_last_block_may_be_short() -> None:
    data = b"X" * (4 * 1024 * 1024 + 100)  # one full block + 100 bytes
    blocks = split(data)
    assert len(blocks) == 2
    assert len(blocks[0].data) == 4 * 1024 * 1024
    assert len(blocks[1].data) == 100


def test_custom_block_size() -> None:
    data = b"0123456789"
    blocks = split(data, block_size=4)
    assert [len(b.data) for b in blocks] == [4, 4, 2]
    assert reassemble([b.hash for b in blocks], _store(blocks)) == data


def test_block_hash_is_sha256() -> None:
    import hashlib
    assert block_hash(b"hello") == hashlib.sha256(b"hello").hexdigest()


def test_reassemble_missing_block_raises() -> None:
    import pytest
    blocks = split(b"data here", block_size=4)
    partial = {blocks[0].hash: blocks[0].data}  # drop the rest
    with pytest.raises(KeyError):
        reassemble([b.hash for b in blocks], partial)
