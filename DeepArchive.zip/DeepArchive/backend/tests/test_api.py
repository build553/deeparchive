"""Tests for the HTTP API: auth, org isolation, restore, residency."""
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.services.api import create_app
from deeparchive.services.api.auth import KeyStore
from deeparchive.storage import Storage

_KEY = "org_live_secret_hdfc"


class FakeS3:
    def __init__(self, ready: bool = False) -> None:
        self._ready = ready
        self.objects: dict[str, bytes] = {}

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        state = "false" if self._ready else "true"
        return {"StorageClass": "DEEP_ARCHIVE", "Restore": f'ongoing-request="{state}"'}

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return f"https://s3.example/{Params['Key']}?sig=fake"

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def get_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        import io
        return {"Body": io.BytesIO(self.objects[Key])}

    def list_objects_v2(self, Bucket, Prefix):  # type: ignore[no-untyped-def]  # noqa: N803
        keys = [k for k in self.objects if k.startswith(Prefix)]
        return {"Contents": [{"Key": k} for k in keys]}

    def delete_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects.pop(Key, None)


def _client(ready: bool = False) -> TestClient:
    shared = FakeS3(ready)

    def provider(country: str) -> Storage:
        return Storage(regions.resolve(country), s3=shared)  # type: ignore[arg-type]

    store = KeyStore()
    store.add_key(_KEY, org_id="hdfc")
    return TestClient(create_app(storage_provider=provider, key_store=store))


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {_KEY}"}


def test_health_needs_no_auth() -> None:
    assert _client().get("/v1/health").json() == {"status": "ok"}


def test_regions_lists_active() -> None:
    assert "US" in _client().get("/v1/regions").json()["active_countries"]


def test_restore_requires_auth() -> None:
    resp = _client().post(
        "/v1/restore", json={"country": "US", "tarball_key": "data/hdfc/7y/p.tar"}
    )
    assert resp.status_code == 401


def test_restore_with_valid_key_and_own_data() -> None:
    resp = _client().post(
        "/v1/restore",
        json={"country": "US", "tarball_key": "data/hdfc/7y/p.tar"},
        headers=_auth(),
    )
    assert resp.status_code == 200
    assert resp.json()["state"] == "RESTORING"


def test_restore_other_org_data_forbidden() -> None:
    # hdfc key trying to restore icici's tarball -> 403.
    resp = _client().post(
        "/v1/restore",
        json={"country": "US", "tarball_key": "data/icici/7y/p.tar"},
        headers=_auth(),
    )
    assert resp.status_code == 403


def test_invalid_key_rejected() -> None:
    resp = _client().post(
        "/v1/restore",
        json={"country": "US", "tarball_key": "data/hdfc/7y/p.tar"},
        headers={"Authorization": "Bearer wrong"},
    )
    assert resp.status_code == 401


def test_unserved_country_rejected() -> None:
    resp = _client().post(
        "/v1/restore",
        json={"country": "NG", "tarball_key": "data/hdfc/7y/p.tar"},
        headers=_auth(),
    )
    assert resp.status_code == 422


def test_pack_upload_url_returns_presigned() -> None:
    resp = _client().post(
        "/v1/packs/upload-url",
        json={"country": "US", "tarball_key": "data/hdfc/7y/p.tar"},
        headers=_auth(),
    )
    assert resp.status_code == 200
    assert resp.json()["url"].startswith("https://s3.example/")


def test_pack_upload_url_requires_auth() -> None:
    resp = _client().post(
        "/v1/packs/upload-url",
        json={"country": "US", "tarball_key": "data/hdfc/7y/p.tar"},
    )
    assert resp.status_code == 401


def test_pack_complete_registers_manifest() -> None:
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    m = Manifest(
        pack_id="pack_x", org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key="data/hdfc/7y/pack_x.tar", tarball_sha256="a" * 64,
        tarball_bytes=1024, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("f", 0, 10, "a" * 64, "2026-01-01T00:00:00Z")],
    )
    resp = _client().post(
        "/v1/packs/complete",
        json={"country": "US", "manifest_json": m.to_json()},
        headers=_auth(),
    )
    assert resp.status_code == 200
    assert resp.json()["pack_id"] == "pack_x"


def test_pack_complete_rejects_other_org_manifest() -> None:
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    m = Manifest(
        pack_id="pack_y", org_id="icici", created_at="2026-01-01T00:00:00Z",
        tarball_key="data/icici/7y/pack_y.tar", tarball_sha256="a" * 64,
        tarball_bytes=1024, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("f", 0, 10, "a" * 64, "2026-01-01T00:00:00Z")],
    )
    resp = _client().post(
        "/v1/packs/complete",
        json={"country": "US", "manifest_json": m.to_json()},
        headers=_auth(),  # hdfc key, icici manifest
    )
    assert resp.status_code == 403


def test_find_file_returns_location() -> None:
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    client = _client()
    m = Manifest(
        pack_id="pack_f", org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key="data/hdfc/7y/pack_f.tar", tarball_sha256="a" * 64,
        tarball_bytes=1024, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("statements/jan.pdf", 512, 2048, "b" * 64, "2026-01-01T00:00:00Z")],
    )
    # Register the manifest so the file is findable.
    client.post("/v1/packs/complete",
                json={"country": "US", "manifest_json": m.to_json()}, headers=_auth())

    resp = client.get("/v1/files?path=statements/jan.pdf&country=US", headers=_auth())
    assert resp.status_code == 200
    body = resp.json()
    assert body["tarball_key"] == "data/hdfc/7y/pack_f.tar"
    assert body["offset"] == 512
    assert body["length"] == 2048


def test_find_file_not_found() -> None:
    resp = _client().get("/v1/files?path=nope.pdf&country=US", headers=_auth())
    assert resp.status_code == 404


def test_find_file_requires_auth() -> None:
    resp = _client().get("/v1/files?path=x&country=US")
    assert resp.status_code == 401


def _register(client, pack_id: str, legal_hold: bool = False) -> None:  # type: ignore[no-untyped-def]
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    m = Manifest(
        pack_id=pack_id, org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key=f"data/hdfc/7y/{pack_id}.tar", tarball_sha256="a" * 64,
        tarball_bytes=1024, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=legal_hold,
        files=[FileEntry("f", 0, 10, "a" * 64, "2026-01-01T00:00:00Z")],
    )
    client.post("/v1/packs/complete",
                json={"country": "US", "manifest_json": m.to_json()}, headers=_auth())


def test_soft_delete() -> None:
    client = _client()
    _register(client, "pack_sd")
    resp = client.delete("/v1/packs/pack_sd?country=US", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["status"] == "soft_deleted"


def test_hard_delete_purges() -> None:
    client = _client()
    _register(client, "pack_hd")
    resp = client.delete("/v1/packs/pack_hd?country=US&hard=true", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["status"] == "hard_deleted"
    # The file is gone from the index afterwards.
    gone = client.get("/v1/files?path=f&country=US", headers=_auth())
    assert gone.status_code == 404


def test_hard_delete_blocked_by_legal_hold() -> None:
    client = _client()
    _register(client, "pack_lh", legal_hold=True)
    resp = client.delete("/v1/packs/pack_lh?country=US&hard=true", headers=_auth())
    assert resp.status_code == 409  # legal hold forbids hard delete


def test_delete_requires_auth() -> None:
    resp = _client().delete("/v1/packs/pack_x?country=US")
    assert resp.status_code == 401


def test_thumbnail_put_then_get() -> None:
    import base64

    client = _client()
    img = b"\xff\xd8\xff\xe0 fake jpeg bytes"
    b64 = base64.b64encode(img).decode()
    put = client.put(
        "/v1/thumbnails/photos/beach.jpg?country=US",
        json={"image_base64": b64}, headers=_auth(),
    )
    assert put.status_code == 200
    got = client.get("/v1/thumbnails/photos/beach.jpg?country=US", headers=_auth())
    assert got.status_code == 200
    assert got.content == img
    assert got.headers["content-type"] == "image/jpeg"


def test_thumbnail_missing_404() -> None:
    resp = _client().get("/v1/thumbnails/nope.jpg?country=US", headers=_auth())
    assert resp.status_code == 404


def test_thumbnail_requires_auth() -> None:
    resp = _client().get("/v1/thumbnails/x.jpg?country=US")
    assert resp.status_code == 401


def test_restore_pending_approval_when_over_threshold() -> None:
    from deeparchive.accounts.approval import ApprovalService
    from deeparchive.accounts.orgs import Organization
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    org = Organization(account_id="hdfc", name="HDFC")
    svc = ApprovalService(org=org, threshold_bytes=100)  # tiny threshold

    shared = FakeS3()

    def provider(country: str) -> Storage:
        return Storage(regions.resolve(country), s3=shared)  # type: ignore[arg-type]

    store = KeyStore()
    store.add_key(_KEY, org_id="hdfc")
    app = create_app(
        storage_provider=provider, key_store=store,
        approval_provider=lambda org_id: svc,
    )
    client = TestClient(app)

    # Register a manifest (tarball bytes > threshold) so the gate sees the size.
    m = Manifest(
        pack_id="pack_big", org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key="data/hdfc/7y/pack_big.tar", tarball_sha256="a" * 64,
        tarball_bytes=5000, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("f", 0, 10, "a" * 64, "2026-01-01T00:00:00Z")],
    )
    client.post("/v1/packs/complete",
                json={"country": "US", "manifest_json": m.to_json()}, headers=_auth())

    resp = client.post(
        "/v1/restore",
        json={"country": "US", "tarball_key": "data/hdfc/7y/pack_big.tar"},
        headers=_auth(),
    )
    assert resp.status_code == 200
    assert resp.json()["state"] == "PENDING_APPROVAL"


def _approval_client() -> tuple[TestClient, Any]:
    from deeparchive.accounts.approval import ApprovalService
    from deeparchive.accounts.orgs import Organization, Role

    org = Organization(account_id="hdfc", name="HDFC")
    org.add_member("hdfc", Role.ADMIN)  # api-key holder acts as org admin
    svc = ApprovalService(org=org, threshold_bytes=100)
    store = KeyStore()
    store.add_key(_KEY, org_id="hdfc")
    app = create_app(
        storage_provider=lambda c: Storage(regions.resolve(c), s3=FakeS3()),  # type: ignore[arg-type]
        key_store=store, approval_provider=lambda org_id: svc,
    )
    return TestClient(app), svc


def test_approve_restore_request() -> None:
    client, svc = _approval_client()
    req = svc.request("hdfc", "data/hdfc/7y/p.tar", size_bytes=5000)  # over threshold
    resp = client.post(f"/v1/restore/{req.request_id}/approve", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["state"] == "APPROVED"


def test_reject_restore_request() -> None:
    client, svc = _approval_client()
    req = svc.request("hdfc", "data/hdfc/7y/p.tar", size_bytes=5000)
    resp = client.post(f"/v1/restore/{req.request_id}/reject", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["state"] == "REJECTED"


def test_approve_unknown_request_404() -> None:
    client, _ = _approval_client()
    resp = client.post("/v1/restore/nope/approve", headers=_auth())
    assert resp.status_code == 404


def test_approve_requires_auth() -> None:
    client, _ = _approval_client()
    assert client.post("/v1/restore/x/approve").status_code == 401


def test_restore_download_409_when_not_ready() -> None:
    # Default FakeS3 head_object -> ongoing-request="true" (not ready).
    resp = _client().get(
        "/v1/restore/data/hdfc/7y/p.tar/download?country=US", headers=_auth()
    )
    assert resp.status_code == 409


def test_restore_download_returns_url_when_ready() -> None:
    resp = _client(ready=True).get(
        "/v1/restore/data/hdfc/7y/p.tar/download?country=US", headers=_auth()
    )
    assert resp.status_code == 200
    assert resp.json()["download_url"].startswith("https://s3.example/")


def test_restore_download_requires_auth() -> None:
    resp = _client().get("/v1/restore/data/hdfc/7y/p.tar/download?country=US")
    assert resp.status_code == 401
