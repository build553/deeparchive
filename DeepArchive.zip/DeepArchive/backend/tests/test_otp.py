"""Tests for mobile OTP sign-in with a fake sender."""
import os

import pytest

from deeparchive.accounts import AccountService, AccountStore
from deeparchive.accounts.otp import FakeSender, MobileOtp, OtpError
from deeparchive.crypto import LocalKeyStore
from deeparchive.services.api.auth import KeyStore as ApiKeyStore

_PHONE = "+15551234567"


def _otp(tmp_path: object) -> tuple[MobileOtp, FakeSender]:
    svc = AccountService(
        accounts=AccountStore(),
        api_keys=ApiKeyStore(),
        crypto_keys=LocalKeyStore(os.path.join(str(tmp_path), "keys.json")),
    )
    sender = FakeSender()
    return MobileOtp(accounts=svc, sender=sender), sender


def test_request_then_verify_creates_account(tmp_path: object) -> None:
    otp, sender = _otp(tmp_path)
    otp.request_code(_PHONE)
    code = sender.sent[_PHONE]                      # fake sender captured it
    created, account_id = otp.verify(_PHONE, code, country="IN")
    assert created is not None
    assert account_id.startswith("acc_")
    assert created.account.phone == _PHONE
    assert created.account.region == "ap-south-1"   # residency from country


def test_wrong_code_rejected(tmp_path: object) -> None:
    otp, sender = _otp(tmp_path)
    otp.request_code(_PHONE)
    with pytest.raises(OtpError):
        otp.verify(_PHONE, "000000", country="IN")


def test_code_is_single_use(tmp_path: object) -> None:
    otp, sender = _otp(tmp_path)
    otp.request_code(_PHONE)
    code = sender.sent[_PHONE]
    otp.verify(_PHONE, code, country="IN")
    with pytest.raises(OtpError):                   # second use fails
        otp.verify(_PHONE, code, country="IN")


def test_rate_limit_blocks_rapid_resend(tmp_path: object) -> None:
    otp, _ = _otp(tmp_path)
    otp.request_code(_PHONE)
    with pytest.raises(OtpError):
        otp.request_code(_PHONE)                    # too soon


def test_returning_user_reuses_account(tmp_path: object) -> None:
    otp, sender = _otp(tmp_path)
    otp.request_code(_PHONE)
    _, first_id = otp.verify(_PHONE, sender.sent[_PHONE], country="IN")
    # A later successful OTP for the same phone reuses the account.
    otp._pending.clear()                            # bypass rate limit for test
    otp.request_code(_PHONE)
    created2, second_id = otp.verify(_PHONE, sender.sent[_PHONE], country="IN")
    assert created2 is None
    assert first_id == second_id
