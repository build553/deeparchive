"""Tests for pluggable notifications + event templates."""
from deeparchive.notify import (
    FakeNotifier,
    payment_failed,
    quota_low,
    restore_ready,
)


def test_fake_notifier_captures() -> None:
    n = FakeNotifier()
    n.send(restore_ready("a@x.com", "jan.pdf"))
    assert len(n.sent) == 1
    assert n.sent[0].to == "a@x.com"


def test_restore_ready_template() -> None:
    m = restore_ready("a@x.com", "statements/jan.pdf", expires_hours=48)
    assert "jan.pdf" in m.body
    assert "48 hours" in m.body
    assert "ready" in m.subject.lower()


def test_quota_low_template_percent() -> None:
    m = quota_low("a@x.com", used_gb=90.0, quota_gb=100.0)
    assert "90" in m.body  # 90%
    assert "90.0 GB" in m.body
    assert "100.0 GB" in m.body


def test_quota_low_zero_quota_safe() -> None:
    # No divide-by-zero when quota is 0.
    m = quota_low("a@x.com", used_gb=5.0, quota_gb=0.0)
    assert "100%" in m.body


def test_payment_failed_template() -> None:
    m = payment_failed("a@x.com", plan="Individual 30yr", amount="$120.00")
    assert "$120.00" in m.body
    assert "Individual 30yr" in m.body
    assert "failed" in m.subject.lower()
    assert "data is safe" in m.body.lower()  # reassure: retained during grace
