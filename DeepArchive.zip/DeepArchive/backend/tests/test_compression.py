"""Tests for the compression module."""
from deeparchive.compression import Codec, choose_codec, compress, decompress


def test_gzip_round_trip() -> None:
    data = b"hello world " * 1000
    packed = compress(data, Codec.GZIP)
    assert packed != data
    assert len(packed) < len(data)  # it actually compressed
    assert decompress(packed, Codec.GZIP) == data


def test_store_is_identity() -> None:
    data = b"anything"
    assert compress(data, Codec.STORE) == data
    assert decompress(data, Codec.STORE) == data


def test_choose_codec_compresses_text() -> None:
    assert choose_codec("notes/report.txt", 10_000) is Codec.GZIP
    assert choose_codec("data/log.json", 5_000) is Codec.GZIP


def test_choose_codec_stores_already_compressed() -> None:
    assert choose_codec("photos/x.jpg", 5_000_000) is Codec.STORE
    assert choose_codec("video/clip.mp4", 50_000_000) is Codec.STORE
    assert choose_codec("archive/backup.zip", 1_000_000) is Codec.STORE


def test_choose_codec_stores_tiny_files() -> None:
    # Below the gzip-header-overhead threshold.
    assert choose_codec("tiny.txt", 100) is Codec.STORE


def test_gzip_output_is_deterministic() -> None:
    # mtime=0 -> identical bytes for identical input (needed for dedup later).
    data = b"reproducible" * 500
    assert compress(data, Codec.GZIP) == compress(data, Codec.GZIP)
