"""Tests for the token-bucket rate limiter and API 429 behavior."""
from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.services.api import create_app
from deeparchive.services.api.auth import KeyStore
from deeparchive.services.api.ratelimit import RateLimiter
from deeparchive.storage import Storage


def test_allows_within_capacity() -> None:
    rl = RateLimiter(capacity=3, refill_per_sec=0)
    assert all(rl.allow("k", now=100.0) for _ in range(3))


def test_blocks_over_capacity() -> None:
    rl = RateLimiter(capacity=2, refill_per_sec=0)
    assert rl.allow("k", now=100.0)
    assert rl.allow("k", now=100.0)
    assert rl.allow("k", now=100.0) is False  # third exceeds


def test_refills_over_time() -> None:
    rl = RateLimiter(capacity=1, refill_per_sec=1.0)
    assert rl.allow("k", now=100.0)
    assert rl.allow("k", now=100.0) is False       # empty
    assert rl.allow("k", now=101.5)                # 1.5s later -> refilled


def test_per_key_isolation() -> None:
    rl = RateLimiter(capacity=1, refill_per_sec=0)
    assert rl.allow("a", now=100.0)
    assert rl.allow("b", now=100.0)                # different key, own bucket


class _FakeS3:
    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Restore": 'ongoing-request="true"'}

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None


def test_api_returns_429_when_limited() -> None:
    store = KeyStore()
    store.add_key("k", org_id="hdfc")
    app = create_app(
        storage_provider=lambda c: Storage(regions.resolve(c), s3=_FakeS3()),  # type: ignore[arg-type]
        key_store=store,
        rate_limiter=RateLimiter(capacity=1, refill_per_sec=0),
    )
    client = TestClient(app)
    body = {"country": "US", "tarball_key": "data/hdfc/7y/p.tar"}
    h = {"Authorization": "Bearer k"}
    assert client.post("/v1/restore", json=body, headers=h).status_code == 200
    assert client.post("/v1/restore", json=body, headers=h).status_code == 429
