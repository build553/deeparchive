"""Tests for the catalog builder."""
from deeparchive.catalog import (
    build_catalog,
    filter_prefix,
    find,
    list_folders,
)
from deeparchive.manifest import FileEntry, Manifest, RetentionClass


def _manifest(pack_id: str, paths: list[str]) -> Manifest:
    return Manifest(
        pack_id=pack_id, org_id="hdfc", created_at="2026-01-01T00:00:00Z",
        tarball_key=f"data/hdfc/7y/{pack_id}.tar", tarball_sha256="a" * 64,
        tarball_bytes=4096, retention_class=RetentionClass.SEVEN_YEAR, legal_hold=False,
        files=[FileEntry(p, i * 512, 512, "b" * 64, "2026-01-01T00:00:00Z")
               for i, p in enumerate(paths)],
    )


def _catalog() -> list:  # type: ignore[type-arg]
    return build_catalog([
        _manifest("p1", ["statements/2026/jan.pdf", "statements/2026/feb.pdf"]),
        _manifest("p2", ["photos/beach.jpg", "statements/2025/dec.pdf"]),
    ])


def test_build_catalog_flattens_and_sorts() -> None:
    cat = _catalog()
    assert len(cat) == 4
    assert [e.path for e in cat] == sorted(e.path for e in cat)
    jan = find(cat, "statements/2026/jan.pdf")
    assert jan is not None
    assert jan.tarball_key == "data/hdfc/7y/p1.tar"
    assert jan.pack_id == "p1"


def test_filter_prefix_browses_folder() -> None:
    cat = _catalog()
    stmts = filter_prefix(cat, "statements/")
    assert len(stmts) == 3
    assert all(e.path.startswith("statements/") for e in stmts)


def test_list_folders_top_level() -> None:
    cat = _catalog()
    assert list_folders(cat) == ["photos", "statements"]


def test_list_folders_nested() -> None:
    cat = _catalog()
    assert list_folders(cat, "statements/") == ["2025", "2026"]


def test_find_missing_returns_none() -> None:
    assert find(_catalog(), "nope.pdf") is None
