"""Tests for the org model: provisioning, roles, retention policy."""
import os

from deeparchive.accounts import AccountService, AccountStore, AccountType
from deeparchive.accounts.orgs import (
    OrgService,
    OrgStore,
    RetentionPolicy,
    Role,
)
from deeparchive.crypto import LocalKeyStore
from deeparchive.manifest import RetentionClass
from deeparchive.services.api.auth import KeyStore as ApiKeyStore


def _org_service(tmp_path: object) -> OrgService:
    accounts = AccountService(
        accounts=AccountStore(),
        api_keys=ApiKeyStore(),
        crypto_keys=LocalKeyStore(os.path.join(str(tmp_path), "keys.json")),
    )
    return OrgService(accounts=accounts, orgs=OrgStore())


def test_create_org_provisions_enterprise_account_and_admin(tmp_path: object) -> None:
    svc = _org_service(tmp_path)
    org, api_key = svc.create_org(name="HDFC", country="IN", admin_user_ref="cto@hdfc")

    assert org.account_id.startswith("acc_")
    assert api_key.startswith("dak_")
    acc = svc.accounts.accounts.get(org.account_id)
    assert acc.account_type is AccountType.ENTERPRISE
    assert acc.region == "ap-south-1"                 # residency
    assert org.role_of("cto@hdfc") is Role.ADMIN


def test_roles_gate_restore_and_delete(tmp_path: object) -> None:
    svc = _org_service(tmp_path)
    org, _ = svc.create_org(name="HDFC", country="IN", admin_user_ref="admin@hdfc")
    org.add_member("clerk@hdfc", Role.MEMBER)
    org.add_member("auditor@hdfc", Role.VIEWER)

    # Admin: everything.
    assert org.may_restore("admin@hdfc") and org.may_delete("admin@hdfc")
    # Member: restore yes, delete no.
    assert org.may_restore("clerk@hdfc") and not org.may_delete("clerk@hdfc")
    # Viewer: neither (browse only) -- protects egress cost.
    assert not org.may_restore("auditor@hdfc")
    assert not org.may_delete("auditor@hdfc")
    # Non-member: nothing.
    assert not org.may_restore("stranger@evil")


def test_retention_policy_defaults_and_custom(tmp_path: object) -> None:
    svc = _org_service(tmp_path)
    default_org, _ = svc.create_org(name="A", country="US", admin_user_ref="a@a")
    assert default_org.policy.default_retention is RetentionClass.SEVEN_YEAR
    assert default_org.policy.default_legal_hold is False

    custom = RetentionPolicy(
        default_retention=RetentionClass.INDEFINITE, default_legal_hold=True
    )
    held_org, _ = svc.create_org(
        name="B", country="US", admin_user_ref="b@b", policy=custom
    )
    assert held_org.policy.default_retention is RetentionClass.INDEFINITE
    assert held_org.policy.default_legal_hold is True


def test_org_persists_in_store(tmp_path: object) -> None:
    svc = _org_service(tmp_path)
    org, _ = svc.create_org(name="HDFC", country="IN", admin_user_ref="admin@hdfc")
    assert svc.orgs.get(org.account_id).name == "HDFC"
