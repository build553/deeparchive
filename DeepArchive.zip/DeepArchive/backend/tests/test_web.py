"""Tests for the website gateway."""
from fastapi.testclient import TestClient

from deeparchive.services.web import create_web_app, index_html


def test_home_serves_html() -> None:
    client = TestClient(create_web_app())
    resp = client.get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert "DeepArchive" in resp.text


def test_page_wires_the_api_endpoints() -> None:
    html = index_html()
    # The UI must call the real API endpoints.
    assert "/v1/regions" in html
    assert "/v1/accounts/otp/request" in html
    assert "/v1/accounts/social" in html
    assert "/v1/restore" in html
