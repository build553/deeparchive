"""Tests for CLI upload/restore/status commands (fake storage, no AWS)."""
import os

from deeparchive import regions
from deeparchive.services.cli import main
from deeparchive.storage import Storage


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def upload_file(self, Filename, Bucket, Key, Config=None):  # type: ignore[no-untyped-def]  # noqa: N803
        with open(Filename, "rb") as f:
            self.objects[Key] = f.read()

    def put_object(self, Bucket, Key, Body):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"StorageClass": "DEEP_ARCHIVE", "Restore": 'ongoing-request="true"'}


def _patch_storage(monkeypatch) -> FakeS3:  # type: ignore[no-untyped-def]
    fake = FakeS3()

    def fake_for_country(country, s3=None, key_store=None):  # type: ignore[no-untyped-def]
        return Storage(regions.resolve(country), s3=fake)  # type: ignore[arg-type]

    monkeypatch.setattr(Storage, "for_country", staticmethod(fake_for_country))
    return fake


def _pack_dir(tmp_path: object) -> str:
    base = str(tmp_path)
    src, out = os.path.join(base, "src"), os.path.join(base, "out")
    os.makedirs(src)
    with open(os.path.join(src, "a.txt"), "wb") as f:
        f.write(b"data" * 100)
    assert main(["pack", src, out, "--org", "acme", "--retention", "7y"]) == 0
    return out


def test_cli_upload(tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    fake = _patch_storage(monkeypatch)
    out = _pack_dir(tmp_path)
    rc = main(["upload", out, "--country", "US", "--org", "acme"])
    assert rc == 0
    assert any(k.endswith(".tar") for k in fake.objects)


def test_cli_restore(tmp_path, monkeypatch, capsys) -> None:  # type: ignore[no-untyped-def]
    _patch_storage(monkeypatch)
    rc = main(["restore", "data/acme/7y/pack.tar", "--country", "US"])
    assert rc == 0
    assert "RESTORING" in capsys.readouterr().out


def test_cli_status(tmp_path, monkeypatch, capsys) -> None:  # type: ignore[no-untyped-def]
    _patch_storage(monkeypatch)
    rc = main(["status", "data/acme/7y/pack.tar", "--country", "US"])
    assert rc == 0
    assert "RESTORING" in capsys.readouterr().out
