"""Tests for account service wiring (factory-backed persistence)."""
from fastapi import FastAPI
from fastapi.testclient import TestClient

from deeparchive.services.api.accounts_api import build_accounts_router
from deeparchive.services.api.wiring import build_accounts_deps


def test_wiring_builds_working_services(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.delenv("DEEPARCHIVE_USE_DDB", raising=False)
    monkeypatch.setattr("deeparchive.config.DDB_ENDPOINT_URL", None)

    deps = build_accounts_deps()
    app = FastAPI()
    app.include_router(build_accounts_router(deps))
    client = TestClient(app)

    # Create an org through the wired services -> persists to the factory store.
    resp = client.post(
        "/v1/orgs", json={"name": "HDFC", "country": "IN", "admin_user_ref": "cto@hdfc"}
    )
    assert resp.status_code == 200
    api_key = resp.json()["api_key"]

    me = client.get("/v1/accounts/me", headers={"Authorization": f"Bearer {api_key}"})
    assert me.status_code == 200
    assert me.json()["type"] == "ENTERPRISE"
