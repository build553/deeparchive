"""Tests for the ingest microservice (region from identity, quota via billing)."""
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.manifest import FileEntry, Manifest, RetentionClass
from deeparchive.services.ingest_svc import build_ingest_app
from deeparchive.storage import Storage

_GB = 1024 * 1024 * 1024


class FakeIdentity:
    """Resolves any key 'good-<country>-<acct>' to that account + country."""

    def validate(self, api_key: str) -> dict[str, Any]:
        if not api_key.startswith("good-"):
            raise PermissionError("invalid")
        _, country, acct = api_key.split("-", 2)
        return {"account_id": acct, "country": country}


class FakeBilling:
    def __init__(self, allow: bool = True) -> None:
        self.allow = allow

    def check_quota(self, account_id: str, size_bytes: int) -> bool:
        return self.allow


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return f"https://s3.example/{Params['Key']}?sig=x"

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def get_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        import io
        return {"Body": io.BytesIO(self.objects[Key])}

    def list_objects_v2(self, Bucket, Prefix):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Contents": [{"Key": k} for k in self.objects if k.startswith(Prefix)]}


def _client(allow_quota: bool = True) -> TestClient:
    s3 = FakeS3()
    return TestClient(build_ingest_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        billing=FakeBilling(allow_quota),  # type: ignore[arg-type]
        storage_for_country=lambda c: Storage(regions.resolve(c), s3=s3),  # type: ignore[arg-type]
    ))


def _auth(country: str = "IN", acct: str = "acc1") -> dict[str, str]:
    return {"Authorization": f"Bearer good-{country}-{acct}"}


def _manifest(acct: str, size: int = 2048) -> str:
    return Manifest(
        pack_id="pk", org_id=acct, created_at="t",
        tarball_key=f"data/{acct}/7y/pk.tar", tarball_sha256="a" * 64,
        tarball_bytes=size, retention_class=RetentionClass.SEVEN_YEAR, legal_hold=False,
        files=[FileEntry("docs/f.pdf", 512, 1024, "b" * 64, "t")],
    ).to_json()


def test_health() -> None:
    assert _client().get("/v1/health").json()["service"] == "ingest"


def test_upload_url_uses_account_region_not_request() -> None:
    # Key encodes country=IN -> region ap-south-1 comes from identity, no request country.
    resp = _client().post("/v1/packs/upload-url",
                          json={"tarball_key": "data/acc1/7y/pk.tar"}, headers=_auth("IN"))
    assert resp.status_code == 200
    assert resp.json()["url"].startswith("https://s3.example/")


def test_upload_url_requires_auth() -> None:
    assert _client().post("/v1/packs/upload-url",
                          json={"tarball_key": "data/acc1/7y/pk.tar"}).status_code == 401


def test_complete_checks_quota_then_registers() -> None:
    c = _client(allow_quota=True)
    resp = c.post("/v1/packs/complete", json={"manifest_json": _manifest("acc1")},
                  headers=_auth("IN", "acc1"))
    assert resp.status_code == 200
    assert resp.json()["pack_id"] == "pk"


def test_complete_denied_when_quota_exceeded() -> None:
    c = _client(allow_quota=False)
    resp = c.post("/v1/packs/complete", json={"manifest_json": _manifest("acc1")},
                  headers=_auth("IN", "acc1"))
    assert resp.status_code == 402


def test_complete_rejects_other_org_manifest() -> None:
    c = _client()
    # authed as acc1 but manifest is for acc2 -> 403
    resp = c.post("/v1/packs/complete", json={"manifest_json": _manifest("acc2")},
                  headers=_auth("IN", "acc1"))
    assert resp.status_code == 403


def test_find_file_after_complete() -> None:
    c = _client()
    c.post("/v1/packs/complete", json={"manifest_json": _manifest("acc1")},
           headers=_auth("IN", "acc1"))
    resp = c.get("/v1/files?path=docs/f.pdf", headers=_auth("IN", "acc1"))
    assert resp.status_code == 200
    assert resp.json()["offset"] == 512


class FakeAudit:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def record(self, event: Any) -> None:
        self.events.append(event)


def test_audit_records_upload_and_register() -> None:
    s3 = FakeS3()
    aud = FakeAudit()
    c = TestClient(build_ingest_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        billing=FakeBilling(True),  # type: ignore[arg-type]
        storage_for_country=lambda cc: Storage(regions.resolve(cc), s3=s3),  # type: ignore[arg-type]
        audit=aud,  # type: ignore[arg-type]
    ))
    c.post("/v1/packs/upload-url", json={"tarball_key": "data/acc1/7y/pk.tar"},
           headers=_auth("IN", "acc1"))
    c.post("/v1/packs/complete", json={"manifest_json": _manifest("acc1")},
           headers=_auth("IN", "acc1"))
    actions = [e.action for e in aud.events]
    assert "pack.upload_url" in actions
    assert "pack.register" in actions
    # actor is the authenticated account, and the register event carries bytes.
    reg = next(e for e in aud.events if e.action == "pack.register")
    assert reg.actor == "acc1"
    assert reg.detail["pack_id"] == "pk"



def test_complete_bad_manifest_returns_400() -> None:
    # Malformed/incomplete manifest JSON -> 400, not a raw 500.
    c = _client()
    resp = c.post("/v1/packs/complete", json={"manifest_json": "{}"},
                  headers=_auth("IN", "acc1"))
    assert resp.status_code == 400
