"""Tests for the CLI pack command (no AWS needed)."""
import os

from deeparchive.services.cli import main


def test_pack_command_creates_tarballs(tmp_path: object) -> None:
    base = str(tmp_path)
    src = os.path.join(base, "src")
    out = os.path.join(base, "out")
    os.makedirs(src)
    with open(os.path.join(src, "a.txt"), "wb") as f:
        f.write(b"hello" * 100)

    rc = main(["pack", src, out, "--org", "acme", "--retention", "7y"])
    assert rc == 0

    tarballs = [n for n in os.listdir(out) if n.endswith(".tar")]
    manifests = [n for n in os.listdir(out) if n.endswith(".manifest.json")]
    assert len(tarballs) == 1
    assert len(manifests) == 1


def test_pack_empty_dir_returns_error(tmp_path: object) -> None:
    base = str(tmp_path)
    src = os.path.join(base, "empty")
    os.makedirs(src)
    rc = main(["pack", src, os.path.join(base, "out"), "--org", "acme"])
    assert rc == 1
