"""Tests for the billing microservice (public + internal quota)."""
from fastapi.testclient import TestClient

from deeparchive.services.api.auth import KeyStore
from deeparchive.services.billing_svc import build_billing_app

_GB = 1024 * 1024 * 1024


def _client() -> tuple[TestClient, KeyStore]:
    keys = KeyStore()
    keys.add_key("k", org_id="hdfc")
    return TestClient(build_billing_app(key_store=keys)), keys


def test_health() -> None:
    c, _ = _client()
    assert c.get("/v1/health").json()["service"] == "billing"


def test_quota_denied_without_plan() -> None:
    c, _ = _client()
    resp = c.post("/internal/quota", json={"account_id": "hdfc", "size_bytes": _GB})
    assert resp.json()["allowed"] is False


def test_purchase_then_quota_allowed() -> None:
    c, _ = _client()
    c.post("/v1/billing/purchase",
           json={"plan_id": "individual-100-30y", "payment_token": "tok"},
           headers={"Authorization": "Bearer k"})
    ok = c.post("/internal/quota", json={"account_id": "hdfc", "size_bytes": 10 * _GB})
    assert ok.json()["allowed"] is True
    # Over remaining quota -> denied.
    over = c.post("/internal/quota", json={"account_id": "hdfc", "size_bytes": 200 * _GB})
    assert over.json()["allowed"] is False


class FakeNotifier:
    def __init__(self) -> None:
        self.sent: list[object] = []

    def send(self, message: object) -> None:
        self.sent.append(message)


def _client_with_notifier(notifier: FakeNotifier) -> TestClient:
    from deeparchive.billing import UsageMeter, make_entitlement
    from deeparchive.billing.plans import CATALOG, PlanId

    keys = KeyStore()
    keys.add_key("k", org_id="hdfc")
    meter = UsageMeter()
    # Give hdfc a 100 GB plan so we can push usage over 90%.
    meter.set_entitlement(make_entitlement("hdfc", CATALOG[PlanId("individual-100-30y")]))
    return TestClient(build_billing_app(
        key_store=keys, meter=meter,
        notifier=notifier,
        notify_email_for=lambda acct: f"{acct}@example.com",
    ))


def test_quota_low_notification_fires_over_threshold() -> None:
    n = FakeNotifier()
    c = _client_with_notifier(n)
    # 100 GB plan; upload 95 GB -> 95% -> crosses the 90% threshold -> notify.
    resp = c.post("/internal/quota", json={"account_id": "hdfc", "size_bytes": 95 * _GB})
    assert resp.json()["allowed"] is True
    assert len(n.sent) == 1
    assert n.sent[0].to == "hdfc@example.com"  # type: ignore[attr-defined]


def test_quota_low_not_fired_under_threshold() -> None:
    n = FakeNotifier()
    c = _client_with_notifier(n)
    # 10 GB of 100 GB = 10% -> no notification.
    c.post("/internal/quota", json={"account_id": "hdfc", "size_bytes": 10 * _GB})
    assert n.sent == []


def test_payment_failed_notification_fires() -> None:
    n = FakeNotifier()
    c = _client_with_notifier(n)
    # Start a subscription so mark_past_due has something to flip.
    c.post("/v1/billing/subscribe",
           json={"plan_id": "individual-100-30y", "payment_token": "tok"},
           headers={"Authorization": "Bearer k"})
    resp = c.post("/v1/billing/webhook", json={
        "event_type": "invoice.payment_failed", "account_id": "hdfc",
        "plan_id": "individual-100-30y", "units": 1,
    })
    assert resp.json()["status"] == "past_due"
    assert any(getattr(m, "subject", "").lower().find("payment") >= 0 for m in n.sent)
