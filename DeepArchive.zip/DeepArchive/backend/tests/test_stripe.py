"""Tests for Stripe-backed payments + country method routing."""
import sys
import types

import pytest

from deeparchive.billing import (
    PaymentError,
    PaymentProcessor,
    PayMethod,
    RoutingProcessor,
    StripeProcessor,
    method_for_country,
)


def test_routing_by_country() -> None:
    assert method_for_country("IN") is PayMethod.UPI
    assert method_for_country("BR") is PayMethod.PIX
    assert method_for_country("US") is PayMethod.CARD
    assert method_for_country("DE") is PayMethod.CARD


def test_stripe_processor_is_a_payment_processor() -> None:
    assert isinstance(StripeProcessor(api_key="sk_test_x"), PaymentProcessor)
    assert isinstance(RoutingProcessor(api_key="sk_test_x"), PaymentProcessor)


def _install_fake_stripe(monkeypatch, captured: dict[str, object]) -> None:  # type: ignore[no-untyped-def]
    class PaymentIntent:
        @staticmethod
        def create(**kwargs: object) -> dict[str, object]:
            captured.update(kwargs)
            return {"id": "pi_test_123"}

    fake = types.ModuleType("stripe")
    fake.api_key = ""  # type: ignore[attr-defined]
    fake.PaymentIntent = PaymentIntent  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "stripe", fake)


def test_stripe_charge_uses_routed_method(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    captured: dict[str, object] = {}
    _install_fake_stripe(monkeypatch, captured)

    router = RoutingProcessor(api_key="sk_test_x")
    charge = router.charge_for_country("IN", "acc_1", 5000, token="pm_tok")
    assert charge.charge_id == "pi_test_123"
    assert charge.amount_cents == 5000
    # India routed to UPI.
    assert captured["payment_method_types"] == ["upi"]


def test_stripe_charge_defaults_to_card(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    captured: dict[str, object] = {}
    _install_fake_stripe(monkeypatch, captured)
    RoutingProcessor(api_key="sk_test_x").charge_for_country("US", "acc_1", 5000, "pm")
    assert captured["payment_method_types"] == ["card"]


def test_stripe_charge_failure_raises_payment_error(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    class PaymentIntent:
        @staticmethod
        def create(**kwargs: object) -> dict[str, object]:
            raise RuntimeError("card_declined")

    fake = types.ModuleType("stripe")
    fake.api_key = ""  # type: ignore[attr-defined]
    fake.PaymentIntent = PaymentIntent  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "stripe", fake)

    with pytest.raises(PaymentError):
        StripeProcessor(api_key="sk_test_x").charge("acc_1", 5000, "pm")
