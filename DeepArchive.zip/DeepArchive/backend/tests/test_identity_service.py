"""Tests for the identity microservice (public + internal endpoints)."""
from typing import Any

from fastapi.testclient import TestClient

from deeparchive.services.identity import build_identity_app


def _client() -> TestClient:
    return TestClient(build_identity_app())


class FakeAudit:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def record(self, event: Any) -> None:
        self.events.append(event)


def test_audit_records_failed_auth_only() -> None:
    aud = FakeAudit()
    c = TestClient(build_identity_app(audit=aud))  # type: ignore[arg-type]
    org = c.post("/v1/orgs",
                 json={"name": "HDFC", "country": "IN", "admin_user_ref": "a@h"}).json()
    # A successful validate is NOT audited (high-volume, called every request).
    c.post("/internal/validate", json={"api_key": org["api_key"]})
    assert aud.events == []
    # A failed validate IS audited (security signal).
    c.post("/internal/validate", json={"api_key": "dak_bogus"})
    assert [e.action for e in aud.events] == ["auth.failed"]


def test_health() -> None:
    assert _client().get("/v1/health").json()["service"] == "identity"


def test_org_creation_and_me() -> None:
    c = _client()
    org = c.post("/v1/orgs",
                 json={"name": "HDFC", "country": "IN", "admin_user_ref": "a@h"}).json()
    me = c.get("/v1/accounts/me", headers={"Authorization": f"Bearer {org['api_key']}"})
    assert me.status_code == 200
    assert me.json()["region"] == "ap-south-1"


def test_internal_validate_returns_account_and_country() -> None:
    c = _client()
    org = c.post("/v1/orgs",
                 json={"name": "HDFC", "country": "IN", "admin_user_ref": "a@h"}).json()
    resp = c.post("/internal/validate", json={"api_key": org["api_key"]})
    assert resp.status_code == 200
    body = resp.json()
    assert body["account_id"] == org["account_id"]
    assert body["country"] == "IN"


def test_internal_validate_rejects_bad_key() -> None:
    resp = _client().post("/internal/validate", json={"api_key": "nope"})
    assert resp.status_code == 401


def test_internal_region_lookup() -> None:
    c = _client()
    org = c.post("/v1/orgs",
                 json={"name": "HDFC", "country": "US", "admin_user_ref": "a@h"}).json()
    resp = c.get(f"/internal/region/{org['account_id']}")
    assert resp.status_code == 200
    assert resp.json()["country"] == "US"



def test_org_creation_unserved_region_returns_422() -> None:
    # Strict residency: NG has no in-country region -> 422, not a raw 500.
    c = _client()
    resp = c.post("/v1/orgs",
                  json={"name": "X", "country": "NG", "admin_user_ref": "x@x.com"})
    assert resp.status_code == 422
