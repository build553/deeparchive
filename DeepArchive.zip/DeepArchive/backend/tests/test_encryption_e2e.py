"""End-to-end: encrypted upload -> restore -> decrypt -> verify."""
import os

from deeparchive import regions
from deeparchive.crypto import LocalKeyStore
from deeparchive.manifest import Manifest, RetentionClass
from deeparchive.packer import Pack, SourceFile, pack
from deeparchive.restore import (
    RestoreState,
    check_restore,
    download_verify,
    request_restore,
)
from deeparchive.storage import Storage


class FakeEncryptingS3:
    """Fake S3 that stores uploaded bytes and serves them back for restore."""

    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def upload_file(self, Filename, Bucket, Key, Config=None):  # type: ignore[no-untyped-def]  # noqa: N803
        with open(Filename, "rb") as f:
            self.objects[Key] = f.read()

    def put_object(self, Bucket, Key, Body):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Restore": 'ongoing-request="false"'}

    def download_file(self, Bucket, Key, dest):  # type: ignore[no-untyped-def]  # noqa: N803
        with open(dest, "wb") as f:
            f.write(self.objects[Key])


def _one_pack(base: str) -> Pack:
    src = os.path.join(base, "f.bin")
    with open(src, "wb") as f:
        f.write(b"top secret archive contents" * 100)
    files = [SourceFile(src, "f.bin", RetentionClass.SEVEN_YEAR)]
    return pack(files, out_dir=os.path.join(base, "out"), org_id="hdfc")[0]


def test_encrypted_upload_then_restore_decrypts_and_verifies(tmp_path: object) -> None:
    base = str(tmp_path)
    fake = FakeEncryptingS3()
    keystore = LocalKeyStore(os.path.join(base, "keys.json"))
    storage = Storage(regions.resolve("IN"), s3=fake, key_store=keystore)  # type: ignore[arg-type]

    p = _one_pack(base)
    plaintext_sha = p.manifest.tarball_sha256
    storage.upload_pack(p)

    # Stored bytes are ciphertext (not equal to the plaintext tarball on disk).
    with open(p.tarball_path, "rb") as f:
        assert fake.objects[p.manifest.tarball_key] != f.read()

    # The manifest that was uploaded carries the nonce.
    manifest_key = f"db/hdfc/{p.manifest.pack_id}.json"
    stored_manifest = Manifest.from_json(fake.objects[manifest_key].decode())
    assert stored_manifest.encryption_nonce != ""
    assert stored_manifest.tarball_sha256 == plaintext_sha

    # Restore -> download -> decrypt -> verify.
    job = request_restore(storage, stored_manifest.tarball_key)
    job = check_restore(storage, job)
    assert job.state is RestoreState.READY
    dest = os.path.join(base, "restored.tar")
    download_verify(storage, job, stored_manifest, dest)  # raises if integrity fails

    # Decrypted file matches the original plaintext tarball.
    with open(dest, "rb") as f1, open(p.tarball_path, "rb") as f2:
        assert f1.read() == f2.read()
