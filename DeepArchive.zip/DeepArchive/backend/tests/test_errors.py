"""Tests for the storage error taxonomy and boto3 error translation."""
import os

import pytest
from botocore.exceptions import ClientError, EndpointConnectionError

from deeparchive import regions
from deeparchive.manifest import RetentionClass
from deeparchive.packer import Pack, SourceFile, pack
from deeparchive.storage import (
    PermanentStorageError,
    Storage,
    TransientStorageError,
)
from deeparchive.storage.errors import classify


def test_classify_transient_code() -> None:
    err = ClientError({"Error": {"Code": "SlowDown"}}, "PutObject")
    assert isinstance(classify(err), TransientStorageError)


def test_classify_permanent_code() -> None:
    err = ClientError({"Error": {"Code": "AccessDenied"}}, "PutObject")
    assert isinstance(classify(err), PermanentStorageError)


def test_classify_connection_error_is_transient() -> None:
    err = EndpointConnectionError(endpoint_url="https://s3")
    assert isinstance(classify(err), TransientStorageError)


class RaisingS3:
    """Fake S3 whose upload raises a permanent ClientError."""

    def upload_file(self, Filename, Bucket, Key, Config=None):  # type: ignore[no-untyped-def]  # noqa: N803
        raise ClientError({"Error": {"Code": "AccessDenied"}}, "PutObject")


def _one_pack(tmp_path: object) -> Pack:
    base = str(tmp_path)
    src = os.path.join(base, "f.bin")
    with open(src, "wb") as f:
        f.write(b"data" * 10)
    files = [SourceFile(src, "f.bin", RetentionClass.SEVEN_YEAR)]
    return pack(files, out_dir=os.path.join(base, "out"), org_id="acme")[0]


def test_storage_translates_client_error(tmp_path: object) -> None:
    storage = Storage(regions.resolve("US"), s3=RaisingS3())  # type: ignore[arg-type]
    with pytest.raises(PermanentStorageError):
        storage.upload_pack(_one_pack(tmp_path))
