"""Tests for DdbAccountStore using moto (offline DynamoDB)."""
import time

import boto3
import pytest
from moto import mock_aws

from deeparchive.accounts.accounts import Account, AccountType
from deeparchive.persistence import create_tables
from deeparchive.persistence.account_store import DdbAccountStore


def _account(**kw: object) -> Account:
    base = {
        "account_id": "acc_1",
        "account_type": AccountType.INDIVIDUAL,
        "country": "US",
        "region": "us-east-1",
        "created_at": time.time(),
    }
    base.update(kw)
    return Account(**base)  # type: ignore[arg-type]


@mock_aws
def test_put_get_round_trip() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbAccountStore(resource=res)

    acc = _account(email="u@example.com", phone="+15551112222")
    store.put(acc)
    got = store.get("acc_1")
    assert got.account_id == "acc_1"
    assert got.email == "u@example.com"
    assert got.account_type is AccountType.INDIVIDUAL


@mock_aws
def test_lookups_via_gsi() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbAccountStore(resource=res)

    store.put(_account(account_id="acc_e", email="Find@Me.com"))
    store.put(_account(account_id="acc_p", phone="+19998887777"))
    store.put(_account(account_id="acc_s", provider="google", provider_user_id="g-9"))

    assert store.find_by_email("find@me.com").account_id == "acc_e"  # type: ignore[union-attr]
    assert store.find_by_phone("+19998887777").account_id == "acc_p"  # type: ignore[union-attr]
    assert store.find_by_provider("google", "g-9").account_id == "acc_s"  # type: ignore[union-attr]
    assert store.find_by_email("nobody@nowhere.com") is None


@mock_aws
def test_missing_account_raises() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    store = DdbAccountStore(resource=res)
    with pytest.raises(KeyError):
        store.get("acc_missing")


@mock_aws
def test_persists_across_store_instances() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    DdbAccountStore(resource=res).put(_account(account_id="acc_persist"))
    # A brand-new store instance (simulating a restart) reads it back.
    reloaded = DdbAccountStore(resource=res).get("acc_persist")
    assert reloaded.account_id == "acc_persist"
