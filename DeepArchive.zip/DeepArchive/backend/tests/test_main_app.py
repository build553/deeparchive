"""Tests for the assembled main app (core + accounts, factory-backed)."""
from fastapi.testclient import TestClient

from deeparchive.services.api.main import build_app, storage_mode


def test_main_app_has_core_and_accounts(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.delenv("DEEPARCHIVE_USE_DDB", raising=False)
    monkeypatch.setattr("deeparchive.config.DDB_ENDPOINT_URL", None)
    client = TestClient(build_app())

    # Core endpoint present.
    assert client.get("/v1/health").json() == {"status": "ok"}
    # Registration endpoint present + working (org creation -> me).
    org = client.post(
        "/v1/orgs", json={"name": "HDFC", "country": "IN", "admin_user_ref": "cto@hdfc"}
    ).json()
    me = client.get("/v1/accounts/me",
                    headers={"Authorization": f"Bearer {org['api_key']}"})
    assert me.status_code == 200
    assert me.json()["region"] == "ap-south-1"


def test_storage_mode_reflects_config(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.delenv("DEEPARCHIVE_USE_DDB", raising=False)
    assert storage_mode() == "in-memory"
    monkeypatch.setenv("DEEPARCHIVE_USE_DDB", "1")
    assert storage_mode() == "dynamodb"


def test_payment_mode_reflects_stripe_key(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    from deeparchive.services.api.main import payment_mode

    monkeypatch.setattr("deeparchive.config.STRIPE_API_KEY", "")
    assert payment_mode() == "fake"
    monkeypatch.setattr("deeparchive.config.STRIPE_API_KEY", "sk_live_x")
    assert payment_mode() == "stripe"
