"""Tests for social/OIDC sign-in with a fake verifier."""
import os

import pytest

from deeparchive.accounts import AccountService, AccountStore
from deeparchive.accounts.social import AuthError, FakeVerifier, SocialAuth
from deeparchive.crypto import LocalKeyStore
from deeparchive.services.api.auth import KeyStore as ApiKeyStore


def _social(tmp_path: object) -> tuple[SocialAuth, FakeVerifier]:
    svc = AccountService(
        accounts=AccountStore(),
        api_keys=ApiKeyStore(),
        crypto_keys=LocalKeyStore(os.path.join(str(tmp_path), "keys.json")),
    )
    google = FakeVerifier(provider="google")
    return SocialAuth(accounts=svc, verifiers={"google": google}), google


def test_new_user_creates_account(tmp_path: object) -> None:
    social, google = _social(tmp_path)
    google.register_token("tok-1", user_id="g-123", email="user@gmail.com")

    created, account_id = social.sign_in("google", "tok-1", country="US")
    assert created is not None                     # new account
    assert account_id.startswith("acc_")
    assert created.api_key.startswith("dak_")      # one-time api key surfaced
    assert created.account.provider == "google"


def test_returning_user_reuses_account(tmp_path: object) -> None:
    social, google = _social(tmp_path)
    google.register_token("tok-1", user_id="g-123", email="user@gmail.com")

    _, first_id = social.sign_in("google", "tok-1", country="US")
    created2, second_id = social.sign_in("google", "tok-1", country="US")
    assert created2 is None                        # not a new account
    assert first_id == second_id                   # same account_id


def test_invalid_token_rejected(tmp_path: object) -> None:
    social, _ = _social(tmp_path)
    with pytest.raises(AuthError):
        social.sign_in("google", "bad-token", country="US")


def test_unsupported_provider_rejected(tmp_path: object) -> None:
    social, _ = _social(tmp_path)
    with pytest.raises(AuthError):
        social.sign_in("myspace", "tok", country="US")
