"""Tests for the gateway edge: routing + retry-with-failover."""
from typing import Any

from fastapi.testclient import TestClient

from deeparchive.services.gateway import build_gateway_app, route_for


def test_route_map() -> None:
    assert route_for("/v1/accounts/me") == "identity"
    assert route_for("/v1/orgs") == "identity"
    assert route_for("/scim/v2/Users") == "identity"
    assert route_for("/v1/billing/account") == "billing"
    assert route_for("/v1/packs/upload-url") == "ingest"
    assert route_for("/v1/files") == "ingest"
    assert route_for("/v1/thumbnails/x.jpg") == "ingest"
    assert route_for("/v1/catalog") == "metadata"
    assert route_for("/v1/folders") == "metadata"
    assert route_for("/v1/files/statements/jan.pdf/content") == "metadata"
    assert route_for("/v1/files") == "ingest"
    assert route_for("/v1/restore") == "restore"
    assert route_for("/v1/unknown") is None


def test_gateway_health() -> None:
    assert TestClient(build_gateway_app()).get("/v1/health").json()["service"] == "gateway"


class Resp:
    def __init__(self, status: int, payload: Any = None) -> None:
        self.status_code = status
        self._p = payload if payload is not None else {}
        self.text = ""

    def json(self) -> Any:
        return self._p


class SeqHttp:
    """Returns a queued sequence of responses/exceptions across instances."""

    def __init__(self, seq: list[Any]) -> None:
        self._seq = seq
        self.calls: list[str] = []

    def request(self, method, url, headers=None, params=None, content=None):  # type: ignore[no-untyped-def]
        self.calls.append(url)
        item = self._seq[min(len(self.calls) - 1, len(self._seq) - 1)]
        if isinstance(item, Exception):
            raise item
        return item


def _client(seq: list[Any], monkeypatch) -> TestClient:  # type: ignore[no-untyped-def]
    # Give billing a distinct remote instance so there are 2 to fail over between.
    monkeypatch.setenv("DEEPARCHIVE_BILLING_URL", "http://billing.internal")
    return TestClient(build_gateway_app(http=SeqHttp(seq)))


def test_routes_and_returns_ok(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    c = _client([Resp(200, {"active": True})], monkeypatch)
    r = c.get("/v1/billing/account")
    assert r.status_code == 200
    assert r.json()["active"] is True


def test_500_fails_over_to_next_instance(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    # First instance 500s, second returns 200 -> gateway serves the 200.
    c = _client([Resp(500, {"detail": "boom"}), Resp(200, {"active": True})], monkeypatch)
    r = c.get("/v1/billing/account")
    assert r.status_code == 200
    assert r.json()["active"] is True


def test_connection_error_fails_over(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    c = _client([ConnectionError("down"), Resp(200, {"ok": True})], monkeypatch)
    r = c.get("/v1/billing/account")
    assert r.status_code == 200


def test_all_instances_down_returns_503(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    c = _client([ConnectionError("down"), ConnectionError("down")], monkeypatch)
    r = c.get("/v1/billing/account")
    assert r.status_code == 503


def test_all_500_returns_the_500(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    c = _client([Resp(500, {"detail": "boom"}), Resp(500, {"detail": "boom"})], monkeypatch)
    r = c.get("/v1/billing/account")
    assert r.status_code == 500


def test_unknown_route_404(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    c = _client([Resp(200)], monkeypatch)
    assert c.get("/v1/nonsense").status_code == 404
