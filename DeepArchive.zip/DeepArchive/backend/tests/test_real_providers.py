"""Tests for the real providers (SNS SMS sender, Google verifier wiring)."""
from deeparchive.accounts import GoogleTokenVerifier, SnsCodeSender, TokenVerifier
from deeparchive.accounts.otp import CodeSender


class FakeSns:
    def __init__(self) -> None:
        self.published: list[dict[str, str]] = []

    def publish(self, PhoneNumber: str, Message: str) -> None:  # noqa: N803
        self.published.append({"phone": PhoneNumber, "message": Message})


def test_sns_sender_publishes_sms() -> None:
    sns = FakeSns()
    sender = SnsCodeSender(region="us-east-1", sns=sns)
    assert isinstance(sender, CodeSender)
    sender.send("+15551234567", "123456")
    assert sns.published[0]["phone"] == "+15551234567"
    assert "123456" in sns.published[0]["message"]


def test_google_verifier_is_a_token_verifier() -> None:
    # Interface wiring only (real verification requires a live Google token).
    verifier = GoogleTokenVerifier(client_id="my-client-id.apps.googleusercontent.com")
    assert isinstance(verifier, TokenVerifier)


def test_facebook_and_apple_verifiers_are_token_verifiers() -> None:
    from deeparchive.accounts import AppleTokenVerifier, FacebookTokenVerifier

    fb = FacebookTokenVerifier(app_id="123", app_secret="shh")
    apple = AppleTokenVerifier(client_id="com.example.app")
    assert isinstance(fb, TokenVerifier)
    assert isinstance(apple, TokenVerifier)
