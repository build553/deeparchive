"""Tests for local-first / remote-fallback internal routing."""
from typing import Any

import pytest

from deeparchive.services.internal_client import (
    BillingClient,
    IdentityClient,
    _Resolver,
)


class Resp:
    def __init__(self, status: int, payload: Any = None) -> None:
        self.status_code = status
        self._p = payload or {}

    def json(self) -> Any:
        return self._p


class ScriptedHttp:
    """Routes by URL host: local (127.0.0.1) vs remote. Each can be up/down."""

    def __init__(self, local_up: bool = True, remote_up: bool = True) -> None:
        self.local_up = local_up
        self.remote_up = remote_up
        self.calls: list[str] = []

    def request(self, method, url, headers=None, json=None):  # type: ignore[no-untyped-def]
        self.calls.append(url)
        is_local = "127.0.0.1" in url
        up = self.local_up if is_local else self.remote_up
        if not up:
            raise ConnectionError("down")
        if url.endswith("/v1/health"):
            return Resp(200, {"status": "ok"})
        if url.endswith("/internal/validate"):
            return Resp(200, {"account_id": "acc1", "country": "IN"})
        if url.endswith("/internal/quota"):
            return Resp(200, {"allowed": True})
        return Resp(200, {})


@pytest.fixture(autouse=True)
def _remote_dns(monkeypatch):  # type: ignore[no-untyped-def]
    # Give each service a DISTINCT remote (cluster) URL so local != remote.
    for svc in ("identity", "billing"):
        monkeypatch.setenv(f"DEEPARCHIVE_{svc.upper()}_URL", f"http://{svc}.internal")


def test_uses_local_when_healthy() -> None:
    http = ScriptedHttp(local_up=True, remote_up=True)
    IdentityClient(http).validate("k")
    # The validate call went to the LOCAL instance.
    validate_calls = [u for u in http.calls if u.endswith("/internal/validate")]
    assert validate_calls and "127.0.0.1" in validate_calls[0]


def test_fails_over_to_remote_when_local_down() -> None:
    http = ScriptedHttp(local_up=False, remote_up=True)
    result = IdentityClient(http).validate("k")
    assert result["account_id"] == "acc1"
    validate_calls = [u for u in http.calls if u.endswith("/internal/validate")]
    # It reached a non-local (remote) instance.
    assert any("127.0.0.1" not in u for u in validate_calls)


def test_raises_when_both_down() -> None:
    http = ScriptedHttp(local_up=False, remote_up=False)
    with pytest.raises(ConnectionError):
        IdentityClient(http).validate("k")


def test_health_is_cached() -> None:
    http = ScriptedHttp(local_up=True)
    r = _Resolver(http, health_ttl=100.0)
    r.bases("identity")  # first -> probes health
    probes_after_first = sum(1 for u in http.calls if u.endswith("/v1/health"))
    r.bases("identity")  # second -> should use cache, no new probe
    probes_after_second = sum(1 for u in http.calls if u.endswith("/v1/health"))
    assert probes_after_first == probes_after_second == 1


def test_billing_check_quota_local_first() -> None:
    http = ScriptedHttp(local_up=True)
    assert BillingClient(http).check_quota("acc1", 1000) is True
    quota_calls = [u for u in http.calls if u.endswith("/internal/quota")]
    assert quota_calls and "127.0.0.1" in quota_calls[0]
