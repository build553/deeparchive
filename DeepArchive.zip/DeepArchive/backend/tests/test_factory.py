"""Tests for the store factory (in-memory default, DDB when configured)."""
import boto3
from moto import mock_aws

from deeparchive.accounts.accounts import AccountStore
from deeparchive.accounts.orgs import OrgStore
from deeparchive.persistence import create_tables, factory
from deeparchive.persistence.account_store import DdbAccountStore
from deeparchive.persistence.org_store import DdbOrgStore


def test_defaults_to_in_memory(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.delenv("DEEPARCHIVE_USE_DDB", raising=False)
    monkeypatch.setattr("deeparchive.config.DDB_ENDPOINT_URL", None)
    assert isinstance(factory.account_store(), AccountStore)
    assert isinstance(factory.org_store(), OrgStore)


@mock_aws
def test_uses_ddb_when_enabled(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setenv("DEEPARCHIVE_USE_DDB", "1")
    res = boto3.resource("dynamodb", region_name="us-east-1")
    create_tables(res)
    assert isinstance(factory.account_store(resource=res), DdbAccountStore)
    assert isinstance(factory.org_store(resource=res), DdbOrgStore)
