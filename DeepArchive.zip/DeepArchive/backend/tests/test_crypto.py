"""Tests for per-customer encryption and the local key store."""
import os

import pytest
from cryptography.exceptions import InvalidTag

from deeparchive.crypto import LocalKeyStore, decrypt, encrypt


def test_encrypt_decrypt_round_trip() -> None:
    key = os.urandom(32)
    data = b"important archive bytes" * 100
    enc = encrypt(data, key)
    assert enc.ciphertext != data
    assert decrypt(enc.ciphertext, key, enc.nonce) == data


def test_tampered_ciphertext_rejected() -> None:
    key = os.urandom(32)
    enc = encrypt(b"secret", key)
    tampered = bytes([enc.ciphertext[0] ^ 0xFF]) + enc.ciphertext[1:]
    with pytest.raises(InvalidTag):
        decrypt(tampered, key, enc.nonce)


def test_wrong_key_rejected() -> None:
    enc = encrypt(b"secret", os.urandom(32))
    with pytest.raises(InvalidTag):
        decrypt(enc.ciphertext, os.urandom(32), enc.nonce)


def test_key_must_be_256_bit() -> None:
    with pytest.raises(ValueError):
        encrypt(b"x", b"tooshort")


def test_keystore_one_key_per_customer(tmp_path: object) -> None:
    store = LocalKeyStore(os.path.join(str(tmp_path), "keys.json"))
    k_hdfc = store.get_or_create_key("hdfc")
    k_icici = store.get_or_create_key("icici")
    assert k_hdfc != k_icici                       # different customers, different keys
    assert store.get_or_create_key("hdfc") == k_hdfc  # stable per customer
    assert len(k_hdfc) == 32


def test_keystore_persists_across_instances(tmp_path: object) -> None:
    path = os.path.join(str(tmp_path), "keys.json")
    k1 = LocalKeyStore(path).get_or_create_key("hdfc")
    k2 = LocalKeyStore(path).get_key("hdfc")  # new instance reads same file
    assert k1 == k2
    assert oct(os.stat(path).st_mode)[-3:] == "600"  # locked-down perms
