"""Tests for billing plans + entitlements (cost + 50% margin pricing)."""
from deeparchive.billing import CATALOG, PlanId, make_entitlement
from deeparchive.billing.plans import (
    MARGIN_MONTHLY,
    MARGIN_PREPAID_30Y,
    price_cents,
)

_GB = 1024 * 1024 * 1024


def test_price_is_cost_plus_margin() -> None:
    plan = CATALOG[PlanId.INDIVIDUAL_100_30Y]
    expected = price_cents(plan.quota_bytes, plan.duration_seconds, MARGIN_PREPAID_30Y)
    assert plan.price_usd_cents == expected


def test_margins_are_70_monthly_50_prepaid() -> None:
    assert MARGIN_MONTHLY == 0.70
    assert MARGIN_PREPAID_30Y == 0.50


def test_monthly_plan_exists_and_priced_at_70_margin() -> None:
    plan = CATALOG[PlanId.INDIVIDUAL_100_MONTHLY]
    assert plan.billing_period == "monthly"
    assert plan.price_usd_cents == price_cents(
        plan.quota_bytes, plan.duration_seconds, MARGIN_MONTHLY
    )


def test_prepaid_30y_is_one_time() -> None:
    assert CATALOG[PlanId.INDIVIDUAL_100_30Y].billing_period == "one-time"


def test_price_scales_with_size_and_duration() -> None:
    small = price_cents(50 * _GB, 15 * 365 * 24 * 3600)
    big = price_cents(100 * _GB, 30 * 365 * 24 * 3600)
    assert big > small  # more GB + longer term = higher price


def test_individual_price_around_56_usd() -> None:
    # Sanity: 100GB/30yr lands near $56 (raw storage ~$35.64 + overhead, +50%).
    cents = CATALOG[PlanId.INDIVIDUAL_100_30Y].price_usd_cents
    assert 5000 <= cents <= 6000


def test_make_entitlement_sets_quota_and_expiry() -> None:
    plan = CATALOG[PlanId.INDIVIDUAL_100_30Y]
    ent = make_entitlement("acc_1", plan, now=1000.0)
    assert ent.quota_bytes == 100 * _GB
    assert ent.expires_at == 1000.0 + plan.duration_seconds
    assert ent.is_active(now=1000.0)
    assert not ent.is_active(now=ent.expires_at + 1)


def test_org_plan_scales_by_units() -> None:
    plan = CATALOG[PlanId.ORG_PER_TB_30Y]
    ent = make_entitlement("acc_org", plan, units=5, now=0.0)  # 5 TB-years
    assert ent.quota_bytes == plan.quota_bytes * 5
