"""Tests for the block dedup index (dedup + delta)."""
from deeparchive.blocks import BlockIndex, split


def test_which_new_all_new_first_time() -> None:
    idx = BlockIndex()
    hashes = ["a" * 64, "b" * 64, "c" * 64]
    assert idx.which_new(hashes) == hashes


def test_which_new_skips_stored() -> None:
    idx = BlockIndex()
    idx.add_file(["a" * 64, "b" * 64], sizes={})
    # a,b already stored; only c is new.
    assert idx.which_new(["a" * 64, "b" * 64, "c" * 64]) == ["c" * 64]


def test_which_new_dedups_within_input() -> None:
    idx = BlockIndex()
    dup = "a" * 64
    assert idx.which_new([dup, dup, dup]) == [dup]  # uploaded once


def test_add_file_reports_dedup_stats() -> None:
    idx = BlockIndex()
    a, b, c = "a" * 64, "b" * 64, "c" * 64
    idx.add_file([a, b], sizes={a: 100, b: 200})
    # Second file shares a, adds c -> 1 deduped, 1 new.
    stats = idx.add_file([a, c], sizes={a: 100, c: 300})
    assert stats.total_blocks == 2
    assert stats.new_blocks == 1
    assert stats.deduped_blocks == 1
    assert stats.new_bytes == 300
    assert stats.deduped_bytes == 100
    assert stats.dedup_ratio == 0.5


def test_delta_reupload_unchanged_file_stores_nothing() -> None:
    # Re-archiving the SAME file uploads zero new blocks (pure delta win).
    idx = BlockIndex()
    data = b"X" * (9 * 1024 * 1024)
    hashes = [b.hash for b in split(data)]
    idx.add_file(hashes, sizes={})
    assert idx.which_new(hashes) == []


def test_delta_changed_tail_only_new_block() -> None:
    # A file whose last block changed: only that block is new.
    idx = BlockIndex()
    v1 = b"A" * (4 * 1024 * 1024) + b"B" * (4 * 1024 * 1024) + b"C" * 100
    h1 = [b.hash for b in split(v1)]
    idx.add_file(h1, sizes={})
    # v2: same first two 4MiB blocks, different tail.
    v2 = b"A" * (4 * 1024 * 1024) + b"B" * (4 * 1024 * 1024) + b"Z" * 100
    h2 = [b.hash for b in split(v2)]
    new = idx.which_new(h2)
    assert len(new) == 1  # only the changed tail block


def test_remove_file_refcount_and_droppable() -> None:
    idx = BlockIndex()
    a, b = "a" * 64, "b" * 64
    idx.add_file([a, b], sizes={})
    idx.add_file([a], sizes={})  # a now refcount 2, b refcount 1
    # Removing the first file: b hits zero (droppable), a still referenced.
    droppable = idx.remove_file([a, b])
    assert droppable == [b]
    assert idx.has(a)
    assert not idx.has(b)


def test_len_counts_unique_blocks() -> None:
    idx = BlockIndex()
    idx.add_file(["a" * 64, "b" * 64], sizes={})
    idx.add_file(["a" * 64, "c" * 64], sizes={})
    assert len(idx) == 3  # a, b, c
