"""Tests for the restore approval workflow (org egress governance)."""
import pytest

from deeparchive.accounts.approval import (
    ApprovalService,
    ApprovalState,
    NotAuthorizedError,
)
from deeparchive.accounts.orgs import Organization, Role

_GB = 1024 * 1024 * 1024


def _org() -> Organization:
    org = Organization(account_id="acc_1", name="HDFC")
    org.add_member("admin@hdfc", Role.ADMIN)
    org.add_member("clerk@hdfc", Role.MEMBER)
    return org


def test_small_restore_auto_approved() -> None:
    svc = ApprovalService(org=_org(), threshold_bytes=_GB)
    req = svc.request("clerk@hdfc", "data/acc_1/7y/p.tar", size_bytes=100 * 1024 * 1024)
    assert req.state is ApprovalState.AUTO_APPROVED
    assert svc.is_cleared(req.request_id)


def test_large_restore_needs_approval() -> None:
    svc = ApprovalService(org=_org(), threshold_bytes=_GB)
    req = svc.request("clerk@hdfc", "data/acc_1/7y/p.tar", size_bytes=5 * _GB)
    assert req.state is ApprovalState.PENDING_APPROVAL
    assert svc.is_cleared(req.request_id) is False


def test_admin_approves_large_restore() -> None:
    svc = ApprovalService(org=_org(), threshold_bytes=_GB)
    req = svc.request("clerk@hdfc", "data/acc_1/7y/p.tar", size_bytes=5 * _GB)
    approved = svc.approve(req.request_id, "admin@hdfc")
    assert approved.state is ApprovalState.APPROVED
    assert approved.decided_by == "admin@hdfc"
    assert svc.is_cleared(req.request_id)


def test_admin_rejects() -> None:
    svc = ApprovalService(org=_org(), threshold_bytes=_GB)
    req = svc.request("clerk@hdfc", "data/acc_1/7y/p.tar", size_bytes=5 * _GB)
    svc.reject(req.request_id, "admin@hdfc")
    assert svc.is_cleared(req.request_id) is False


def test_non_admin_cannot_approve() -> None:
    svc = ApprovalService(org=_org(), threshold_bytes=_GB)
    req = svc.request("clerk@hdfc", "data/acc_1/7y/p.tar", size_bytes=5 * _GB)
    with pytest.raises(NotAuthorizedError):
        svc.approve(req.request_id, "clerk@hdfc")  # member, not admin
