"""Integration: the REAL SDK client driving the REAL assembled API (offline).

The SDK's HttpClient is adapted to FastAPI's TestClient, so the actual SDK code
paths (put/flush/account/find_file) make real requests to the real app. Storage
is a fake S3, so it runs offline in CI. This locks in the SDK<->API contract.
"""
import io
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.billing import BillingService, FakeProcessor, UsageMeter
from deeparchive.sdk import Client, Config
from deeparchive.services.api.accounts_api import build_accounts_router
from deeparchive.services.api.app import create_app
from deeparchive.services.api.auth import KeyStore
from deeparchive.services.api.billing_api import build_billing_router
from deeparchive.services.api.wiring import build_accounts_deps
from deeparchive.storage import Storage


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return f"https://s3.example/{Params['Key']}?sig=x"

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def get_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Body": io.BytesIO(self.objects[Key])}

    def list_objects_v2(self, Bucket, Prefix):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Contents": [{"Key": k} for k in self.objects if k.startswith(Prefix)]}


def _build() -> tuple[TestClient, KeyStore]:
    shared = FakeS3()
    keys = KeyStore()
    meter = UsageMeter()
    deps = build_accounts_deps(api_keys=keys)
    app = create_app(
        storage_provider=lambda c: Storage(regions.resolve(c), s3=shared),  # type: ignore[arg-type]
        key_store=keys, usage_meter=meter,
    )
    app.include_router(build_accounts_router(deps))
    app.include_router(build_billing_router(
        keys, BillingService(processor=FakeProcessor(), meter=meter), meter))
    return TestClient(app), keys


class SdkOverApp:
    """Adapts the SDK's HttpClient protocol onto the app's TestClient."""

    def __init__(self, tc: TestClient) -> None:
        self._tc = tc

    def request(self, method, url, headers, json=None, content=None):  # type: ignore[no-untyped-def]
        if url.startswith("https://s3") or "?sig" in url:
            class _R:
                status_code = 200
                content = b""

                def json(self) -> dict[str, Any]:
                    return {}
            return _R()
        from urllib.parse import urlparse
        u = urlparse(url)
        path = u.path + (("?" + u.query) if u.query else "")
        return self._tc.request(method, path, headers=headers, json=json, content=content)


def test_sdk_drives_real_api_end_to_end() -> None:
    tc, _ = _build()
    # Provision an org + plan via the real API.
    org = tc.post("/v1/orgs",
                  json={"name": "HDFC", "country": "US", "admin_user_ref": "a@h"}).json()
    key, acct = org["api_key"], org["account_id"]
    tc.post("/v1/billing/purchase",
            json={"plan_id": "individual-100-30y", "payment_token": "tok"},
            headers={"Authorization": f"Bearer {key}"})

    # Drive the REAL SDK against the REAL app.
    c = Client(api_key=key, org_id=acct, config=Config(endpoint="http://app"),
               http=SdkOverApp(tc))
    acct_info = c.account()
    assert acct_info["active"] is True

    c.put("statements/jan.pdf", data=b"integration bytes " * 500, retention="7y")
    n = c.flush()
    assert n == 1  # one tarball uploaded via /v1/packs/upload-url + /complete

    # The manifest the SDK wrote is now findable through the API.
    loc = c.find_file("statements/jan.pdf")
    assert loc["tarball_key"].startswith(f"data/{acct}/7y/")
    assert loc["length"] > 0
