"""Tests for the region registry and strict residency rules."""
import pytest

from deeparchive import regions


def test_launch_countries_active() -> None:
    active = regions.active_countries()
    assert "US" in active
    assert "IN" in active
    assert "DE" in active


def test_resolve_returns_in_country_region() -> None:
    assert regions.resolve("IN").region == "ap-south-1"
    assert regions.resolve("US").region == "us-east-1"


def test_unknown_country_refused() -> None:
    with pytest.raises(regions.CountryNotServedError):
        regions.resolve("ZZ")


def test_planned_but_inactive_country_refused() -> None:
    # Japan has an in-country region but is not active yet.
    with pytest.raises(regions.CountryNotServedError):
        regions.resolve("JP")


def test_cross_border_country_refused_under_strict_residency() -> None:
    # Nigeria has no in-country region; strict model refuses it.
    with pytest.raises(regions.CountryNotServedError):
        regions.resolve("NG")
