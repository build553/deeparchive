"""Tests for region-aware storage, using a fake in-memory S3 client."""
import os
from typing import Any

from deeparchive.manifest import RetentionClass
from deeparchive.packer import Pack, SourceFile, pack
from deeparchive.storage import Storage


class FakeS3:
    """Minimal in-memory stand-in for the boto3 S3 client."""

    def __init__(self) -> None:
        self.objects: dict[tuple[str, str], bytes] = {}

    def put_object(self, Bucket: str, Key: str, Body: Any) -> None:  # noqa: N803
        data = Body.read() if hasattr(Body, "read") else Body
        self.objects[(Bucket, Key)] = data

    def upload_file(self, Filename: str, Bucket: str, Key: str, Config: Any = None) -> None:  # noqa: N803
        with open(Filename, "rb") as f:
            self.objects[(Bucket, Key)] = f.read()


def _one_pack(tmp_path: object) -> Pack:
    base = str(tmp_path)
    src = os.path.join(base, "f.bin")
    with open(src, "wb") as f:
        f.write(b"hello world" * 10)
    files = [SourceFile(src, "f.bin", RetentionClass.SEVEN_YEAR)]
    return pack(files, out_dir=os.path.join(base, "out"), org_id="hdfc")[0]


def test_upload_pack_writes_tarball_and_manifest(tmp_path: object) -> None:
    fake = FakeS3()
    storage = Storage.for_country("IN", s3=fake)  # type: ignore[arg-type]
    p = _one_pack(tmp_path)
    storage.upload_pack(p)

    # Tarball stored under its data/ key; manifest under db/.
    keys = {k for (_, k) in fake.objects}
    assert any(k.startswith("data/hdfc/7y/") for k in keys)
    assert any(k.startswith("db/hdfc/") and k.endswith(".json") for k in keys)
    # All written to the India bucket.
    buckets = {b for (b, _) in fake.objects}
    assert buckets == {"deeparchive-ap-south-1"}


def test_large_tarball_uploads_via_transfer(tmp_path: object) -> None:
    """A tarball above the multipart threshold still uploads (via upload_file)."""
    fake = FakeS3()
    storage = Storage.for_country("IN", s3=fake)  # type: ignore[arg-type]
    p = _one_pack(tmp_path)
    storage.upload_pack(p)
    # The tarball object landed and matches the packed bytes on disk.
    tarball_keys = [k for (_, k) in fake.objects if k.endswith(".tar")]
    assert len(tarball_keys) == 1
    with open(p.tarball_path, "rb") as f:
        assert fake.objects[("deeparchive-ap-south-1", tarball_keys[0])] == f.read()



def test_restore_ready_true_for_warm_standard_object() -> None:
    """A STANDARD (warm) object is immediately readable -- no restore needed.

    Regression: previously restore_ready returned False for warm objects (no
    Restore header), wrongly demanding a restore for freshly-uploaded data.
    """
    from deeparchive import regions
    from deeparchive.storage import Storage

    class WarmS3:
        def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
            return {}  # STANDARD: S3 omits StorageClass; no Restore header

    s = Storage(regions.resolve("US"), s3=WarmS3())  # type: ignore[arg-type]
    assert s.restore_ready("data/acc/7y/p.tar") is True


def test_restore_ready_false_for_cold_unrestored() -> None:
    from deeparchive import regions
    from deeparchive.storage import Storage

    class ColdS3:
        def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
            return {"StorageClass": "DEEP_ARCHIVE"}  # cold, no restore yet

    s = Storage(regions.resolve("US"), s3=ColdS3())  # type: ignore[arg-type]
    assert s.restore_ready("data/acc/7y/p.tar") is False
