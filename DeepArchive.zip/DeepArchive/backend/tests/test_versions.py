"""Tests for file versioning / history."""
from deeparchive.manifest import FileEntry, Manifest, RetentionClass
from deeparchive.versions import (
    latest_version,
    list_versions,
    version_at,
    version_count,
)


def _manifest(pack: str, created: str, path: str, sha: str, size: int) -> Manifest:
    return Manifest(
        pack_id=pack, org_id="acc1", created_at=created,
        tarball_key=f"data/acc1/7y/{pack}.tar", tarball_sha256="a" * 64,
        tarball_bytes=size, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry(path, 0, size, sha, created)],
    )


def _history() -> list[Manifest]:
    # Three captures of report.pdf over time + an unrelated file.
    return [
        _manifest("p1", "2026-01-01T00:00:00Z", "docs/report.pdf", "a" * 64, 100),
        _manifest("p2", "2026-02-01T00:00:00Z", "docs/report.pdf", "b" * 64, 150),
        _manifest("p3", "2026-03-01T00:00:00Z", "docs/report.pdf", "c" * 64, 200),
        _manifest("p4", "2026-01-15T00:00:00Z", "photos/x.jpg", "d" * 64, 500),
    ]


def test_list_versions_newest_first() -> None:
    vs = list_versions(_history(), "docs/report.pdf")
    assert [v.created_at for v in vs] == [
        "2026-03-01T00:00:00Z", "2026-02-01T00:00:00Z", "2026-01-01T00:00:00Z",
    ]


def test_version_count() -> None:
    assert version_count(_history(), "docs/report.pdf") == 3
    assert version_count(_history(), "photos/x.jpg") == 1
    assert version_count(_history(), "nope.txt") == 0


def test_latest_version() -> None:
    v = latest_version(_history(), "docs/report.pdf")
    assert v is not None
    assert v.created_at == "2026-03-01T00:00:00Z"
    assert v.sha256 == "c" * 64
    assert v.size == 200


def test_latest_version_missing_is_none() -> None:
    assert latest_version(_history(), "ghost.txt") is None


def test_version_at_specific_timestamp() -> None:
    v = version_at(_history(), "docs/report.pdf", "2026-02-01T00:00:00Z")
    assert v is not None
    assert v.sha256 == "b" * 64
    assert v.pack_id == "p2"
    assert v.tarball_key == "data/acc1/7y/p2.tar"


def test_version_at_unknown_timestamp_is_none() -> None:
    assert version_at(_history(), "docs/report.pdf", "2099-01-01T00:00:00Z") is None


def test_version_carries_entry_for_restore() -> None:
    # A version exposes the full FileEntry so a caller can extract it.
    v = latest_version(_history(), "docs/report.pdf")
    assert v is not None
    assert v.entry.path == "docs/report.pdf"
    assert v.offset == v.entry.offset
