"""Tests for the restore state machine, using a fake S3 that simulates restore."""
import os

import pytest

from deeparchive.manifest import RetentionClass
from deeparchive.packer import Pack, SourceFile, pack
from deeparchive.restore import (
    IntegrityError,
    RestoreNotReadyError,
    RestoreState,
    check_restore,
    download_verify,
    request_restore,
)
from deeparchive.storage import Storage


class FakeRestoreS3:
    """Fake S3 that models the restore lifecycle for one tarball on local disk."""

    def __init__(self, tarball_path: str) -> None:
        self._tarball_path = tarball_path
        self._restore_requested = False
        self.ready = False  # test flips this to simulate 48h passing

    def restore_object(self, Bucket: str, Key: str, RestoreRequest: dict[str, object]) -> None:  # noqa: N803
        self._restore_requested = True

    def head_object(self, Bucket: str, Key: str) -> dict[str, str]:  # noqa: N803
        # A cold (DEEP_ARCHIVE) object: not readable until a restore completes.
        if not self._restore_requested:
            return {"StorageClass": "DEEP_ARCHIVE"}
        state = "false" if self.ready else "true"
        return {"StorageClass": "DEEP_ARCHIVE",
                "Restore": f'ongoing-request="{state}"'}

    def download_file(self, Bucket: str, Key: str, dest: str) -> None:  # noqa: N803
        with open(self._tarball_path, "rb") as src, open(dest, "wb") as out:
            out.write(src.read())


def _one_pack(tmp_path: object) -> Pack:
    base = str(tmp_path)
    src = os.path.join(base, "f.bin")
    with open(src, "wb") as f:
        f.write(b"important archive data" * 50)
    files = [SourceFile(src, "f.bin", RetentionClass.SEVEN_YEAR)]
    return pack(files, out_dir=os.path.join(base, "out"), org_id="hdfc")[0]


def test_full_restore_happy_path(tmp_path: object) -> None:
    p = _one_pack(tmp_path)
    fake = FakeRestoreS3(p.tarball_path)
    storage = Storage.for_country("IN", s3=fake)  # type: ignore[arg-type]

    job = request_restore(storage, p.manifest.tarball_key)
    assert job.state is RestoreState.RESTORING

    # Still restoring (48h not elapsed).
    job = check_restore(storage, job)
    assert job.state is RestoreState.RESTORING

    # Simulate restore completing.
    fake.ready = True
    job = check_restore(storage, job)
    assert job.state is RestoreState.READY

    # Download + verify integrity succeeds.
    dest = os.path.join(str(tmp_path), "restored.tar")
    download_verify(storage, job, p.manifest, dest)
    assert os.path.exists(dest)


def test_download_before_ready_refused(tmp_path: object) -> None:
    p = _one_pack(tmp_path)
    fake = FakeRestoreS3(p.tarball_path)
    storage = Storage.for_country("IN", s3=fake)  # type: ignore[arg-type]
    job = request_restore(storage, p.manifest.tarball_key)
    with pytest.raises(RestoreNotReadyError):
        download_verify(storage, job, p.manifest, os.path.join(str(tmp_path), "x.tar"))


def test_integrity_mismatch_detected(tmp_path: object) -> None:
    p = _one_pack(tmp_path)
    fake = FakeRestoreS3(p.tarball_path)
    storage = Storage.for_country("IN", s3=fake)  # type: ignore[arg-type]
    job = request_restore(storage, p.manifest.tarball_key)
    fake.ready = True
    job = check_restore(storage, job)

    # Corrupt the manifest's expected hash -> integrity check must fail.
    bad_manifest = _one_pack(tmp_path).manifest  # different tarball, different hash
    with pytest.raises(IntegrityError):
        download_verify(storage, job, bad_manifest, os.path.join(str(tmp_path), "y.tar"))
