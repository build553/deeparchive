"""Tests for the restore microservice."""
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.services.restore_svc import build_restore_app
from deeparchive.storage import Storage


class FakeIdentity:
    def validate(self, api_key: str) -> dict[str, Any]:
        if not api_key.startswith("good-"):
            raise PermissionError("invalid")
        _, country, acct = api_key.split("-", 2)
        return {"account_id": acct, "country": country}


class FakeS3:
    def __init__(self, ready: bool = False) -> None:
        self.ready = ready

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"StorageClass": "DEEP_ARCHIVE",
                "Restore": f'ongoing-request="{"false" if self.ready else "true"}"'}

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return f"https://s3.example/{Params['Key']}?sig=x"


def _client(ready: bool = False) -> TestClient:
    s3 = FakeS3(ready)
    return TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda c: Storage(regions.resolve(c), s3=s3),  # type: ignore[arg-type]
    ))


def _auth(acct: str = "acc1") -> dict[str, str]:
    return {"Authorization": f"Bearer good-IN-{acct}"}


def test_health() -> None:
    assert _client().get("/v1/health").json()["service"] == "restore"


def test_start_restore() -> None:
    resp = _client().post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"},
                          headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["state"] == "RESTORING"
    assert resp.json()["sla_hours"] == 48


def test_restore_other_org_forbidden() -> None:
    resp = _client().post("/v1/restore", json={"tarball_key": "data/acc2/7y/p.tar"},
                          headers=_auth("acc1"))
    assert resp.status_code == 403


def test_download_not_ready_409() -> None:
    resp = _client(ready=False).get("/v1/restore/data/acc1/7y/p.tar/download",
                                    headers=_auth())
    assert resp.status_code == 409


def test_download_ready_returns_url() -> None:
    resp = _client(ready=True).get("/v1/restore/data/acc1/7y/p.tar/download",
                                   headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["download_url"].startswith("https://s3.example/")


def test_requires_auth() -> None:
    assert _client().post("/v1/restore",
                          json={"tarball_key": "data/acc1/7y/p.tar"}).status_code == 401


class FakeAudit:
    def __init__(self) -> None:
        self.events: list[Any] = []

    def record(self, event: Any) -> None:
        self.events.append(event)


def test_audit_records_restore_request_and_download() -> None:
    s3 = FakeS3(ready=True)
    aud = FakeAudit()
    c = TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda cc: Storage(regions.resolve(cc), s3=s3),  # type: ignore[arg-type]
        audit=aud,  # type: ignore[arg-type]
    ))
    c.post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"}, headers=_auth())
    c.get("/v1/restore/data/acc1/7y/p.tar/download", headers=_auth())
    actions = [e.action for e in aud.events]
    assert "restore.request" in actions
    assert "restore.download" in actions
    assert all(e.actor == "acc1" for e in aud.events)


# --- Approval gating + approve/reject ----------------------------------------

def _approval_client(threshold: int, seed_manifest_bytes: int):  # type: ignore[no-untyped-def]
    """Restore client whose org gates restores above `threshold` bytes.

    The admin ref in the microservice is the account_id (acc1), so we make acc1
    an ADMIN member of its own org (parity with the monolith).
    """
    from deeparchive.accounts.approval import ApprovalService
    from deeparchive.accounts.orgs import Organization, Role
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass

    org = Organization(account_id="acc1", name="HDFC")
    org.add_member("acc1", Role.ADMIN)
    svc = ApprovalService(org=org, threshold_bytes=threshold)

    s3 = FakeS3(ready=False)
    # Seed a manifest so the restore size lookup finds the tarball.
    m = Manifest(
        pack_id="p", org_id="acc1", created_at="t",
        tarball_key="data/acc1/7y/p.tar", tarball_sha256="a" * 64,
        tarball_bytes=seed_manifest_bytes,
        retention_class=RetentionClass.SEVEN_YEAR, legal_hold=False,
        files=[FileEntry("f.pdf", 0, 10, "b" * 64, "t")],
    )

    class SeededStorage(Storage):
        def list_manifests(self, org_id: str):  # type: ignore[no-untyped-def]
            return [m]

    seeded = SeededStorage(regions.resolve("IN"), s3=s3)  # type: ignore[arg-type]
    c = TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda cc: seeded,
        approval_provider=lambda org_id: svc,
    ))
    return c, svc


def test_large_restore_pends_approval() -> None:
    # threshold 1 byte, manifest 100 bytes -> over threshold -> PENDING_APPROVAL
    c, _svc = _approval_client(threshold=1, seed_manifest_bytes=100)
    resp = c.post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"}, headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["state"] == "PENDING_APPROVAL"
    assert resp.json()["request_id"].startswith("apr_")


def test_small_restore_auto_proceeds() -> None:
    # threshold huge, manifest tiny -> auto-approved -> proceeds to RESTORING
    c, _svc = _approval_client(threshold=10 ** 12, seed_manifest_bytes=100)
    resp = c.post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"}, headers=_auth())
    assert resp.json()["state"] == "RESTORING"


def test_approve_then_restore_flow() -> None:
    c, _svc = _approval_client(threshold=1, seed_manifest_bytes=100)
    pend = c.post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"},
                  headers=_auth()).json()
    rid = pend["request_id"]
    resp = c.post(f"/v1/restore/{rid}/approve", headers=_auth())
    assert resp.status_code == 200
    assert resp.json()["state"] == "APPROVED"


def test_reject_flow() -> None:
    c, _svc = _approval_client(threshold=1, seed_manifest_bytes=100)
    pend = c.post("/v1/restore", json={"tarball_key": "data/acc1/7y/p.tar"},
                  headers=_auth()).json()
    resp = c.post(f"/v1/restore/{pend['request_id']}/reject", headers=_auth())
    assert resp.json()["state"] == "REJECTED"


def test_approve_404_when_approvals_disabled() -> None:
    # Default client has no approval_provider.
    resp = _client().post("/v1/restore/apr_x/approve", headers=_auth())
    assert resp.status_code == 404


# --- Restore-ready notification ----------------------------------------------

def test_status_ready_fires_notification() -> None:
    from deeparchive.notify import FakeNotifier
    notifier = FakeNotifier()
    s3 = FakeS3(ready=True)  # head_object says restore complete -> READY
    c = TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda cc: Storage(regions.resolve(cc), s3=s3),  # type: ignore[arg-type]
        notifier=notifier,
        notify_email_for=lambda acct: f"{acct}@example.com",
    ))
    resp = c.get("/v1/restore/data/acc1/7y/p.tar", headers=_auth())
    assert resp.json()["state"] == "READY"
    assert len(notifier.sent) == 1
    assert notifier.sent[0].to == "acc1@example.com"
    assert "ready" in notifier.sent[0].subject.lower()


def test_status_not_ready_no_notification() -> None:
    from deeparchive.notify import FakeNotifier
    notifier = FakeNotifier()
    s3 = FakeS3(ready=False)
    c = TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda cc: Storage(regions.resolve(cc), s3=s3),  # type: ignore[arg-type]
        notifier=notifier,
        notify_email_for=lambda acct: f"{acct}@example.com",
    ))
    c.get("/v1/restore/data/acc1/7y/p.tar", headers=_auth())
    assert notifier.sent == []



class _ErrS3:
    """FakeS3 whose head_object fails as S3 would for a missing/inaccessible key."""
    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        from botocore.exceptions import ClientError
        raise ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "Access Denied"}},
            "HeadObject",
        )

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return "https://s3.example/x?sig=x"


def _err_client() -> TestClient:
    s3 = _ErrS3()
    return TestClient(build_restore_app(
        identity=FakeIdentity(),  # type: ignore[arg-type]
        storage_for_country=lambda c: Storage(regions.resolve(c), s3=s3),  # type: ignore[arg-type]
    ))


def test_status_s3_error_returns_404_not_500() -> None:
    resp = _err_client().get("/v1/restore/data/acc1/7y/x.tar",
                             headers={"Authorization": "Bearer good-IN-acc1"})
    assert resp.status_code == 404


def test_download_s3_error_returns_404_not_500() -> None:
    resp = _err_client().get("/v1/restore/data/acc1/7y/x.tar/download",
                             headers={"Authorization": "Bearer good-IN-acc1"})
    assert resp.status_code == 404
