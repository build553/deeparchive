"""Tests for the persistent restore orchestrator (adapted from aws-glacier-restore)."""
import os

from deeparchive.restore import (
    JobStatus,
    LocalJobStore,
    Orchestrator,
    RestoreRecord,
)


class FakeStorage:
    """Fake Storage: restore can be made to fail, and readiness toggled."""

    def __init__(self, fail: bool = False, ready: bool = False) -> None:
        self.fail = fail
        self.ready = ready
        self.started: list[str] = []

    def start_restore(self, tarball_key: str) -> None:
        if self.fail:
            raise RuntimeError("glacier restore rejected")
        self.started.append(tarball_key)

    def restore_ready(self, tarball_key: str) -> bool:
        return self.ready


def _orch(tmp_path: object, storage: FakeStorage) -> Orchestrator:
    store = LocalJobStore(os.path.join(str(tmp_path), "jobs.json"))
    return Orchestrator(store=store, storage=storage)


def test_create_moves_to_restoring(tmp_path: object) -> None:
    storage = FakeStorage()
    orch = _orch(tmp_path, storage)
    rec = orch.create("hdfc", "data/hdfc/7y/p.tar")
    assert rec.status is JobStatus.RESTORING
    assert storage.started == ["data/hdfc/7y/p.tar"]


def test_advance_flips_to_ready_when_available(tmp_path: object) -> None:
    storage = FakeStorage(ready=False)
    orch = _orch(tmp_path, storage)
    rec = orch.create("hdfc", "data/hdfc/7y/p.tar")
    assert orch.advance(rec.job_id).status is JobStatus.RESTORING
    storage.ready = True
    assert orch.advance(rec.job_id).status is JobStatus.READY


def test_job_persists_across_store_instances(tmp_path: object) -> None:
    path = os.path.join(str(tmp_path), "jobs.json")
    storage = FakeStorage()
    rec = Orchestrator(store=LocalJobStore(path), storage=storage).create(
        "hdfc", "data/hdfc/7y/p.tar"
    )
    # New store instance reads the persisted job.
    reloaded = LocalJobStore(path).get(rec.job_id)
    assert isinstance(reloaded, RestoreRecord)
    assert reloaded.status is JobStatus.RESTORING


def test_failed_restore_can_be_redriven(tmp_path: object) -> None:
    storage = FakeStorage(fail=True)
    orch = _orch(tmp_path, storage)
    rec = orch.create("hdfc", "data/hdfc/7y/p.tar")
    assert rec.status is JobStatus.FAILED
    assert rec.attempts == 1

    # Glacier recovers; redrive succeeds.
    storage.fail = False
    redriven = orch.redrive(rec.job_id)
    assert redriven.status is JobStatus.RESTORING
    assert redriven.attempts == 2


def test_redrive_respects_attempt_cap(tmp_path: object) -> None:
    storage = FakeStorage(fail=True)
    store = LocalJobStore(os.path.join(str(tmp_path), "jobs.json"))
    orch = Orchestrator(store=store, storage=storage, max_attempts=2)
    rec = orch.create("hdfc", "data/hdfc/7y/p.tar")  # attempt 1, FAILED
    orch.redrive(rec.job_id)  # attempt 2, still failing
    capped = orch.redrive(rec.job_id)  # at cap -> no further attempt
    assert capped.attempts == 2
    assert capped.status is JobStatus.FAILED
