"""Tests for prod notifier backends (SES/SNS) with injected fake clients."""
from typing import Any

import pytest

from deeparchive.notify import (
    Message,
    RoutingNotifier,
    SesNotifier,
    SnsNotifier,
    restore_ready,
)


class FakeSes:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def send_email(self, **kwargs: Any) -> dict[str, str]:
        self.calls.append(kwargs)
        return {"MessageId": "m1"}


class FakeSns:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def publish(self, **kwargs: Any) -> dict[str, str]:
        self.calls.append(kwargs)
        return {"MessageId": "s1"}


def test_ses_sends_email() -> None:
    ses = FakeSes()
    SesNotifier(sender="no-reply@deeparchive.io", region="us-east-1", ses_client=ses).send(
        restore_ready("a@x.com", "jan.pdf")
    )
    assert ses.calls[0]["Source"] == "no-reply@deeparchive.io"
    assert ses.calls[0]["Destination"]["ToAddresses"] == ["a@x.com"]
    assert "jan.pdf" in ses.calls[0]["Message"]["Body"]["Text"]["Data"]


def test_sns_sends_sms_with_subject_prefixed() -> None:
    sns = FakeSns()
    SnsNotifier(region="us-east-1", sns_client=sns).send(
        Message(to="+14155550123", subject="Ready", body="your file is ready")
    )
    assert sns.calls[0]["PhoneNumber"] == "+14155550123"
    assert sns.calls[0]["Message"] == "Ready: your file is ready"


def test_routing_picks_channel_by_destination() -> None:
    ses, sns = FakeSes(), FakeSns()
    router = RoutingNotifier(
        email=SesNotifier("s@x.com", "us-east-1", ses_client=ses),
        sms=SnsNotifier("us-east-1", sns_client=sns),
    )
    router.send(Message(to="a@x.com", subject="s", body="b"))       # email
    router.send(Message(to="+14155550123", subject="s", body="b"))  # sms
    assert len(ses.calls) == 1
    assert len(sns.calls) == 1


def test_routing_raises_when_channel_missing() -> None:
    router = RoutingNotifier(email=None, sms=None)
    with pytest.raises(ValueError, match="no notifier configured"):
        router.send(Message(to="a@x.com", subject="s", body="b"))
