"""Tests for the payment/purchase flow."""
import pytest

from deeparchive.billing import (
    CATALOG,
    BillingService,
    FakeProcessor,
    NoEntitlementError,
    PaymentError,
    PlanId,
    UsageMeter,
)

_GB = 1024 * 1024 * 1024


def _service() -> tuple[BillingService, FakeProcessor, UsageMeter]:
    proc = FakeProcessor()
    meter = UsageMeter()
    return BillingService(processor=proc, meter=meter), proc, meter


def test_purchase_grants_entitlement_and_enables_upload() -> None:
    svc, proc, meter = _service()
    ent = svc.purchase("acc_1", PlanId.INDIVIDUAL_100_30Y, payment_token="tok", now=0.0)
    assert ent.quota_bytes == 100 * _GB
    # Charged the plan's derived (cost + margin) price.
    assert proc.charges[0].amount_cents == CATALOG[PlanId.INDIVIDUAL_100_30Y].price_usd_cents
    # Entitlement is registered -> upload now allowed.
    meter.check_and_record_upload("acc_1", 10 * _GB, now=0.0)
    assert meter.usage("acc_1").stored_bytes == 10 * _GB


def test_declined_card_raises_and_grants_nothing() -> None:
    svc, _, meter = _service()
    with pytest.raises(PaymentError):
        svc.purchase("acc_1", PlanId.INDIVIDUAL_100_30Y, payment_token="decline", now=0.0)
    # No entitlement -> upload rejected.
    with pytest.raises(NoEntitlementError):
        meter.check_and_record_upload("acc_1", 1, now=0.0)


def test_org_purchase_scales_price_by_units() -> None:
    svc, proc, _ = _service()
    svc.purchase("acc_org", PlanId.ORG_PER_TB_30Y, payment_token="tok", units=10, now=0.0)
    unit_price = CATALOG[PlanId.ORG_PER_TB_30Y].price_usd_cents
    assert proc.charges[0].amount_cents == unit_price * 10
