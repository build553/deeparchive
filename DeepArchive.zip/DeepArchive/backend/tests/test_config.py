"""Sanity test: config loads and holds the locked decisions."""
from deeparchive import config


def test_config_locked_decisions() -> None:
    assert config.PACK_SIZE_BYTES == 256 * 1024 * 1024
    assert config.RESTORE_TIER == "Bulk"
    assert config.RESTORE_SLA_HOURS == 48
    assert config.DATA_PREFIX == "data/"
    assert config.INDEX_PREFIX == "db/"
