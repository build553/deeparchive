"""Tests for the ingest flow (stage -> flush when qualified)."""
import os

from deeparchive import regions
from deeparchive.services.ingest import IngestService
from deeparchive.storage import Storage


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def upload_file(self, Filename, Bucket, Key, Config=None):  # type: ignore[no-untyped-def]  # noqa: N803
        with open(Filename, "rb") as f:
            self.objects[Key] = f.read()

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body


def _ingest(tmp_path: object) -> tuple[IngestService, FakeS3]:
    fake = FakeS3()
    storage = Storage(regions.resolve("US"), s3=fake)  # type: ignore[arg-type]
    out = os.path.join(str(tmp_path), "out")
    return IngestService(storage=storage, out_dir=out), fake


def _make_file(tmp_path: object, name: str, size: int) -> str:
    path = os.path.join(str(tmp_path), name)
    with open(path, "wb") as f:
        f.write(b"x" * size)
    return path


def test_below_threshold_does_not_flush(tmp_path: object) -> None:
    ingest, fake = _ingest(tmp_path)
    p = _make_file(tmp_path, "a.bin", 1000)
    ingest.stage("hdfc", p, "a.bin", size=1000)
    assert ingest.qualifies("hdfc") is False
    assert ingest.flush("hdfc") == 0
    assert fake.objects == {}


def test_crossing_threshold_flushes(tmp_path: object) -> None:
    ingest, fake = _ingest(tmp_path)
    # Force a small threshold by staging a file bigger than 256MB is impractical;
    # instead stage a file and shrink the buffer threshold.
    p = _make_file(tmp_path, "big.bin", 2000)
    ingest.stage("hdfc", p, "big.bin", size=2000)
    ingest._buffer("hdfc").threshold_bytes = 1000  # now qualifies by size
    assert ingest.qualifies("hdfc") is True
    uploaded = ingest.flush("hdfc")
    assert uploaded == 1
    assert any(k.endswith(".tar") for k in fake.objects)
    # Buffer drained after flush.
    assert ingest.qualifies("hdfc") is False
