"""Tests for observability: structured logging + metrics."""
import json
import logging

from deeparchive.observability import Metrics, get_logger


def test_log_event_emits_json() -> None:
    logger = get_logger()
    formatter = logger.handlers[0].formatter
    assert formatter is not None
    record = logging.LogRecord(
        name="deeparchive", level=logging.INFO, pathname="", lineno=0,
        msg="thing_happened", args=(), exc_info=None,
    )
    record.fields = {"org_id": "acc_1", "count": 3}
    payload = json.loads(formatter.format(record))
    assert payload["msg"] == "thing_happened"
    assert payload["org_id"] == "acc_1"
    assert payload["count"] == 3
    assert payload["level"] == "INFO"


def test_metrics_counter() -> None:
    m = Metrics()
    m.incr("uploads")
    m.incr("uploads", by=2)
    assert m.counters["uploads"] == 3


def test_metrics_timer() -> None:
    m = Metrics()
    with m.timed("op"):
        pass
    assert "op" in m.timers_ms
    assert m.timers_ms["op"] >= 0.0
