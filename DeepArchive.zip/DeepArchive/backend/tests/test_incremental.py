"""Tests for incremental backup / resume via ArchiveIndex (borrowed from serac)."""
import os

from deeparchive.index import ArchiveIndex
from deeparchive.manifest import RetentionClass
from deeparchive.packer import SourceFile, pack


def _write(path: str, data: bytes) -> None:
    with open(path, "wb") as f:
        f.write(data)


def _sources(base: str) -> list[SourceFile]:
    _write(os.path.join(base, "a.bin"), b"aaaa" * 100)
    _write(os.path.join(base, "b.bin"), b"bbbb" * 100)
    return [
        SourceFile(os.path.join(base, "a.bin"), "a.bin", RetentionClass.SEVEN_YEAR),
        SourceFile(os.path.join(base, "b.bin"), "b.bin", RetentionClass.SEVEN_YEAR),
    ]


def test_second_run_skips_unchanged_files(tmp_path: object) -> None:
    base = str(tmp_path)
    out = os.path.join(base, "out")

    # First run: no index -> packs everything.
    first = pack(_sources(base), out_dir=out, org_id="acme")
    idx = ArchiveIndex.from_manifests([p.manifest for p in first])
    assert len(idx) == 2

    # Second run with the index: nothing changed -> nothing packed.
    second = pack(_sources(base), out_dir=out, org_id="acme", index=idx)
    assert second == []


def test_changed_file_is_repacked(tmp_path: object) -> None:
    base = str(tmp_path)
    out = os.path.join(base, "out")
    first = pack(_sources(base), out_dir=out, org_id="acme")
    idx = ArchiveIndex.from_manifests([p.manifest for p in first])

    # Change a.bin -> its sha differs -> it must be repacked (b.bin skipped).
    _write(os.path.join(base, "a.bin"), b"CHANGED CONTENT")
    srcs = [
        SourceFile(os.path.join(base, "a.bin"), "a.bin", RetentionClass.SEVEN_YEAR),
        SourceFile(os.path.join(base, "b.bin"), "b.bin", RetentionClass.SEVEN_YEAR),
    ]
    second = pack(srcs, out_dir=out, org_id="acme", index=idx)
    packed_paths = [e.path for p in second for e in p.manifest.files]
    assert packed_paths == ["a.bin"]


def test_resume_after_partial_upload(tmp_path: object) -> None:
    """Simulate resume: a.bin already archived (in index) -> only b.bin packed."""
    base = str(tmp_path)
    out = os.path.join(base, "out")
    _sources(base)

    # Index knows only about a.bin (b.bin's upload was 'interrupted').
    a_only = pack(
        [SourceFile(os.path.join(base, "a.bin"), "a.bin", RetentionClass.SEVEN_YEAR)],
        out_dir=out,
        org_id="acme",
    )
    partial = ArchiveIndex.from_manifests([p.manifest for p in a_only])

    # Rerun with both files -> a.bin skipped, b.bin packed.
    second = pack(_sources(base), out_dir=out, org_id="acme", index=partial)
    remaining = [e.path for p in second for e in p.manifest.files]
    assert "b.bin" in remaining
    assert "a.bin" not in remaining
