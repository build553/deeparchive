"""Tests for the cost-aware S3 audit log."""
import io

from deeparchive.audit import AuditEvent, AuditLog


class FakeS3:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}
        self.gets: list[str] = []

    def put_object(self, Bucket, Key, Body):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body

    def get_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        self.gets.append(Key)
        if Key not in self.objects:
            raise KeyError(Key)
        return {"Body": io.BytesIO(self.objects[Key])}


_DAY = 86400
# 2026-09-20 00:00 UTC-ish base
_BASE = 1789948800.0


def _ev(at: float, action: str = "restore.request") -> AuditEvent:
    return AuditEvent(org_id="hdfc", actor="admin", action=action,
                      target="data/hdfc/7y/p.tar", at=at, source_ip="1.2.3.4")


def test_append_multiple_events_same_day_one_object() -> None:
    s3 = FakeS3()
    log = AuditLog(bucket="b", s3=s3)
    log.record(_ev(_BASE + 10))
    log.record(_ev(_BASE + 20, "file.delete"))
    # Both events in ONE day object (cost-aware: not one object per event).
    day_objects = [k for k in s3.objects if k.startswith("audit/hdfc/")]
    assert len(day_objects) == 1
    assert s3.objects[day_objects[0]].decode().count("\n") == 1  # 2 lines


def test_read_range_returns_events() -> None:
    s3 = FakeS3()
    log = AuditLog(bucket="b", s3=s3)
    log.record(_ev(_BASE + 10))
    log.record(_ev(_BASE + 20, "file.delete"))
    events = log.read_range("hdfc", _BASE, _BASE + _DAY)
    assert len(events) == 2
    assert {e["action"] for e in events} == {"restore.request", "file.delete"}


def test_read_range_prunes_partitions() -> None:
    s3 = FakeS3()
    log = AuditLog(bucket="b", s3=s3)
    log.record(_ev(_BASE + 10))            # day 0
    log.record(_ev(_BASE + 5 * _DAY))       # day 5
    s3.gets.clear()
    # Query only day 0 -> should fetch just ~1 day file, not day 5.
    log.read_range("hdfc", _BASE, _BASE + 100)
    assert all("2026-09" in k for k in s3.gets)
    # Only 1 day key fetched (partition pruning), not the whole range.
    assert len(s3.gets) == 1


def test_missing_day_is_ok() -> None:
    s3 = FakeS3()
    log = AuditLog(bucket="b", s3=s3)
    # No events written; reading a range just returns [].
    assert log.read_range("hdfc", _BASE, _BASE + 3 * _DAY) == []
