"""Notifications: pluggable, event-driven, $0 idle.

A Notifier just delivers a message. Backends (SES email / SNS SMS) are
pay-per-use -- you pay per message sent, nothing at rest. FakeNotifier is used
in tests (captures messages, sends nothing).

Event helpers format the customer-facing messages for the three events that
matter: restore ready, quota low, payment failed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class Message:
    to: str          # email address or E.164 phone number
    subject: str     # used by email; SMS backends may prepend/ignore
    body: str


class Notifier(Protocol):
    """Delivers a message. Implementations: Fake (tests), SES (email), SNS (SMS)."""

    def send(self, message: Message) -> None: ...


class FakeNotifier:
    """Test notifier: records messages instead of sending (zero cost, no I/O)."""

    def __init__(self) -> None:
        self.sent: list[Message] = []

    def send(self, message: Message) -> None:
        self.sent.append(message)


# --- Event message templates (customer-facing copy) --------------------------

def restore_ready(to: str, file_name: str, expires_hours: int = 24) -> Message:
    return Message(
        to=to,
        subject="Your DeepArchive file is ready to download",
        body=(
            f"Good news -- '{file_name}' has been restored from cold storage "
            f"and is ready to download. It will remain available for "
            f"{expires_hours} hours before returning to archive."
        ),
    )


def quota_low(to: str, used_gb: float, quota_gb: float) -> Message:
    pct = round(100 * used_gb / quota_gb) if quota_gb else 100
    return Message(
        to=to,
        subject="You're running low on DeepArchive storage",
        body=(
            f"You've used {used_gb:.1f} GB of your {quota_gb:.1f} GB "
            f"({pct}%). Add storage to keep archiving without interruption."
        ),
    )


def payment_failed(to: str, plan: str, amount: str) -> Message:
    return Message(
        to=to,
        subject="Action needed: your DeepArchive payment failed",
        body=(
            f"We couldn't process your {amount} payment for the {plan} plan. "
            f"Please update your payment method to keep your archive active. "
            f"Your data is safe and retained during the grace period."
        ),
    )
