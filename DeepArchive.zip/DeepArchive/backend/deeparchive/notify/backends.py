"""Production notifier backends: SES (email) and SNS (SMS). $0 idle.

Both are pay-per-use -- no fixed cost, you pay only per message:
  * SES email: ~$0.10 per 1,000 emails
  * SNS SMS:   ~$0.006+ per SMS (varies by country)

boto3 clients are created lazily so importing this module never requires AWS.
A RoutingNotifier picks email vs SMS by the shape of the destination.
"""
from __future__ import annotations

from typing import Any

from deeparchive.notify.notify import Message, Notifier


class SesNotifier:
    """Sends email via Amazon SES (pay-per-email, no fixed cost)."""

    def __init__(self, sender: str, region: str, ses_client: Any = None):
        self._sender = sender
        self._region = region
        self._client = ses_client  # injectable for tests

    def _ses(self) -> Any:
        if self._client is None:  # pragma: no cover - real AWS at runtime
            import boto3
            self._client = boto3.client("ses", region_name=self._region)
        return self._client

    def send(self, message: Message) -> None:
        self._ses().send_email(
            Source=self._sender,
            Destination={"ToAddresses": [message.to]},
            Message={
                "Subject": {"Data": message.subject},
                "Body": {"Text": {"Data": message.body}},
            },
        )


class SnsNotifier:
    """Sends SMS via Amazon SNS (pay-per-SMS, no fixed cost)."""

    def __init__(self, region: str, sns_client: Any = None):
        self._region = region
        self._client = sns_client  # injectable for tests

    def _sns(self) -> Any:
        if self._client is None:  # pragma: no cover - real AWS at runtime
            import boto3
            self._client = boto3.client("sns", region_name=self._region)
        return self._client

    def send(self, message: Message) -> None:
        # SMS has no subject; prepend it so the text still carries context.
        text = f"{message.subject}: {message.body}" if message.subject else message.body
        self._sns().publish(PhoneNumber=message.to, Message=text)


class RoutingNotifier:
    """Routes to email or SMS based on the destination shape.

    E.164 phone numbers start with '+'; everything else is treated as email.
    Falls back gracefully if a channel isn't configured.
    """

    def __init__(self, email: Notifier | None = None, sms: Notifier | None = None):
        self._email = email
        self._sms = sms

    def send(self, message: Message) -> None:
        is_phone = message.to.startswith("+")
        backend = self._sms if is_phone else self._email
        if backend is None:
            raise ValueError(
                f"no notifier configured for destination {message.to!r}"
            )
        backend.send(message)
