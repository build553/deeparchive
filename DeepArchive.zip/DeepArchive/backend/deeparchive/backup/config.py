"""Backup / DR config: S3 versioning + cross-region replication (residency-aware).

Near-zero compute cost -- this is bucket CONFIG, not a running service. S3 does
the replication automatically; you pay only for the replica's storage
(~$1/TB/mo Deep Archive) + transfer. Versioning protects against accidental
delete/overwrite (~free for tiny manifests).

RESIDENCY RULE: a replica MUST stay in the same jurisdiction as the source, or
we'd break data residency. E.g. India (ap-south-1) replicates to another Indian
region (ap-south-2), NEVER the US. This module enforces that.
"""
from __future__ import annotations

from dataclasses import dataclass

# Same-jurisdiction DR pairs: source region -> allowed replica region.
# Both regions are in the same legal jurisdiction (residency-safe).
_DR_REPLICA = {
    "us-east-1": "us-west-2",       # US -> US
    "us-west-2": "us-east-1",
    "ap-south-1": "ap-south-2",     # India (Mumbai) -> India (Hyderabad)
    "ap-south-2": "ap-south-1",
    "eu-central-1": "eu-west-1",    # EU -> EU (GDPR jurisdiction)
    "eu-west-1": "eu-central-1",
    "eu-west-3": "eu-central-1",
}


class ResidencyViolationError(Exception):
    """Raised when a source region has no same-jurisdiction replica."""


@dataclass(frozen=True)
class ReplicationPlan:
    source_region: str
    source_bucket: str
    dest_region: str
    dest_bucket: str


def versioning_config() -> dict[str, str]:
    """S3 versioning config (protects against accidental delete/overwrite)."""
    return {"Status": "Enabled"}


def replica_region_for(source_region: str) -> str:
    """The residency-safe DR region for a source region, or raise."""
    dest = _DR_REPLICA.get(source_region)
    if dest is None:
        raise ResidencyViolationError(
            f"no same-jurisdiction replica for {source_region!r}"
        )
    return dest


def build_replication_plan(source_region: str, source_bucket: str) -> ReplicationPlan:
    """Build a residency-safe replication plan for a source bucket."""
    dest_region = replica_region_for(source_region)
    return ReplicationPlan(
        source_region=source_region,
        source_bucket=source_bucket,
        dest_region=dest_region,
        dest_bucket=f"{source_bucket}-dr-{dest_region}",
    )


def replication_config(plan: ReplicationPlan, role_arn: str) -> dict[str, object]:
    """S3 replication configuration: replicate data/ to the DR bucket as Deep
    Archive (cheap replica). Residency is guaranteed by build_replication_plan."""
    return {
        "Role": role_arn,
        "Rules": [
            {
                "ID": "dr-replicate-data",
                "Status": "Enabled",
                "Priority": 1,
                "Filter": {"Prefix": "data/"},
                "DeleteMarkerReplication": {"Status": "Disabled"},
                "Destination": {
                    "Bucket": f"arn:aws:s3:::{plan.dest_bucket}",
                    "StorageClass": "DEEP_ARCHIVE",
                },
            }
        ],
    }
