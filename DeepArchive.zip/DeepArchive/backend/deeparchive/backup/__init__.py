"""Backup: S3 versioning + residency-aware cross-region replication config."""
from deeparchive.backup.config import (
    ReplicationPlan,
    ResidencyViolationError,
    build_replication_plan,
    replica_region_for,
    replication_config,
    versioning_config,
)

__all__ = [
    "ReplicationPlan",
    "ResidencyViolationError",
    "build_replication_plan",
    "replica_region_for",
    "replication_config",
    "versioning_config",
]
