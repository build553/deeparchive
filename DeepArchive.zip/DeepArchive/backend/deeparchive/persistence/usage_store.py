"""DynamoDB-backed UsageMeter. Same interface as billing.UsageMeter, so nothing
above it changes -- just durable and SHARED across hosts.

This is what makes a plan purchased on one host visible on another: entitlements
and per-account usage live in DynamoDB, not per-process memory. Fixes the
"purchase succeeds but account shows no plan" flakiness in the multi-host fleet.

One table (<prefix>_billing), pk account_id, storing both the entitlement and
the running usage counters in a single item per account.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any

from deeparchive.billing.plans import Entitlement, PlanId
from deeparchive.billing.usage import (
    NoEntitlementError,
    QuotaExceededError,
    Usage,
)
from deeparchive.persistence import ddb


def _num(v: Any, default: int = 0) -> int:
    return int(v) if v is not None else default


class DdbUsageMeter:
    """Durable, shared UsageMeter backed by DynamoDB (drop-in for UsageMeter)."""

    def __init__(self, resource: Any = None):
        res = resource if resource is not None else ddb.resource()
        self._table = res.Table(ddb.table_name("billing"))

    # --- item helpers -----------------------------------------------------

    def _get(self, account_id: str) -> dict[str, Any]:
        resp = self._table.get_item(Key={"account_id": account_id})
        return resp.get("Item") or {}

    # --- entitlement ------------------------------------------------------

    def set_entitlement(self, ent: Entitlement) -> None:
        """Persist the entitlement, preserving any existing usage counters."""
        item = self._get(ent.account_id)
        item.update({
            "account_id": ent.account_id,
            "plan_id": ent.plan_id.value,
            "quota_bytes": ent.quota_bytes,
            "expires_at": Decimal(str(ent.expires_at)),
            "purchased_at": Decimal(str(ent.purchased_at)),
        })
        item.setdefault("stored_bytes", 0)
        item.setdefault("egress_bytes", 0)
        self._table.put_item(Item=item)

    def _active_entitlement(self, account_id: str, now: float | None = None) -> Entitlement:
        item = self._get(account_id)
        if "plan_id" not in item:
            raise NoEntitlementError(f"no active entitlement for {account_id}")
        ent = Entitlement(
            account_id=account_id,
            plan_id=PlanId(str(item["plan_id"])),
            quota_bytes=_num(item.get("quota_bytes")),
            expires_at=float(item.get("expires_at", 0)),
            purchased_at=float(item.get("purchased_at", 0)),
        )
        if not ent.is_active(now):
            raise NoEntitlementError(f"no active entitlement for {account_id}")
        return ent

    # --- usage ------------------------------------------------------------

    def usage(self, account_id: str) -> Usage:
        item = self._get(account_id)
        return Usage(
            stored_bytes=_num(item.get("stored_bytes")),
            egress_bytes=_num(item.get("egress_bytes")),
        )

    def check_and_record_upload(
        self, account_id: str, size_bytes: int, now: float | None = None
    ) -> None:
        ent = self._active_entitlement(account_id, now)
        stored = self.usage(account_id).stored_bytes
        if stored + size_bytes > ent.quota_bytes:
            raise QuotaExceededError(
                f"quota exceeded: {stored + size_bytes} > {ent.quota_bytes}"
            )
        # Atomic increment so concurrent uploads on different hosts don't clobber.
        self._table.update_item(
            Key={"account_id": account_id},
            UpdateExpression="SET stored_bytes = if_not_exists(stored_bytes, :z) + :n",
            ExpressionAttributeValues={":n": size_bytes, ":z": 0},
        )

    def record_egress(self, account_id: str, size_bytes: int) -> None:
        self._table.update_item(
            Key={"account_id": account_id},
            UpdateExpression="SET egress_bytes = if_not_exists(egress_bytes, :z) + :n",
            ExpressionAttributeValues={":n": size_bytes, ":z": 0},
        )

    def record_delete(self, account_id: str, size_bytes: int) -> None:
        stored = self.usage(account_id).stored_bytes
        new_val = max(0, stored - size_bytes)
        self._table.update_item(
            Key={"account_id": account_id},
            UpdateExpression="SET stored_bytes = :v",
            ExpressionAttributeValues={":v": new_val},
        )

    def remaining_quota(self, account_id: str, now: float | None = None) -> int:
        ent = self._active_entitlement(account_id, now)
        return max(0, ent.quota_bytes - self.usage(account_id).stored_bytes)

    def quota_fraction_used(self, account_id: str, now: float | None = None) -> float:
        ent = self._active_entitlement(account_id, now)
        if ent.quota_bytes <= 0:
            return 1.0
        return self.usage(account_id).stored_bytes / ent.quota_bytes
