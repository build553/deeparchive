"""DynamoDB-backed OrgStore. Same interface as the in-memory OrgStore.

Members and policy are stored inline on the org item (an org has a bounded set
of members; fine for a single item).
"""
from __future__ import annotations

from typing import Any

from deeparchive.accounts.orgs import (
    Member,
    Organization,
    RetentionPolicy,
    Role,
)
from deeparchive.manifest import RetentionClass
from deeparchive.persistence import ddb


class DdbOrgStore:
    """Durable OrgStore backed by DynamoDB."""

    def __init__(self, resource: Any = None):
        res = resource if resource is not None else ddb.resource()
        self._table = res.Table(ddb.table_name("orgs"))

    def put(self, org: Organization) -> None:
        self._table.put_item(
            Item={
                "account_id": org.account_id,
                "name": org.name,
                "default_retention": org.policy.default_retention.value,
                "default_legal_hold": org.policy.default_legal_hold,
                "members": {
                    ref: m.role.value for ref, m in org.members.items()
                },
            }
        )

    def get(self, account_id: str) -> Organization:
        resp = self._table.get_item(Key={"account_id": account_id})
        item = resp.get("Item")
        if item is None:
            raise KeyError(f"no org {account_id!r}")
        return self._to_org(item)

    @staticmethod
    def _to_org(item: dict[str, Any]) -> Organization:
        policy = RetentionPolicy(
            default_retention=RetentionClass(item["default_retention"]),
            default_legal_hold=bool(item["default_legal_hold"]),
        )
        org = Organization(
            account_id=str(item["account_id"]),
            name=str(item["name"]),
            policy=policy,
        )
        for ref, role in dict(item.get("members", {})).items():
            org.members[str(ref)] = Member(user_ref=str(ref), role=Role(role))
        return org
