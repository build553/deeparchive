"""DynamoDB-backed KeyStore. Same interface as the in-memory auth.KeyStore, so
nothing above it changes -- just durable and SHARED across hosts.

This is what lets an API key created on one host be validated on another: keys
live in DynamoDB (hashed), not per-process memory.
"""
from __future__ import annotations

from typing import Any

from deeparchive.persistence import ddb
from deeparchive.services.api.auth import AuthError, Principal, hash_key


class DdbKeyStore:
    """Durable KeyStore backed by DynamoDB. Maps hashed API key -> org_id."""

    def __init__(self, resource: Any = None):
        res = resource if resource is not None else ddb.resource()
        self._table = res.Table(ddb.table_name("keys"))

    def add_key(self, raw_key: str, org_id: str) -> None:
        self._table.put_item(Item={"key_hash": hash_key(raw_key), "org_id": org_id})

    def authenticate(self, raw_key: str | None) -> Principal:
        if not raw_key:
            raise AuthError("missing API key")
        resp = self._table.get_item(Key={"key_hash": hash_key(raw_key)})
        item = resp.get("Item")
        if item is None:
            raise AuthError("invalid API key")
        return Principal(org_id=str(item["org_id"]))
