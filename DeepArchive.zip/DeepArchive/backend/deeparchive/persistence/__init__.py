"""Persistence: DynamoDB-backed durable stores (endpoint-swappable).

Same code for real AWS DynamoDB and DynamoDB Local (our own server) / moto tests,
selected by config.DDB_ENDPOINT_URL. Implements the same store interfaces the
in-memory versions do, so nothing above changes.
"""
from deeparchive.persistence import factory
from deeparchive.persistence.account_store import DdbAccountStore
from deeparchive.persistence.ddb import create_tables, resource, table_name
from deeparchive.persistence.job_store import DdbJobStore
from deeparchive.persistence.key_store import DdbKeyStore
from deeparchive.persistence.org_store import DdbOrgStore
from deeparchive.persistence.usage_store import DdbUsageMeter

__all__ = [
    "DdbAccountStore",
    "DdbJobStore",
    "DdbKeyStore",
    "DdbOrgStore",
    "DdbUsageMeter",
    "create_tables",
    "factory",
    "resource",
    "table_name",
]
