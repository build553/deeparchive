"""DynamoDB-backed JobStore for restore records. Same interface as LocalJobStore
(put / get / list_by_status)."""
from __future__ import annotations

from typing import Any

from deeparchive.persistence import ddb
from deeparchive.restore.orchestrator import JobStatus, RestoreRecord


class DdbJobStore:
    """Durable restore-job store backed by DynamoDB."""

    def __init__(self, resource: Any = None):
        res = resource if resource is not None else ddb.resource()
        self._table = res.Table(ddb.table_name("jobs"))

    def put(self, record: RestoreRecord) -> None:
        self._table.put_item(
            Item={
                "job_id": record.job_id,
                "org_id": record.org_id,
                "tarball_key": record.tarball_key,
                "status": record.status.value,
                "created_at": str(record.created_at),
                "updated_at": str(record.updated_at),
                "attempts": record.attempts,
                "error": record.error,
            }
        )

    def get(self, job_id: str) -> RestoreRecord:
        resp = self._table.get_item(Key={"job_id": job_id})
        item = resp.get("Item")
        if item is None:
            raise KeyError(f"no restore job {job_id!r}")
        return self._to_record(item)

    def list_by_status(self, status: JobStatus) -> list[RestoreRecord]:
        from boto3.dynamodb.conditions import Key

        resp = self._table.query(
            IndexName="by_status",
            KeyConditionExpression=Key("status").eq(status.value),
        )
        return [self._to_record(i) for i in resp.get("Items", [])]

    @staticmethod
    def _to_record(item: dict[str, Any]) -> RestoreRecord:
        return RestoreRecord(
            job_id=str(item["job_id"]),
            org_id=str(item["org_id"]),
            tarball_key=str(item["tarball_key"]),
            status=JobStatus(item["status"]),
            created_at=float(item["created_at"]),
            updated_at=float(item["updated_at"]),
            attempts=int(item["attempts"]),
            error=str(item.get("error", "")),
        )
