"""Store factory: choose durable (DynamoDB) or in-memory stores.

If DynamoDB is configured (DEEPARCHIVE_USE_DDB=1, or an endpoint is set), return
the durable Ddb* stores; otherwise the in-memory ones (dev/tests). This is the
one place that decides persistence, so wiring stays in a single spot.
"""
from __future__ import annotations

import os
from typing import Any

from deeparchive import config
from deeparchive.accounts.accounts import AccountStore
from deeparchive.accounts.orgs import OrgStore


def _use_ddb() -> bool:
    return os.environ.get("DEEPARCHIVE_USE_DDB") == "1" or config.DDB_ENDPOINT_URL is not None


def account_store(resource: Any = None) -> Any:
    """Durable DdbAccountStore if DDB configured, else in-memory AccountStore."""
    if _use_ddb():
        from deeparchive.persistence import DdbAccountStore

        return DdbAccountStore(resource=resource)
    return AccountStore()


def org_store(resource: Any = None) -> Any:
    if _use_ddb():
        from deeparchive.persistence import DdbOrgStore

        return DdbOrgStore(resource=resource)
    return OrgStore()


def key_store(resource: Any = None) -> Any:
    """Durable DdbKeyStore if DDB configured, else in-memory KeyStore.

    This is what shares API keys across hosts: without it, a key created on one
    host is invisible to others (per-process memory)."""
    if _use_ddb():
        from deeparchive.persistence import DdbKeyStore

        return DdbKeyStore(resource=resource)
    from deeparchive.services.api.auth import KeyStore

    return KeyStore()


def job_store(resource: Any = None, local_path: str | None = None) -> Any:
    """Durable DdbJobStore if DDB configured, else LocalJobStore (file)."""
    if _use_ddb():
        from deeparchive.persistence import DdbJobStore

        return DdbJobStore(resource=resource)
    from deeparchive.restore.orchestrator import LocalJobStore

    return LocalJobStore(local_path or "/tmp/deeparchive_jobs.json")  # noqa: S108
