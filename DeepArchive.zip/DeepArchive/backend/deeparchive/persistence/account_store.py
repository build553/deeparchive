"""DynamoDB-backed AccountStore. Same interface as the in-memory AccountStore,
so nothing above it changes -- just durable.

Lookups use the GSIs created in persistence.ddb. provider_key is a composite
"<provider>#<provider_user_id>" so the by_provider GSI can match on one attr.
"""
from __future__ import annotations

from typing import Any

from deeparchive.accounts.accounts import Account
from deeparchive.persistence import ddb


def _provider_key(provider: str | None, provider_user_id: str | None) -> str | None:
    if provider and provider_user_id:
        return f"{provider}#{provider_user_id}"
    return None


class DdbAccountStore:
    """Durable AccountStore backed by DynamoDB (real AWS or local)."""

    def __init__(self, resource: Any = None):
        res = resource if resource is not None else ddb.resource()
        self._table = res.Table(ddb.table_name("accounts"))

    def put(self, account: Account) -> None:
        item: dict[str, Any] = {
            "account_id": account.account_id,
            "account_type": account.account_type.value,
            "country": account.country,
            "region": account.region,
            "created_at": str(account.created_at),
            "plan": account.plan,
        }
        # Only set indexed attrs when present (DDB GSI keys can't be empty/None).
        if account.email:
            item["email"] = account.email.lower()
        if account.phone:
            item["phone"] = account.phone
        pk = _provider_key(account.provider, account.provider_user_id)
        if pk:
            item["provider_key"] = pk
            item["provider"] = account.provider
            item["provider_user_id"] = account.provider_user_id
        self._table.put_item(Item=item)

    def get(self, account_id: str) -> Account:
        resp = self._table.get_item(Key={"account_id": account_id})
        item = resp.get("Item")
        if item is None:
            raise KeyError(f"no account {account_id!r}")
        return self._to_account(item)

    def find_by_email(self, email: str) -> Account | None:
        return self._query_gsi("by_email", "email", email.lower())

    def find_by_phone(self, phone: str) -> Account | None:
        return self._query_gsi("by_phone", "phone", phone)

    def find_by_provider(self, provider: str, provider_user_id: str) -> Account | None:
        key = _provider_key(provider, provider_user_id)
        if key is None:
            return None
        return self._query_gsi("by_provider", "provider_key", key)

    def _query_gsi(self, index: str, attr: str, value: str) -> Account | None:
        from boto3.dynamodb.conditions import Key

        resp = self._table.query(
            IndexName=index, KeyConditionExpression=Key(attr).eq(value), Limit=1
        )
        items = resp.get("Items", [])
        return self._to_account(items[0]) if items else None

    @staticmethod
    def _to_account(item: dict[str, Any]) -> Account:
        from deeparchive.accounts.accounts import AccountType

        return Account(
            account_id=str(item["account_id"]),
            account_type=AccountType(item["account_type"]),
            country=str(item["country"]),
            region=str(item["region"]),
            created_at=float(item["created_at"]),
            email=item.get("email"),
            phone=item.get("phone"),
            provider=item.get("provider"),
            provider_user_id=item.get("provider_user_id"),
            plan=str(item.get("plan", "free")),
        )
