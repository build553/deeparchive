"""DynamoDB connection + table setup, with endpoint-swap.

One code path serves three environments (via DEEPARCHIVE_DDB_ENDPOINT):
  - unset            -> real AWS DynamoDB
  - http://host:8000 -> DynamoDB Local (our own server) or moto in tests

Tables (prefix = config.DDB_TABLE_PREFIX):
  <prefix>_accounts  (pk account_id; GSIs: email, phone, provider)
  <prefix>_orgs      (pk account_id)
  <prefix>_jobs      (pk job_id; GSI: status)
"""
from __future__ import annotations

from typing import Any

import boto3

from deeparchive import config


def resource(endpoint_url: str | None = None, region: str = "us-east-1") -> Any:
    """Build a DynamoDB resource. endpoint_url set => local/moto; None => real AWS."""
    ep = endpoint_url if endpoint_url is not None else config.DDB_ENDPOINT_URL
    return boto3.resource("dynamodb", region_name=region, endpoint_url=ep)


def table_name(kind: str) -> str:
    return f"{config.DDB_TABLE_PREFIX}_{kind}"


def _gsi(name: str, key: str) -> dict[str, Any]:
    return {
        "IndexName": name,
        "KeySchema": [{"AttributeName": key, "KeyType": "HASH"}],
        "Projection": {"ProjectionType": "ALL"},
    }


def create_tables(ddb: Any) -> None:
    """Create the tables if they don't exist (idempotent). PAY_PER_REQUEST = no
    provisioned cost; free-tier friendly."""
    existing = {t.name for t in ddb.tables.all()}

    if table_name("accounts") not in existing:
        ddb.create_table(
            TableName=table_name("accounts"),
            KeySchema=[{"AttributeName": "account_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "account_id", "AttributeType": "S"},
                {"AttributeName": "email", "AttributeType": "S"},
                {"AttributeName": "phone", "AttributeType": "S"},
                {"AttributeName": "provider_key", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[
                _gsi("by_email", "email"),
                _gsi("by_phone", "phone"),
                _gsi("by_provider", "provider_key"),
            ],
            BillingMode="PAY_PER_REQUEST",
        ).wait_until_exists()

    if table_name("orgs") not in existing:
        ddb.create_table(
            TableName=table_name("orgs"),
            KeySchema=[{"AttributeName": "account_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "account_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        ).wait_until_exists()

    if table_name("jobs") not in existing:
        ddb.create_table(
            TableName=table_name("jobs"),
            KeySchema=[{"AttributeName": "job_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "status", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[_gsi("by_status", "status")],
            BillingMode="PAY_PER_REQUEST",
        ).wait_until_exists()

    if table_name("keys") not in existing:
        ddb.create_table(
            TableName=table_name("keys"),
            KeySchema=[{"AttributeName": "key_hash", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "key_hash", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        ).wait_until_exists()

    if table_name("billing") not in existing:
        ddb.create_table(
            TableName=table_name("billing"),
            KeySchema=[{"AttributeName": "account_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "account_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        ).wait_until_exists()
