"""Archive index: what has already been archived (for incremental + resume).

Borrowed approach from simple-serac: build a map of archive_path -> sha256 from
all known manifests. A file whose sha matches the index is already archived and
is skipped on the next run. This gives:
  - incremental backups (only new/changed files are packed)
  - resume (manifests of completed tarballs mean their files are skipped on rerun)

This module holds NO S3 logic; callers feed it manifests (loaded from db/ warm
storage or a local cache).
"""
from __future__ import annotations

from collections.abc import Iterable

from deeparchive.manifest import Manifest


class ArchiveIndex:
    """In-memory map of archive_path -> sha256 of already-archived files."""

    def __init__(self) -> None:
        self._by_path: dict[str, str] = {}

    @staticmethod
    def from_manifests(manifests: Iterable[Manifest]) -> ArchiveIndex:
        idx = ArchiveIndex()
        for m in manifests:
            for entry in m.files:
                idx._by_path[entry.path] = entry.sha256
        return idx

    def is_archived(self, archive_path: str, sha256: str) -> bool:
        """True if this exact file (same path + sha) is already archived."""
        return self._by_path.get(archive_path) == sha256

    def __len__(self) -> int:
        return len(self._by_path)
