"""Archive index: tracks already-archived files (sha) for incremental + resume.

Depends on: manifest. No S3 here.
"""
from deeparchive.index.index import ArchiveIndex

__all__ = ["ArchiveIndex"]
