"""Storage: all S3 / Glacier interaction (the only module that talks to boto3).

Region-aware: a Storage instance is bound to one region + bucket and refuses
cross-region uploads. Retries transient errors (adaptive) and translates boto3
failures into a transient/permanent taxonomy. Depends on: config, regions,
manifest, packer.
"""
from deeparchive.storage.errors import (
    PermanentStorageError,
    StorageError,
    TransientStorageError,
)
from deeparchive.storage.storage import RegionMismatchError, Storage

__all__ = [
    "PermanentStorageError",
    "RegionMismatchError",
    "Storage",
    "StorageError",
    "TransientStorageError",
]
