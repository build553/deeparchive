"""Storage error taxonomy.

boto3 raises ClientError for everything. We translate to two clear kinds so
callers can react correctly:
  - TransientStorageError: retryable (throttling, timeout, 5xx). boto3's adaptive
    retries handle most of these; if one still escapes, callers may retry.
  - PermanentStorageError: not retryable (AccessDenied, NoSuchKey, NoSuchBucket).
"""
from __future__ import annotations

from botocore.exceptions import BotoCoreError, ClientError

# S3/Glacier error codes that are safe to retry.
_TRANSIENT_CODES = frozenset(
    {
        "Throttling",
        "ThrottlingException",
        "RequestTimeout",
        "RequestTimeoutException",
        "SlowDown",
        "InternalError",
        "ServiceUnavailable",
        "503",
        "500",
    }
)


class StorageError(Exception):
    """Base class for storage failures."""


class TransientStorageError(StorageError):
    """A retryable failure (throttling, timeout, transient 5xx)."""


class PermanentStorageError(StorageError):
    """A non-retryable failure (auth, missing object/bucket, bad request)."""


def classify(exc: Exception) -> StorageError:
    """Translate a boto3 exception into our taxonomy."""
    if isinstance(exc, ClientError):
        code = exc.response.get("Error", {}).get("Code", "")
        if code in _TRANSIENT_CODES:
            return TransientStorageError(f"transient S3 error: {code}")
        return PermanentStorageError(f"permanent S3 error: {code}")
    if isinstance(exc, BotoCoreError):
        # Connection/endpoint errors are generally transient.
        return TransientStorageError(f"boto core error: {type(exc).__name__}")
    return StorageError(str(exc))
