"""Storage: the only module that talks to S3 / Glacier.

Region-aware and residency-enforcing: a Storage instance is bound to exactly one
region + bucket. Uploading a pack whose org lives in a different region is
refused, so data never crosses a border.

Uploads: tarball -> data/ (transitions to Deep Archive), manifest -> db/ (warm).
"""
from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import replace
from typing import TYPE_CHECKING, Literal, TypeVar

import boto3
from boto3.s3.transfer import TransferConfig
from botocore.config import Config as BotoConfig
from botocore.exceptions import BotoCoreError, ClientError

from deeparchive import config, regions
from deeparchive.crypto import KeyStore, decrypt, encrypt
from deeparchive.manifest import FileEntry, Manifest
from deeparchive.observability import METRICS, log_event
from deeparchive.packer import Pack
from deeparchive.storage.errors import PermanentStorageError, classify

if TYPE_CHECKING:
    from mypy_boto3_s3.client import S3Client

T = TypeVar("T")


class RegionMismatchError(Exception):
    """Raised when a pack is uploaded to a region other than its org's region."""


def _boto_config() -> BotoConfig:
    """Adaptive retries handle throttling/5xx automatically (AWS-recommended)."""
    return BotoConfig(
        retries={"max_attempts": config.S3_MAX_ATTEMPTS, "mode": "adaptive"},
    )


class Storage:
    """S3/Glacier access bound to a single region + bucket."""

    def __init__(
        self,
        region_info: regions.RegionInfo,
        s3: S3Client | None = None,
        key_store: KeyStore | None = None,
    ):
        self._info = region_info
        self._s3: S3Client = s3 or boto3.client(
            "s3", region_name=region_info.region, config=_boto_config()
        )
        self._key_store = key_store

    @staticmethod
    def for_country(
        country: str,
        s3: S3Client | None = None,
        key_store: KeyStore | None = None,
    ) -> Storage:
        """Build Storage for a country's active in-country region (or raise)."""
        return Storage(regions.resolve(country), s3=s3, key_store=key_store)

    @property
    def bucket(self) -> str:
        return self._info.bucket

    @property
    def region(self) -> str:
        return self._info.region

    def customer_key(self, org_id: str) -> bytes:
        """Fetch the customer's encryption key (requires a configured key store)."""
        if self._key_store is None:
            raise PermanentStorageError("no key store configured for decryption")
        return self._key_store.get_key(org_id)

    @staticmethod
    def _guard(fn: Callable[[], T]) -> T:
        """Run a boto3 call, translating failures into our error taxonomy."""
        try:
            return fn()
        except (ClientError, BotoCoreError) as exc:
            raise classify(exc) from exc

    def upload_pack(self, pack: Pack) -> None:
        """Upload a pack's tarball (cold) and manifest (warm) into this region.

        If a key store is configured, the tarball is encrypted with the customer's
        key before upload and the GCM nonce is recorded in the manifest. The
        tarball uses multipart transfer for reliable large uploads.
        """
        tarball_key = pack.manifest.tarball_key
        manifest = pack.manifest
        manifest_key = f"{config.INDEX_PREFIX}{manifest.org_id}/{manifest.pack_id}.json"

        upload_path = pack.tarball_path
        tmp_encrypted: str | None = None
        if self._key_store is not None:
            key = self._key_store.get_or_create_key(manifest.org_id)
            with open(pack.tarball_path, "rb") as f:
                enc = encrypt(f.read(), key)
            tmp_encrypted = pack.tarball_path + ".enc"
            with open(tmp_encrypted, "wb") as f:
                f.write(enc.ciphertext)
            upload_path = tmp_encrypted
            manifest = replace(manifest, encryption_nonce=enc.nonce)

        transfer = TransferConfig(
            multipart_threshold=config.MULTIPART_THRESHOLD_BYTES,
            multipart_chunksize=config.MULTIPART_CHUNK_BYTES,
            max_concurrency=config.MULTIPART_MAX_CONCURRENCY,
            use_threads=True,
        )
        try:
            self._guard(
                lambda: self._s3.upload_file(
                    Filename=upload_path,
                    Bucket=self._info.bucket,
                    Key=tarball_key,
                    Config=transfer,
                )
            )
            self._guard(
                lambda: self._s3.put_object(
                    Bucket=self._info.bucket,
                    Key=manifest_key,
                    Body=manifest.to_json().encode("utf-8"),
                )
            )
        finally:
            if tmp_encrypted is not None and os.path.exists(tmp_encrypted):
                os.remove(tmp_encrypted)

        log_event(
            "pack_uploaded",
            org_id=manifest.org_id,
            region=self._info.region,
            tarball_key=tarball_key,
            bytes=manifest.tarball_bytes,
            encrypted=bool(manifest.encryption_nonce),
        )
        METRICS.incr("uploads")

    def start_restore(self, tarball_key: str) -> None:
        """Kick off a Bulk-tier restore of a Deep Archive object (48h SLA)."""
        tier: Literal["Bulk", "Expedited", "Standard"] = "Bulk"
        self._guard(
            lambda: self._s3.restore_object(
                Bucket=self._info.bucket,
                Key=tarball_key,
                RestoreRequest={
                    "Days": config.RESTORE_AVAILABILITY_DAYS,
                    "GlacierJobParameters": {"Tier": tier},
                },
            )
        )

    def restore_ready(self, tarball_key: str) -> bool:
        """True once the object can be read directly.

        Warm tiers (STANDARD, STANDARD_IA, etc.) are always readable. Cold tiers
        (GLACIER, DEEP_ARCHIVE) are only readable after a restore, which S3
        reports on the `Restore` header:
          'ongoing-request="true"'  -> still restoring
          'ongoing-request="false"' -> restored copy is ready
        """
        head = self._guard(
            lambda: self._s3.head_object(Bucket=self._info.bucket, Key=tarball_key)
        )
        # Warm storage classes are immediately readable -- no restore needed.
        # S3 omits StorageClass for STANDARD, so absence => STANDARD => ready.
        storage_class = head.get("StorageClass", "STANDARD")
        if storage_class not in ("GLACIER", "DEEP_ARCHIVE"):
            return True
        # Cold tier: ready only if a restore has completed.
        restore = head.get("Restore")
        if restore is None:
            return False
        return 'ongoing-request="false"' in restore

    def download(self, tarball_key: str, dest_path: str) -> None:
        """Download a (restored) object to local disk."""
        self._guard(
            lambda: self._s3.download_file(self._info.bucket, tarball_key, dest_path)
        )

    def presigned_put_url(self, tarball_key: str, expires_in: int = 3600) -> str:
        """A presigned URL the client uses to PUT the tarball straight to S3.

        Big bytes bypass our compute entirely -- the client uploads directly to
        S3, then calls /v1/packs/complete with the manifest.
        """
        return self._guard(
            lambda: self._s3.generate_presigned_url(
                "put_object",
                Params={"Bucket": self._info.bucket, "Key": tarball_key},
                ExpiresIn=expires_in,
            )
        )

    def extract_file(
        self, org_id: str, tarball_key: str, offset: int, length: int, nonce: str = ""
    ) -> bytes:
        """Extract one file's bytes from a RESTORED tarball, then decrypt.

        NOTE: a per-object-encrypted tarball must be decrypted as a whole (the
        GCM nonce covers the full tarball), so when encrypted we fetch the whole
        object and slice after decrypt. When unencrypted, we use a ranged GET to
        fetch ONLY the file's bytes (cheap). Requires the tarball to be READY.
        """
        if nonce and self._key_store is not None:
            # Encrypted: whole-object decrypt, then slice by offset/length.
            obj = self._guard(
                lambda: self._s3.get_object(Bucket=self._info.bucket, Key=tarball_key)
            )
            key = self._key_store.get_key(org_id)
            plaintext = decrypt(bytes(obj["Body"].read()), key, nonce)
            return plaintext[offset : offset + length]
        # Unencrypted: ranged GET fetches only this file's bytes.
        rng = f"bytes={offset}-{offset + length - 1}"
        obj = self._guard(
            lambda: self._s3.get_object(
                Bucket=self._info.bucket, Key=tarball_key, Range=rng
            )
        )
        return bytes(obj["Body"].read())

    def presigned_get_url(self, tarball_key: str, expires_in: int = 3600) -> str:
        """A presigned URL to DOWNLOAD a restored object (short TTL)."""
        return self._guard(
            lambda: self._s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": self._info.bucket, "Key": tarball_key},
                ExpiresIn=expires_in,
            )
        )

    def register_manifest(self, manifest: Manifest) -> None:
        """Store a manifest in db/ (warm) after the client uploaded the tarball."""
        manifest_key = f"{config.INDEX_PREFIX}{manifest.org_id}/{manifest.pack_id}.json"
        self._guard(
            lambda: self._s3.put_object(
                Bucket=self._info.bucket,
                Key=manifest_key,
                Body=manifest.to_json().encode("utf-8"),
            )
        )
        log_event("manifest_registered", org_id=manifest.org_id, pack_id=manifest.pack_id)
        METRICS.incr("manifests_registered")

    def get_manifest(self, org_id: str, pack_id: str) -> Manifest:
        """Read a manifest from db/ (warm, instant)."""
        key = f"{config.INDEX_PREFIX}{org_id}/{pack_id}.json"
        obj = self._guard(
            lambda: self._s3.get_object(Bucket=self._info.bucket, Key=key)
        )
        return Manifest.from_json(obj["Body"].read().decode("utf-8"))

    def list_manifests(self, org_id: str) -> list[Manifest]:
        """Read all of an org's manifests from db/ (warm)."""
        prefix = f"{config.INDEX_PREFIX}{org_id}/"
        resp = self._guard(
            lambda: self._s3.list_objects_v2(Bucket=self._info.bucket, Prefix=prefix)
        )
        manifests: list[Manifest] = []
        for obj in resp.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".json"):
                manifests.append(self._get_manifest_by_key(key))
        return manifests

    def _get_manifest_by_key(self, key: str) -> Manifest:
        obj = self._guard(
            lambda: self._s3.get_object(Bucket=self._info.bucket, Key=key)
        )
        return Manifest.from_json(obj["Body"].read().decode("utf-8"))

    def soft_delete(self, org_id: str, pack_id: str) -> None:
        """Mark a pack deleted but keep the data (recoverable within the SLA).

        We tag the manifest with a soft-delete marker in db/ (warm); the cold
        tarball is untouched, so a restore is still possible within the window.
        """
        manifest = self.get_manifest(org_id, pack_id)
        marker_key = f"{config.INDEX_PREFIX}{org_id}/{pack_id}.deleted"
        self._guard(
            lambda: self._s3.put_object(
                Bucket=self._info.bucket, Key=marker_key, Body=b"soft-deleted"
            )
        )
        log_event("pack_soft_deleted", org_id=org_id, pack_id=pack_id,
                  tarball_key=manifest.tarball_key)
        METRICS.incr("soft_deletes")

    def hard_delete(self, org_id: str, pack_id: str) -> None:
        """Irreversibly purge a pack's tarball + manifest. Blocked on legal hold."""
        manifest = self.get_manifest(org_id, pack_id)
        if manifest.legal_hold:
            raise PermanentStorageError(
                f"pack {pack_id} is under legal hold; hard delete forbidden"
            )
        tarball_key = manifest.tarball_key
        manifest_key = f"{config.INDEX_PREFIX}{org_id}/{pack_id}.json"
        self._guard(
            lambda: self._s3.delete_object(Bucket=self._info.bucket, Key=tarball_key)
        )
        self._guard(
            lambda: self._s3.delete_object(Bucket=self._info.bucket, Key=manifest_key)
        )
        log_event("pack_hard_deleted", org_id=org_id, pack_id=pack_id,
                  tarball_key=tarball_key)
        METRICS.incr("hard_deletes")

    def find_file(self, org_id: str, archive_path: str) -> tuple[Manifest, FileEntry] | None:
        """Find which tarball holds a file (searches the org's warm manifests).

        Returns (manifest, file_entry) or None. file_entry has offset/length/sha256.
        """
        for m in self.list_manifests(org_id):
            for entry in m.files:
                if entry.path == archive_path:
                    return m, entry
        return None

    # --- Thumbnails / previews (warm, so the vault is browsable) ---
    def put_thumbnail(self, org_id: str, archive_path: str, image_bytes: bytes) -> str:
        """Store a small preview in the warm thumbs/ prefix. Returns its key."""
        key = f"{config.THUMBS_PREFIX}{org_id}/{archive_path}"
        self._guard(
            lambda: self._s3.put_object(
                Bucket=self._info.bucket,
                Key=key,
                Body=image_bytes,
                StorageClass="STANDARD_IA",
            )
        )
        METRICS.incr("thumbnails_stored")
        return key

    def get_thumbnail(self, org_id: str, archive_path: str) -> bytes:
        """Fetch a preview (instant -- it's warm, never in Glacier)."""
        key = f"{config.THUMBS_PREFIX}{org_id}/{archive_path}"
        obj = self._guard(
            lambda: self._s3.get_object(Bucket=self._info.bucket, Key=key)
        )
        return bytes(obj["Body"].read())
