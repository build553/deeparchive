"""SDK client configuration (boto3 Config-style)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    """Tunable client behavior."""

    endpoint: str = "https://api.deeparchive.example"
    region_country: str = "US"          # caller's country (drives residency/pricing)
    pack_size_bytes: int = 256 * 1024 * 1024
    max_retries: int = 3
    timeout_seconds: float = 30.0
