"""SDK exceptions (boto3-style).

DeepArchiveError is the base (like botocore's BotoCoreError). ClientError wraps
an API error response with a code + message + HTTP status, mirroring boto3's
ClientError so callers can branch on `err.code`.
"""
from __future__ import annotations


class DeepArchiveError(Exception):
    """Base class for all SDK errors."""


class ClientError(DeepArchiveError):
    """An error returned by the DeepArchive API (non-2xx response)."""

    def __init__(self, code: str, message: str, status_code: int):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.status_code = status_code


class AuthError(ClientError):
    """401 -- missing/invalid API key."""


class QuotaError(ClientError):
    """402 -- no active plan or quota exceeded."""


class NotFoundError(ClientError):
    """404 -- resource not found."""
