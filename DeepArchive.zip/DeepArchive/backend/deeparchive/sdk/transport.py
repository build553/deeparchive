"""HTTP transport for the SDK.

Wraps httpx: adds the Bearer auth header, retries transient failures, and maps
non-2xx responses to typed SDK exceptions (boto3-style). Injectable http client
so tests can stub it without real network.
"""
from __future__ import annotations

import time
from typing import Any, Protocol

from deeparchive.sdk.config import Config
from deeparchive.sdk.errors import (
    AuthError,
    ClientError,
    NotFoundError,
    QuotaError,
)

_RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})


class HttpResponse(Protocol):
    status_code: int
    content: bytes

    def json(self) -> Any: ...


class HttpClient(Protocol):
    def request(
        self, method: str, url: str, headers: dict[str, str],
        json: dict[str, Any] | None = None, content: bytes | None = None,
    ) -> HttpResponse: ...


def _raise_for_status(resp: HttpResponse) -> None:
    if 200 <= resp.status_code < 300:
        return
    try:
        detail = resp.json().get("detail", "")
    except Exception:  # noqa: BLE001
        detail = resp.content.decode("utf-8", "replace")
    code = str(detail) or f"HTTP {resp.status_code}"
    status = resp.status_code
    if status == 401:
        raise AuthError("AuthError", code, status)
    if status == 402:
        raise QuotaError("QuotaError", code, status)
    if status == 404:
        raise NotFoundError("NotFound", code, status)
    raise ClientError("ClientError", code, status)


class Transport:
    """Authenticated, retrying HTTP transport."""

    def __init__(self, api_key: str, config: Config, http: HttpClient):
        self._api_key = api_key
        self._config = config
        self._http = http

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self._api_key}"}
        if extra:
            headers.update(extra)
        return headers

    def call(
        self, method: str, path: str,
        json: dict[str, Any] | None = None,
        content: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> HttpResponse:
        url = self._config.endpoint.rstrip("/") + path
        attempt = 0
        while True:
            attempt += 1
            resp = self._http.request(
                method, url, headers=self._headers(headers), json=json, content=content
            )
            if resp.status_code in _RETRYABLE_STATUS and attempt <= self._config.max_retries:
                time.sleep(min(2 ** (attempt - 1) * 0.05, 1.0))
                continue
            _raise_for_status(resp)
            return resp
