"""DeepArchive SDK Client (boto3-style).

Usage (mirrors boto3.client):
    from deeparchive.sdk import Client
    client = Client(api_key="dak_...", endpoint="https://api...", country="IN")
    client.put("statements/jan.pdf", data=pdf_bytes, retention="7y")
    client.flush()

The client hides packing: put() buffers files, flush() packs them client-side
into ~256MB tarballs and uploads via presigned URLs. Read methods (restore,
find_file, account) return dict responses; errors raise typed exceptions.
"""
from __future__ import annotations

from types import TracebackType
from typing import TYPE_CHECKING, Any

from deeparchive.sdk.config import Config
from deeparchive.sdk.transport import HttpClient, Transport

if TYPE_CHECKING:
    from deeparchive.staging.staging import StagedFile


class Client:
    """The DeepArchive API client."""

    def __init__(
        self,
        api_key: str,
        org_id: str,
        endpoint: str | None = None,
        country: str | None = None,
        config: Config | None = None,
        http: HttpClient | None = None,
    ):
        if config is None:
            config = Config(
                endpoint=endpoint or Config.endpoint,
                region_country=country or Config.region_country,
            )
        elif endpoint or country:
            config = Config(
                endpoint=endpoint or config.endpoint,
                region_country=country or config.region_country,
                pack_size_bytes=config.pack_size_bytes,
                max_retries=config.max_retries,
                timeout_seconds=config.timeout_seconds,
            )
        self._config = config
        self._api_key = api_key
        self._org_id_value = org_id
        if http is None:  # pragma: no cover - real httpx only at runtime
            import httpx

            http = _HttpxAdapter(httpx.Client(timeout=config.timeout_seconds))
        self._transport = Transport(api_key, config, http)
        self._buffer: list[StagedFile] = []

    @property
    def country(self) -> str:
        return self._config.region_country

    def put(
        self,
        path: str,
        data: bytes,
        retention: str = "7y",
        legal_hold: bool = False,
    ) -> None:
        """Buffer a file for archiving. Packed + uploaded on flush().

        Feels per-file to the caller; the SDK bundles into ~256MB tarballs.
        """
        import os
        import tempfile

        from deeparchive.manifest import RetentionClass
        from deeparchive.staging.staging import StagedFile

        tmp_dir = self._staging_dir()
        # Persist bytes to a temp file so the packer can tar them.
        fd, local = tempfile.mkstemp(dir=tmp_dir)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        self._buffer.append(
            StagedFile(
                local_path=local,
                archive_path=path,
                size=len(data),
                retention=RetentionClass(retention),
                staged_at=0.0,
                legal_hold=legal_hold,
            )
        )

    def flush(self) -> int:
        """Pack buffered files client-side and upload them. Returns packs sent."""
        if not self._buffer:
            return 0
        import os
        import tempfile

        from deeparchive.packer import SourceFile
        from deeparchive.packer import pack as pack_files

        sources = [
            SourceFile(
                local_path=s.local_path, archive_path=s.archive_path,
                retention=s.retention, legal_hold=s.legal_hold,
            )
            for s in self._buffer
        ]
        out_dir = tempfile.mkdtemp(prefix="da_sdk_flush_")
        packs = pack_files(
            sources, out_dir=out_dir, org_id=self._org_id_value,
            pack_size=self._config.pack_size_bytes,
        )
        for p in packs:
            self._upload_pack(p)
        for s in self._buffer:
            if os.path.exists(s.local_path):
                os.remove(s.local_path)
        self._buffer.clear()
        return len(packs)

    def _upload_pack(self, pack: Any) -> None:
        """Presigned flow: get URL -> PUT tarball bytes -> register manifest."""
        manifest = pack.manifest
        country = self._config.region_country
        resp = self._transport.call(
            "POST", "/v1/packs/upload-url",
            json={"country": country, "tarball_key": manifest.tarball_key},
        )
        url = resp.json()["url"]
        with open(pack.tarball_path, "rb") as f:
            body = f.read()
        # Presigned URLs are absolute -> PUT directly via the raw http client.
        self._transport._http.request("PUT", url, headers={}, content=body)  # noqa: SLF001
        self._transport.call(
            "POST", "/v1/packs/complete",
            json={"country": country, "manifest_json": manifest.to_json()},
        )

    def _staging_dir(self) -> str:
        import tempfile

        if not hasattr(self, "_stage_dir"):
            self._stage_dir = tempfile.mkdtemp(prefix="da_sdk_stage_")
        return self._stage_dir

    # --- Read / restore methods (boto3-style: return dict responses) ---
    def find_file(self, path: str) -> dict[str, Any]:
        """Locate a file in the archive (which tarball, offset, size, hash)."""
        resp = self._transport.call(
            "GET", f"/v1/files?path={path}&country={self._config.region_country}"
        )
        return dict(resp.json())

    def restore(self, tarball_key: str) -> dict[str, Any]:
        """Start a restore (48h SLA). Returns the job state (may be PENDING_APPROVAL)."""
        resp = self._transport.call(
            "POST", "/v1/restore",
            json={"country": self._config.region_country, "tarball_key": tarball_key},
        )
        return dict(resp.json())

    def restore_status(self, tarball_key: str) -> dict[str, Any]:
        """Poll a restore's state (RESTORING / READY)."""
        resp = self._transport.call(
            "GET", f"/v1/restore/{tarball_key}?country={self._config.region_country}"
        )
        return dict(resp.json())

    def account(self) -> dict[str, Any]:
        """Billing account: quota, used, remaining, egress."""
        return dict(self._transport.call("GET", "/v1/billing/account").json())

    def purchase(self, plan_id: str, payment_token: str, units: int = 1) -> dict[str, Any]:
        """Buy a prepaid plan."""
        resp = self._transport.call(
            "POST", "/v1/billing/purchase",
            json={"plan_id": plan_id, "payment_token": payment_token, "units": units},
        )
        return dict(resp.json())

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException | None],
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.flush()


class _HttpxAdapter:  # pragma: no cover - thin runtime wrapper over httpx
    """Adapts httpx.Client to the HttpClient protocol."""

    def __init__(self, client: Any):
        self._client = client

    def request(
        self, method: str, url: str, headers: dict[str, str],
        json: dict[str, Any] | None = None, content: bytes | None = None,
    ) -> Any:
        return self._client.request(method, url, headers=headers, json=json, content=content)
