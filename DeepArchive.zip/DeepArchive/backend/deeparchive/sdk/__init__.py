"""DeepArchive SDK: boto3-style client for customers to integrate.

    from deeparchive.sdk import Client
    client = Client(api_key="dak_...", country="IN")
    client.put("path", data=b"...", retention="7y")
    client.flush()
"""
from deeparchive.sdk.client import Client
from deeparchive.sdk.config import Config
from deeparchive.sdk.errors import (
    AuthError,
    ClientError,
    DeepArchiveError,
    NotFoundError,
    QuotaError,
)

__all__ = [
    "AuthError",
    "Client",
    "ClientError",
    "Config",
    "DeepArchiveError",
    "NotFoundError",
    "QuotaError",
]
