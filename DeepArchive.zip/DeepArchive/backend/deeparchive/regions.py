"""Region registry: maps countries to their nearest AWS region.

Design: strict residency. We only serve a country when we have an in-country
(or same-jurisdiction, for the EU) region and it is marked active. Countries
without an in-country region are listed for planning but are NOT active, so we
never silently move data across a border.

Launch (active) regions: US, India, EU.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RegionInfo:
    """A country's archival home."""

    country: str          # ISO 3166-1 alpha-2
    region: str           # AWS region id
    bucket: str           # bucket name in that region
    in_country: bool      # is the region physically in this country's jurisdiction?
    active: bool          # are we live in this region today?


# ISO country -> RegionInfo. `active=True` means we serve it now.
# `in_country=False` means the nearest region is in another country (residency
# risk) -- these stay inactive under the strict model until AWS has a local region.
REGISTRY: dict[str, RegionInfo] = {
    # --- ACTIVE at launch ---
    "US": RegionInfo("US", "us-east-1", "deeparchive-us-east-1", True, True),
    "IN": RegionInfo("IN", "ap-south-1", "deeparchive-ap-south-1", True, True),
    # EU: Frankfurt satisfies EU (GDPR) residency for the bloc.
    "DE": RegionInfo("DE", "eu-central-1", "deeparchive-eu-central-1", True, True),
    "FR": RegionInfo("FR", "eu-west-3", "deeparchive-eu-west-3", True, True),
    "IE": RegionInfo("IE", "eu-west-1", "deeparchive-eu-west-1", True, True),

    # --- Planned: in-country region exists, not yet activated ---
    "GB": RegionInfo("GB", "eu-west-2", "deeparchive-eu-west-2", True, False),
    "JP": RegionInfo("JP", "ap-northeast-1", "deeparchive-ap-northeast-1", True, False),
    "KR": RegionInfo("KR", "ap-northeast-2", "deeparchive-ap-northeast-2", True, False),
    "SG": RegionInfo("SG", "ap-southeast-1", "deeparchive-ap-southeast-1", True, False),
    "AU": RegionInfo("AU", "ap-southeast-2", "deeparchive-ap-southeast-2", True, False),
    "BR": RegionInfo("BR", "sa-east-1", "deeparchive-sa-east-1", True, False),
    "CA": RegionInfo("CA", "ca-central-1", "deeparchive-ca-central-1", True, False),
    "AE": RegionInfo("AE", "me-central-1", "deeparchive-me-central-1", True, False),
    "ZA": RegionInfo("ZA", "af-south-1", "deeparchive-af-south-1", True, False),

    # --- No in-country region (nearest is cross-border): NOT served (strict) ---
    "NG": RegionInfo("NG", "af-south-1", "deeparchive-af-south-1", False, False),
    "NZ": RegionInfo("NZ", "ap-southeast-2", "deeparchive-ap-southeast-2", False, False),
}


class CountryNotServedError(Exception):
    """Raised when a country has no active in-country region."""


def _bucket_override() -> str | None:
    """A single-bucket deployment override.

    In our current lab/single-region deployment there is ONE real bucket
    (config.BUCKET, e.g. deep-archive-lab-<acct>) rather than the per-region
    buckets named in the registry. When DEEPARCHIVE_BUCKET is set, all resolved
    regions use it, so Storage talks to a bucket that actually exists. Residency
    rules below are still enforced; only the physical bucket name is overridden.
    """
    from deeparchive import config
    # Only override when explicitly configured away from the library default.
    return config.BUCKET if config.BUCKET != "deep-archive-lab" else None


def resolve(country: str) -> RegionInfo:
    """Return the active RegionInfo for a country, or raise if not served."""
    key = country.upper()
    info = REGISTRY.get(key)
    if info is None:
        raise CountryNotServedError(f"Country {key!r} is not in the region registry")
    if not info.active:
        raise CountryNotServedError(f"Country {key!r} is not yet served (no active region)")
    if not info.in_country:
        raise CountryNotServedError(
            f"Country {key!r} has no in-country region; strict residency forbids serving"
        )
    # Single-bucket deployment: point at the one real bucket, keep the region.
    override = _bucket_override()
    if override is not None:
        from deeparchive import config
        return RegionInfo(
            country=info.country,
            region=config.REGION,
            bucket=override,
            in_country=info.in_country,
            active=info.active,
        )
    return info


def active_countries() -> list[str]:
    """Countries we serve today."""
    return sorted(c for c, r in REGISTRY.items() if r.active and r.in_country)
