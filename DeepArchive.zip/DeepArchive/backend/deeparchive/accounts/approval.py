"""Restore approval workflow: org egress governance.

Egress is the expensive operation. In an org, a restore whose size exceeds the
policy threshold must be APPROVED by an admin before it runs -- so no single
member can trigger a huge bill. Small restores auto-approve.

States: PENDING_APPROVAL -> APPROVED (admin) / REJECTED (admin).
Approval is checked BEFORE the orchestrator starts the Glacier restore.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum

from deeparchive.accounts.orgs import Organization


class ApprovalState(str, Enum):
    AUTO_APPROVED = "AUTO_APPROVED"      # under threshold, no approval needed
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


@dataclass
class ApprovalRequest:
    request_id: str
    org_id: str
    requested_by: str
    tarball_key: str
    size_bytes: int
    state: ApprovalState
    created_at: float
    decided_by: str = ""

    def to_dict(self) -> dict[str, object]:
        d = asdict(self)
        d["state"] = self.state.value
        return d


class NotAuthorizedError(Exception):
    """Raised when a non-admin tries to approve/reject."""


@dataclass
class ApprovalService:
    """Gates restores by size against an org's approval threshold."""

    org: Organization
    threshold_bytes: int = 1024 * 1024 * 1024  # 1 GiB: above this needs approval
    _requests: dict[str, ApprovalRequest] = field(default_factory=dict)

    def request(self, requested_by: str, tarball_key: str, size_bytes: int) -> ApprovalRequest:
        """Create a restore-approval request. Auto-approves under threshold."""
        state = (
            ApprovalState.AUTO_APPROVED
            if size_bytes < self.threshold_bytes
            else ApprovalState.PENDING_APPROVAL
        )
        req = ApprovalRequest(
            request_id=f"apr_{uuid.uuid4().hex[:16]}",
            org_id=self.org.account_id,
            requested_by=requested_by,
            tarball_key=tarball_key,
            size_bytes=size_bytes,
            state=state,
            created_at=time.time(),
        )
        self._requests[req.request_id] = req
        return req

    def approve(self, request_id: str, admin_ref: str) -> ApprovalRequest:
        return self._decide(request_id, admin_ref, ApprovalState.APPROVED)

    def reject(self, request_id: str, admin_ref: str) -> ApprovalRequest:
        return self._decide(request_id, admin_ref, ApprovalState.REJECTED)

    def _decide(self, request_id: str, admin_ref: str, decision: ApprovalState) -> ApprovalRequest:
        if not self.org.may_manage(admin_ref):
            raise NotAuthorizedError(f"{admin_ref} is not an admin of this org")
        req = self._requests[request_id]
        req.state = decision
        req.decided_by = admin_ref
        return req

    def is_cleared(self, request_id: str) -> bool:
        """True if the restore may proceed (auto-approved or admin-approved)."""
        req = self._requests[request_id]
        return req.state in (ApprovalState.AUTO_APPROVED, ApprovalState.APPROVED)
