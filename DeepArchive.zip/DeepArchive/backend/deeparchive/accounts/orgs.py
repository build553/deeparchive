"""Organizations: enterprise accounts where company rules apply.

An org is an ENTERPRISE account (same account_id spine) plus:
  - members (people) each with a Role
  - a retention policy (default retention class + legal-hold default)
  - role-gated restore (egress is expensive -> only certain roles may restore)

Orgs are admin-provisioned (not self-service). Members typically join via SSO
(reuses the social/OIDC core); here we model membership + roles + policy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from deeparchive.accounts.accounts import AccountService, AccountType
from deeparchive.manifest import RetentionClass


class Role(str, Enum):
    ADMIN = "admin"      # manage members, policy; may restore + delete
    MEMBER = "member"    # may archive + restore
    VIEWER = "viewer"    # may browse the index only; no restore/delete


# Which roles may perform the cost-sensitive / destructive actions.
_MAY_RESTORE = {Role.ADMIN, Role.MEMBER}
_MAY_DELETE = {Role.ADMIN}
_MAY_MANAGE = {Role.ADMIN}


@dataclass(frozen=True)
class RetentionPolicy:
    """Company rules for how this org's data is retained."""

    default_retention: RetentionClass = RetentionClass.SEVEN_YEAR
    default_legal_hold: bool = False


@dataclass
class Member:
    user_ref: str    # provider user id / email / internal user handle
    role: Role


@dataclass
class Organization:
    """An enterprise org keyed by its account_id."""

    account_id: str
    name: str
    policy: RetentionPolicy = field(default_factory=RetentionPolicy)
    members: dict[str, Member] = field(default_factory=dict)

    def add_member(self, user_ref: str, role: Role) -> Member:
        member = Member(user_ref=user_ref, role=role)
        self.members[user_ref] = member
        return member

    def role_of(self, user_ref: str) -> Role | None:
        m = self.members.get(user_ref)
        return m.role if m else None

    def may_restore(self, user_ref: str) -> bool:
        return self.role_of(user_ref) in _MAY_RESTORE

    def may_delete(self, user_ref: str) -> bool:
        return self.role_of(user_ref) in _MAY_DELETE

    def may_manage(self, user_ref: str) -> bool:
        return self.role_of(user_ref) in _MAY_MANAGE


class OrgStore:
    """Persistence for orgs. In-memory; DynamoDB-swappable."""

    def __init__(self) -> None:
        self._by_id: dict[str, Organization] = {}

    def put(self, org: Organization) -> None:
        self._by_id[org.account_id] = org

    def get(self, account_id: str) -> Organization:
        if account_id not in self._by_id:
            raise KeyError(f"no org {account_id!r}")
        return self._by_id[account_id]


@dataclass
class OrgService:
    """Provisions org accounts and manages members/roles. Admin-driven."""

    accounts: AccountService
    orgs: OrgStore

    def create_org(
        self,
        name: str,
        country: str,
        admin_user_ref: str,
        policy: RetentionPolicy | None = None,
    ) -> tuple[Organization, str]:
        """Provision an ENTERPRISE account + org, with the creator as admin.

        Returns (organization, one_time_api_key) -- the org API key is used by
        the org's automated jobs (e.g. a bank's batch archiver).
        """
        new = self.accounts.create(
            country=country, account_type=AccountType.ENTERPRISE, email=None
        )
        org = Organization(
            account_id=new.account.account_id,
            name=name,
            policy=policy or RetentionPolicy(),
        )
        org.add_member(admin_user_ref, Role.ADMIN)
        self.orgs.put(org)
        return org, new.api_key
