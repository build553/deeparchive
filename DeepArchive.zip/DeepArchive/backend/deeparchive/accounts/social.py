"""Social / OIDC sign-in (Google, Facebook, Apple, and enterprise IdPs).

Google/Facebook/Apple sign-in and enterprise SSO are all OIDC/OAuth2, so one
pluggable verifier serves them all. A verifier turns a provider token into a
VerifiedIdentity (provider + stable user id + email). We then find-or-create the
account for that identity.

Real providers verify tokens against their JWKS/endpoints and need app client
credentials (registered in each provider's developer console) + a browser
redirect flow -- so those are pluggable and configured at deploy. Tests use
FakeVerifier so nothing external is called.
"""
from __future__ import annotations

from dataclasses import dataclass

from deeparchive.accounts.accounts import AccountService, AccountType, NewAccount


@dataclass(frozen=True)
class VerifiedIdentity:
    """A verified identity returned by a provider after token verification."""

    provider: str          # "google" | "facebook" | "apple" | "<idp>"
    provider_user_id: str  # stable, provider-issued user id (never reused)
    email: str | None = None


class TokenVerifier:
    """Verifies a provider token -> VerifiedIdentity. One impl per provider."""

    def verify(self, token: str) -> VerifiedIdentity:
        raise NotImplementedError


class AuthError(Exception):
    """Raised when a social token is invalid or cannot be verified."""


class FakeVerifier(TokenVerifier):
    """Test/dev verifier: maps preset tokens to identities. No network."""

    def __init__(self, provider: str = "google") -> None:
        self._provider = provider
        self._tokens: dict[str, VerifiedIdentity] = {}

    def register_token(self, token: str, user_id: str, email: str | None = None) -> None:
        self._tokens[token] = VerifiedIdentity(self._provider, user_id, email)

    def verify(self, token: str) -> VerifiedIdentity:
        if token not in self._tokens:
            raise AuthError("invalid social token")
        return self._tokens[token]


class GoogleTokenVerifier(TokenVerifier):
    """Real Google Sign-In verifier.

    Verifies a Google ID token against Google's certs using google-auth. The
    library is imported lazily so it is only required where real Google login is
    deployed (not for tests, which use FakeVerifier). Configure with your
    Google OAuth client_id (from the Google Cloud console).
    """

    def __init__(self, client_id: str):
        self._client_id = client_id

    def verify(self, token: str) -> VerifiedIdentity:
        try:
            import google.auth.transport.requests as g_requests  # type: ignore[import-not-found]  # noqa: E501
            import google.oauth2.id_token as g_id_token  # type: ignore[import-not-found]  # noqa: E501
        except ImportError as exc:  # pragma: no cover - only if dep missing
            raise AuthError("google-auth not installed") from exc
        try:
            claims = g_id_token.verify_oauth2_token(
                token, g_requests.Request(), self._client_id
            )
        except ValueError as exc:
            raise AuthError(f"invalid google token: {exc}") from exc
        return VerifiedIdentity(
            provider="google",
            provider_user_id=str(claims["sub"]),  # stable Google user id
            email=claims.get("email"),
        )


class FacebookTokenVerifier(TokenVerifier):
    """Real Facebook Login verifier.

    Verifies a user access token via Facebook's Graph API and reads the user's
    id + email. Requires a Facebook app (app_id + app_secret) from the Meta
    developer console. `requests` is imported lazily (deploy-time dep).
    """

    def __init__(self, app_id: str, app_secret: str):
        self._app_id = app_id
        self._app_secret = app_secret

    def verify(self, token: str) -> VerifiedIdentity:
        try:
            import requests  # type: ignore[import-untyped]  # noqa: E501
        except ImportError as exc:  # pragma: no cover - only if dep missing
            raise AuthError("requests not installed") from exc
        # 1) Validate the token belongs to our app. 2) Read the profile.
        app_token = f"{self._app_id}|{self._app_secret}"
        debug = requests.get(
            "https://graph.facebook.com/debug_token",
            params={"input_token": token, "access_token": app_token},
            timeout=10,
        ).json()
        data = debug.get("data", {})
        if not data.get("is_valid") or str(data.get("app_id")) != str(self._app_id):
            raise AuthError("invalid facebook token")
        profile = requests.get(
            "https://graph.facebook.com/me",
            params={"fields": "id,email", "access_token": token},
            timeout=10,
        ).json()
        return VerifiedIdentity(
            provider="facebook",
            provider_user_id=str(profile["id"]),
            email=profile.get("email"),
        )


class AppleTokenVerifier(TokenVerifier):
    """Real Sign in with Apple verifier.

    Verifies Apple's identity token (a JWT) against Apple's public keys and
    checks the audience (your Apple client_id / Services ID). Uses PyJWT with
    Apple's JWKS; both imported lazily (deploy-time deps).
    """

    _APPLE_ISSUER = "https://appleid.apple.com"
    _APPLE_JWKS = "https://appleid.apple.com/auth/keys"

    def __init__(self, client_id: str):
        self._client_id = client_id

    def verify(self, token: str) -> VerifiedIdentity:
        try:
            import jwt  # type: ignore[import-not-found]  # noqa: E501
            from jwt import PyJWKClient  # noqa: E501
        except ImportError as exc:  # pragma: no cover - only if dep missing
            raise AuthError("PyJWT not installed") from exc
        try:
            signing_key = PyJWKClient(self._APPLE_JWKS).get_signing_key_from_jwt(token)
            claims = jwt.decode(
                token, signing_key.key, algorithms=["RS256"],
                audience=self._client_id, issuer=self._APPLE_ISSUER,
            )
        except Exception as exc:  # noqa: BLE001 - jwt raises many types
            raise AuthError(f"invalid apple token: {exc}") from exc
        return VerifiedIdentity(
            provider="apple",
            provider_user_id=str(claims["sub"]),
            email=claims.get("email"),
        )


@dataclass
class SocialAuth:
    """Sign in / register via a social provider, backed by AccountService."""

    accounts: AccountService
    verifiers: dict[str, TokenVerifier]

    def sign_in(
        self, provider: str, token: str, country: str
    ) -> tuple[NewAccount | None, str]:
        """Verify a provider token; find existing account or create a new one.

        Returns (new_account_or_None, account_id). new_account is non-None only
        when a NEW account was created (so the caller can surface the one-time
        API key); for returning users it is None.
        """
        verifier = self.verifiers.get(provider)
        if verifier is None:
            raise AuthError(f"unsupported provider {provider!r}")
        identity = verifier.verify(token)

        existing = self.accounts.accounts.find_by_provider(
            identity.provider, identity.provider_user_id
        )
        if existing is not None:
            return None, existing.account_id

        created = self.accounts.create(
            country=country,
            account_type=AccountType.INDIVIDUAL,
            email=identity.email,
            provider=identity.provider,
            provider_user_id=identity.provider_user_id,
        )
        return created, created.account.account_id
