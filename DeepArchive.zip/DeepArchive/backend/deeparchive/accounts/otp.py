"""Mobile OTP sign-in: phone -> SMS code -> verify -> account.

A pluggable CodeSender delivers the code (FakeSender for tests/dev prints/returns
it; an SNS sender for prod). Codes are single-use, expire after a TTL, and are
rate-limited per phone to prevent SMS-bombing (which costs real money).
"""
from __future__ import annotations

import secrets
import time
from dataclasses import dataclass, field

from deeparchive.accounts.accounts import AccountService, AccountType, NewAccount

_CODE_TTL_SECONDS = 600      # 10 minutes
_MIN_RESEND_SECONDS = 30     # rate limit: one code per phone per 30s
_CODE_DIGITS = 6


class OtpError(Exception):
    """Raised on invalid/expired code or rate-limit violation."""


class CodeSender:
    """Delivers an OTP code to a phone. One impl per channel (SNS, etc)."""

    def send(self, phone: str, code: str) -> None:
        raise NotImplementedError


class FakeSender(CodeSender):
    """Test/dev sender: records the last code instead of sending an SMS."""

    def __init__(self) -> None:
        self.sent: dict[str, str] = {}

    def send(self, phone: str, code: str) -> None:
        self.sent[phone] = code


class SnsCodeSender(CodeSender):
    """Real SMS sender via AWS SNS. boto3 imported lazily (only for prod use).

    SNS SMS costs money per message and pricing varies by country -- combined
    with MobileOtp's per-phone rate limit to curb abuse.
    """

    def __init__(self, region: str, sns: object = None):
        if sns is None:
            import boto3

            sns = boto3.client("sns", region_name=region)
        self._sns = sns

    def send(self, phone: str, code: str) -> None:
        self._sns.publish(  # type: ignore[attr-defined]
            PhoneNumber=phone,
            Message=f"Your DeepArchive verification code is {code}",
        )


@dataclass
class _Pending:
    code: str
    expires_at: float
    sent_at: float


@dataclass
class MobileOtp:
    """Request + verify phone OTP, backed by AccountService."""

    accounts: AccountService
    sender: CodeSender
    _pending: dict[str, _Pending] = field(default_factory=dict)

    def request_code(self, phone: str) -> None:
        """Generate + send a code, enforcing a per-phone resend rate limit."""
        now = time.time()
        prev = self._pending.get(phone)
        if prev is not None and (now - prev.sent_at) < _MIN_RESEND_SECONDS:
            raise OtpError("code requested too recently; slow down")
        code = "".join(secrets.choice("0123456789") for _ in range(_CODE_DIGITS))
        self._pending[phone] = _Pending(
            code=code, expires_at=now + _CODE_TTL_SECONDS, sent_at=now
        )
        self.sender.send(phone, code)

    def verify(self, phone: str, code: str, country: str) -> tuple[NewAccount | None, str]:
        """Verify a code; find-or-create the account for this phone.

        Returns (new_account_or_None, account_id) -- new_account non-None only
        when a NEW account was created.
        """
        pending = self._pending.get(phone)
        if pending is None:
            raise OtpError("no code requested for this phone")
        if time.time() > pending.expires_at:
            del self._pending[phone]
            raise OtpError("code expired")
        if not secrets.compare_digest(code, pending.code):
            raise OtpError("incorrect code")

        # Single-use: consume it.
        del self._pending[phone]

        existing = self.accounts.accounts.find_by_phone(phone)
        if existing is not None:
            return None, existing.account_id

        created = self.accounts.create(
            country=country, account_type=AccountType.INDIVIDUAL, phone=phone
        )
        return created, created.account.account_id
