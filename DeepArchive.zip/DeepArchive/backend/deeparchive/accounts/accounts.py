"""Accounts core: the internal account_id spine.

Every registration path (social login, mobile OTP, org creation) ends here:
we mint an opaque internal account_id and wire it to
  - an encryption key (crypto KeyStore)
  - an API key (auth KeyStore; raw key returned ONCE)
  - a region (from country, via strict residency)
  - a storage prefix data/<account_id>/

account_id is the stable spine; email/phone/provider-id can change, it never does.
No PII in the id, so it is safe to use in S3 keys and manifests.
"""
from __future__ import annotations

import secrets
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any

from deeparchive import regions
from deeparchive.crypto import KeyStore as CryptoKeyStore
from deeparchive.services.api.auth import KeyStore as ApiKeyStore


class AccountType(str, Enum):
    INDIVIDUAL = "INDIVIDUAL"
    ENTERPRISE = "ENTERPRISE"


@dataclass
class Account:
    """An internal account. The spine everything else maps to."""

    account_id: str
    account_type: AccountType
    country: str
    region: str
    created_at: float
    email: str | None = None
    phone: str | None = None
    # For social logins: which provider + the provider's stable user id.
    provider: str | None = None
    provider_user_id: str | None = None
    plan: str = "free"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["account_type"] = self.account_type.value
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> Account:
        return Account(
            account_id=str(d["account_id"]),
            account_type=AccountType(d["account_type"]),
            country=str(d["country"]),
            region=str(d["region"]),
            created_at=float(d["created_at"]),
            email=d.get("email"),
            phone=d.get("phone"),
            provider=d.get("provider"),
            provider_user_id=d.get("provider_user_id"),
            plan=str(d.get("plan", "free")),
        )


class AccountStore:
    """Persistence + lookups for accounts. In-memory; DynamoDB-swappable."""

    def __init__(self) -> None:
        self._by_id: dict[str, Account] = {}
        self._by_email: dict[str, str] = {}
        self._by_phone: dict[str, str] = {}
        self._by_provider: dict[tuple[str, str], str] = {}

    def put(self, account: Account) -> None:
        self._by_id[account.account_id] = account
        if account.email:
            self._by_email[account.email.lower()] = account.account_id
        if account.phone:
            self._by_phone[account.phone] = account.account_id
        if account.provider and account.provider_user_id:
            self._by_provider[(account.provider, account.provider_user_id)] = account.account_id

    def get(self, account_id: str) -> Account:
        if account_id not in self._by_id:
            raise KeyError(f"no account {account_id!r}")
        return self._by_id[account_id]

    def find_by_email(self, email: str) -> Account | None:
        aid = self._by_email.get(email.lower())
        return self._by_id[aid] if aid else None

    def find_by_phone(self, phone: str) -> Account | None:
        aid = self._by_phone.get(phone)
        return self._by_id[aid] if aid else None

    def find_by_provider(self, provider: str, provider_user_id: str) -> Account | None:
        aid = self._by_provider.get((provider, provider_user_id))
        return self._by_id[aid] if aid else None


@dataclass
class NewAccount:
    """Result of creating an account. api_key is returned ONCE."""

    account: Account
    api_key: str


@dataclass
class AccountService:
    """Creates accounts and wires them to keys + region. The one place that mints."""

    accounts: AccountStore
    api_keys: ApiKeyStore
    crypto_keys: CryptoKeyStore
    _seq: int = field(default=0, repr=False)

    def _new_account_id(self) -> str:
        return f"acc_{uuid.uuid4().hex[:20]}"

    def create(
        self,
        country: str,
        account_type: AccountType = AccountType.INDIVIDUAL,
        email: str | None = None,
        phone: str | None = None,
        provider: str | None = None,
        provider_user_id: str | None = None,
    ) -> NewAccount:
        # Resolve region up front -> refuses unserved countries (strict residency).
        info = regions.resolve(country)

        account_id = self._new_account_id()
        account = Account(
            account_id=account_id,
            account_type=account_type,
            country=country,
            region=info.region,
            created_at=time.time(),
            email=email,
            phone=phone,
            provider=provider,
            provider_user_id=provider_user_id,
        )
        self.accounts.put(account)

        # Wire the spine: encryption key + api key.
        self.crypto_keys.get_or_create_key(account_id)
        raw_api_key = f"dak_{secrets.token_urlsafe(24)}"
        self.api_keys.add_key(raw_api_key, org_id=account_id)

        return NewAccount(account=account, api_key=raw_api_key)
