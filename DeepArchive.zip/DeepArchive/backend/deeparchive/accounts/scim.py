"""SCIM auto member provisioning.

Enterprises use SCIM (from Okta/Azure AD/etc.) to automatically add and remove
members as employees join/leave. We implement the core SCIM Users operations
mapped onto org members + roles, so deprovisioning (offboarding) is automatic.

This is a minimal SCIM 2.0 Users subset: create, get, list, deactivate/delete.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from deeparchive.accounts.orgs import Organization, Role

_SCIM_USER_SCHEMA = "urn:ietf:params:scim:schemas:core:2.0:User"


@dataclass
class ScimService:
    """SCIM Users provisioning bound to one org. Maps SCIM users -> members."""

    org: Organization
    default_role: Role = Role.MEMBER
    # SCIM id (uuid) <-> user_ref (email/login) mapping.
    _id_to_ref: dict[str, str] = field(default_factory=dict)

    def create_user(self, user_name: str, active: bool = True) -> dict[str, Any]:
        """SCIM POST /Users -> add an org member. Returns a SCIM user resource."""
        scim_id = uuid.uuid4().hex
        self._id_to_ref[scim_id] = user_name
        if active:
            self.org.add_member(user_name, self.default_role)
        return self._resource(scim_id, user_name, active)

    def get_user(self, scim_id: str) -> dict[str, Any]:
        ref = self._id_to_ref.get(scim_id)
        if ref is None:
            raise KeyError(f"no SCIM user {scim_id}")
        return self._resource(scim_id, ref, self.org.role_of(ref) is not None)

    def list_users(self) -> dict[str, Any]:
        resources = [
            self._resource(sid, ref, self.org.role_of(ref) is not None)
            for sid, ref in self._id_to_ref.items()
        ]
        return {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:ListResponse"],
            "totalResults": len(resources),
            "Resources": resources,
        }

    def deprovision(self, scim_id: str) -> None:
        """SCIM DELETE /Users/{id} -> remove the member (offboarding)."""
        ref = self._id_to_ref.get(scim_id)
        if ref is None:
            raise KeyError(f"no SCIM user {scim_id}")
        self.org.members.pop(ref, None)

    def _resource(self, scim_id: str, user_name: str, active: bool) -> dict[str, Any]:
        return {
            "schemas": [_SCIM_USER_SCHEMA],
            "id": scim_id,
            "userName": user_name,
            "active": active,
        }
