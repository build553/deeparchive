"""Audit log: append-only, cost-aware, backed by S3 JSONL.

Cost design (both write AND read matter):
  WRITE: events appended into ONE object per org per day
         audit/<org>/YYYY-MM-DD.jsonl  -> few PUTs, not one-object-per-event.
  READ:  fetch ONLY the date-partitioned files in the requested range
         (no full scan). Storage is tiny (KB/day) -> pennies. Heavy analytics
         can use Athena/S3-Select later (pay-per-query, $0 idle).

Storage class = S3 Standard (warm) so audit is instantly queryable.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

AUDIT_PREFIX = "audit/"


@dataclass(frozen=True)
class AuditEvent:
    """One audit record: who did what, when, from where."""

    org_id: str
    actor: str          # api-key holder / user ref
    action: str         # e.g. "restore.request", "pack.upload", "file.delete"
    target: str         # what was acted on (tarball_key, path, ...)
    at: float           # epoch seconds
    source_ip: str = ""
    detail: dict[str, Any] | None = None

    def to_line(self) -> str:
        return json.dumps({
            "org_id": self.org_id, "actor": self.actor, "action": self.action,
            "target": self.target, "at": self.at, "source_ip": self.source_ip,
            "detail": self.detail or {},
        }, sort_keys=True)


def _day_key(org_id: str, at: float) -> str:
    day = datetime.fromtimestamp(at, tz=timezone.utc).strftime("%Y-%m-%d")
    return f"{AUDIT_PREFIX}{org_id}/{day}.jsonl"


class AuditLog:
    """Appends events to per-org, per-day JSONL objects in S3 (cost-aware).

    Uses read-modify-append (get the day's object, add a line, put back). For
    low event rates this is cheap; a high-volume deployment would batch/buffer
    or use a Firehose->S3 stream. `s3` is injectable for tests.
    """

    def __init__(self, bucket: str, s3: Any):
        self._bucket = bucket
        self._s3 = s3

    def record(self, event: AuditEvent) -> None:
        key = _day_key(event.org_id, event.at)
        existing = self._read_object(key)
        line = event.to_line().encode("utf-8")
        body = (existing + b"\n" + line) if existing else line
        self._s3.put_object(Bucket=self._bucket, Key=key, Body=body)

    def read_range(
        self, org_id: str, from_at: float, to_at: float
    ) -> list[dict[str, Any]]:
        """Read audit events in [from_at, to_at] -- fetches ONLY the day files
        in range (partition pruning), not a full scan."""
        events: list[dict[str, Any]] = []
        for key in self._day_keys_in_range(org_id, from_at, to_at):
            raw = self._read_object(key)
            if not raw:
                continue
            for line in raw.decode("utf-8").splitlines():
                if not line.strip():
                    continue
                rec = json.loads(line)
                if from_at <= rec["at"] <= to_at:
                    events.append(rec)
        events.sort(key=lambda r: r["at"])
        return events

    def _day_keys_in_range(self, org_id: str, from_at: float, to_at: float) -> list[str]:
        keys, day = [], _floor_day(from_at)
        while day <= to_at:
            keys.append(_day_key(org_id, day))
            day += 86400
        return keys

    def _read_object(self, key: str) -> bytes:
        try:
            obj = self._s3.get_object(Bucket=self._bucket, Key=key)
            return bytes(obj["Body"].read())
        except Exception:  # noqa: BLE001 - missing object => no events that day
            return b""


def _floor_day(at: float) -> float:
    d = datetime.fromtimestamp(at, tz=timezone.utc)
    return datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp()


class NullAudit:
    """No-op audit sink: lets services call record() unconditionally even when
    audit isn't configured (e.g. tests, or a deployment that opts out)."""

    def record(self, event: AuditEvent) -> None:
        return None


def emit(
    sink: AuditLog | NullAudit | None,
    org_id: str,
    actor: str,
    action: str,
    target: str,
    source_ip: str = "",
    detail: dict[str, Any] | None = None,
) -> None:
    """Convenience: build an AuditEvent(now) and record it, tolerating a None
    sink. Audit must never break the request path -- failures are swallowed."""
    if sink is None:
        return
    try:
        sink.record(AuditEvent(
            org_id=org_id, actor=actor, action=action, target=target,
            at=now(), source_ip=source_ip, detail=detail,
        ))
    except Exception:  # noqa: BLE001 - audit is best-effort, never fatal
        return


def now() -> float:
    return time.time()
