"""Wiring: assemble the account services using the store factory.

This is where the running service decides persistence: with DEEPARCHIVE_USE_DDB=1
(or a DDB endpoint set) it uses DynamoDB-backed stores; otherwise in-memory.
Providers (social verifiers, SMS sender, key store) default to safe/fake for
local use and are swapped for real ones at deploy via configure().
"""
from __future__ import annotations

import os

from deeparchive.accounts import (
    AccountService,
    FakeSender,
    FakeVerifier,
    MobileOtp,
    OrgService,
    SocialAuth,
)
from deeparchive.accounts.social import TokenVerifier
from deeparchive.crypto import LocalKeyStore
from deeparchive.persistence import factory
from deeparchive.services.api.accounts_api import AccountsDeps
from deeparchive.services.api.auth import KeyStore


def build_accounts_deps(
    api_keys: KeyStore | None = None,
    verifiers: dict[str, TokenVerifier] | None = None,
    sms_sender: object | None = None,
    key_path: str = "/tmp/deeparchive_keys.json",  # noqa: S108
) -> AccountsDeps:
    """Assemble AccountsDeps. Persistence chosen by the store factory."""
    keys = api_keys or factory.key_store()
    account_service = AccountService(
        accounts=factory.account_store(),
        api_keys=keys,
        crypto_keys=LocalKeyStore(key_path),
    )
    used_verifiers = verifiers or {"google": FakeVerifier("google")}
    sender = sms_sender or FakeSender()
    return AccountsDeps(
        account_service=account_service,
        social=SocialAuth(accounts=account_service, verifiers=used_verifiers),
        otp=MobileOtp(accounts=account_service, sender=sender),  # type: ignore[arg-type]
        orgs=OrgService(accounts=account_service, orgs=factory.org_store()),
        api_keys=keys,
    )


def ddb_enabled() -> bool:
    """Whether the running service is configured for durable DynamoDB storage."""
    return os.environ.get("DEEPARCHIVE_USE_DDB") == "1"
