"""HTTP API service (FastAPI): the /v1 surface.

Thin wrapper over the core library. Endpoints delegate to packer/storage/restore.
No archival logic lives here. This is what mobile/desktop/website gateways call.
"""
from deeparchive.services.api.app import create_app

__all__ = ["create_app"]
