"""Account/registration API endpoints (thin wrappers over the accounts services).

Mounted onto the main app. Three front doors + org creation + me:
    POST /v1/accounts/social       social sign-in (Google/FB/Apple token)
    POST /v1/accounts/otp/request  send a mobile OTP
    POST /v1/accounts/otp/verify   verify OTP -> account
    POST /v1/orgs                  provision an enterprise org (admin)
    GET  /v1/accounts/me           the authenticated account's profile
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from deeparchive.accounts import AccountService, MobileOtp, OrgService, SocialAuth
from deeparchive.accounts.otp import OtpError
from deeparchive.accounts.social import AuthError
from deeparchive.services.api.auth import AuthError as ApiAuthError
from deeparchive.services.api.auth import KeyStore, extract_bearer


@dataclass
class AccountsDeps:
    """The services the account endpoints need."""

    account_service: AccountService
    social: SocialAuth
    otp: MobileOtp
    orgs: OrgService
    api_keys: KeyStore


class SocialBody(BaseModel):
    provider: str
    token: str
    country: str


class OtpRequestBody(BaseModel):
    phone: str


class OtpVerifyBody(BaseModel):
    phone: str
    code: str
    country: str


class OrgBody(BaseModel):
    name: str
    country: str
    admin_user_ref: str


class RegisterResponse(BaseModel):
    account_id: str
    api_key: Optional[str] = None  # present only when a NEW account was created
    new_account: bool


def build_accounts_router(deps: AccountsDeps) -> APIRouter:
    router = APIRouter()

    @router.post("/v1/accounts/social", response_model=RegisterResponse)
    def social_sign_in(body: SocialBody) -> RegisterResponse:
        try:
            created, account_id = deps.social.sign_in(body.provider, body.token, body.country)
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        return RegisterResponse(
            account_id=account_id,
            api_key=created.api_key if created else None,
            new_account=created is not None,
        )

    @router.post("/v1/accounts/otp/request")
    def otp_request(body: OtpRequestBody) -> dict[str, str]:
        try:
            deps.otp.request_code(body.phone)
        except OtpError as exc:
            raise HTTPException(status_code=429, detail=str(exc)) from exc
        return {"status": "sent"}

    @router.post("/v1/accounts/otp/verify", response_model=RegisterResponse)
    def otp_verify(body: OtpVerifyBody) -> RegisterResponse:
        try:
            created, account_id = deps.otp.verify(body.phone, body.code, body.country)
        except OtpError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        return RegisterResponse(
            account_id=account_id,
            api_key=created.api_key if created else None,
            new_account=created is not None,
        )

    @router.post("/v1/orgs", response_model=RegisterResponse)
    def create_org(body: OrgBody) -> RegisterResponse:
        from deeparchive.regions import CountryNotServedError
        try:
            org, api_key = deps.orgs.create_org(
                name=body.name, country=body.country, admin_user_ref=body.admin_user_ref
            )
        except CountryNotServedError as exc:
            # Strict residency: we don't serve this country -> 422, not a 500.
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return RegisterResponse(account_id=org.account_id, api_key=api_key, new_account=True)

    @router.get("/v1/accounts/me")
    def me(authorization: Optional[str] = Header(default=None)) -> dict[str, object]:
        try:
            principal = deps.api_keys.authenticate(extract_bearer(authorization))
        except ApiAuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        acc = deps.account_service.accounts.get(principal.org_id)
        return {
            "account_id": acc.account_id,
            "type": acc.account_type.value,
            "region": acc.region,
            "email": acc.email,
            "phone": acc.phone,
            "plan": acc.plan,
        }

    return router
