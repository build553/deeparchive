"""Rate limiting: a token-bucket limiter keyed by client (API key or IP).

Protects the API from abuse and runaway cost (e.g. restore/upload spam). In-
process here (a real multi-instance deployment would back this with Redis/DDB,
same interface). Token bucket: `rate` tokens refill per second up to `capacity`;
each request costs one token.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class _Bucket:
    tokens: float
    last_refill: float


@dataclass
class RateLimiter:
    """Token-bucket limiter. capacity = burst, refill_per_sec = sustained rate."""

    capacity: float = 60.0
    refill_per_sec: float = 1.0
    _buckets: dict[str, _Bucket] = field(default_factory=dict)

    def allow(self, key: str, now: float | None = None) -> bool:
        """Consume one token for `key`. True if allowed, False if rate-limited."""
        now = time.time() if now is None else now
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = _Bucket(tokens=self.capacity, last_refill=now)
            self._buckets[key] = bucket
        # Refill based on elapsed time.
        elapsed = now - bucket.last_refill
        bucket.tokens = min(self.capacity, bucket.tokens + elapsed * self.refill_per_sec)
        bucket.last_refill = now
        if bucket.tokens >= 1.0:
            bucket.tokens -= 1.0
            return True
        return False
