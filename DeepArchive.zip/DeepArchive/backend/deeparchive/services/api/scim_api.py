"""SCIM 2.0 Users HTTP endpoints (subset) for enterprise auto-provisioning.

An IdP (Okta/Azure AD) calls these with a bearer token to add/remove members.
Routes map to a per-org ScimService via a provider. Standard SCIM paths:
    POST   /scim/v2/Users
    GET    /scim/v2/Users
    GET    /scim/v2/Users/{id}
    DELETE /scim/v2/Users/{id}
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any, Optional

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from deeparchive.accounts.scim import ScimService
from deeparchive.services.api.auth import AuthError, KeyStore, extract_bearer

# org_id -> ScimService for that org.
ScimProvider = Callable[[str], ScimService]


class ScimUserBody(BaseModel):
    userName: str  # noqa: N815 - SCIM uses camelCase
    active: bool = True


def build_scim_router(key_store: KeyStore, scim_provider: ScimProvider) -> APIRouter:
    router = APIRouter(prefix="/scim/v2")

    def _svc(authorization: Optional[str]) -> ScimService:
        try:
            principal = key_store.authenticate(extract_bearer(authorization))
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        return scim_provider(principal.org_id)

    @router.post("/Users")
    def create_user(
        body: ScimUserBody, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        return _svc(authorization).create_user(body.userName, active=body.active)

    @router.get("/Users")
    def list_users(authorization: Optional[str] = Header(default=None)) -> dict[str, Any]:
        return _svc(authorization).list_users()

    @router.get("/Users/{scim_id}")
    def get_user(
        scim_id: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        try:
            return _svc(authorization).get_user(scim_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="user not found") from exc

    @router.delete("/Users/{scim_id}")
    def delete_user(
        scim_id: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, str]:
        try:
            _svc(authorization).deprovision(scim_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="user not found") from exc
        return {"status": "deprovisioned"}

    return router
