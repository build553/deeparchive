"""API authentication + org identity.

Simple bearer API-key model: each org has one or more API keys. A request
presents `Authorization: Bearer <key>`; we resolve it to an org_id and scope all
operations to that org. Keys are stored hashed (never in plaintext).

The key store is pluggable (in-memory for tests/dev; a real deployment backs it
with DynamoDB or Secrets Manager).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass


def hash_key(raw_key: str) -> str:
    """Hash an API key for storage/comparison (never store raw keys)."""
    return hashlib.sha256(raw_key.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Principal:
    """The authenticated caller."""

    org_id: str


class AuthError(Exception):
    """Raised when an API key is missing or invalid."""


class KeyStore:
    """Maps hashed API keys -> org_id. In-memory; swap for DynamoDB in prod."""

    def __init__(self) -> None:
        self._by_hash: dict[str, str] = {}

    def add_key(self, raw_key: str, org_id: str) -> None:
        self._by_hash[hash_key(raw_key)] = org_id

    def authenticate(self, raw_key: str | None) -> Principal:
        """Resolve a raw API key to a Principal, or raise AuthError."""
        if not raw_key:
            raise AuthError("missing API key")
        org_id = self._by_hash.get(hash_key(raw_key))
        if org_id is None:
            raise AuthError("invalid API key")
        return Principal(org_id=org_id)


def extract_bearer(authorization: str | None) -> str | None:
    """Pull the token out of an 'Authorization: Bearer <token>' header."""
    if not authorization:
        return None
    parts = authorization.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1].strip()
