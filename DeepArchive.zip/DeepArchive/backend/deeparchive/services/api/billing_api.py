"""Billing HTTP endpoints.

    POST /v1/billing/purchase   buy a plan (prepaid) -> entitlement
    GET  /v1/billing/account    quota, used, remaining, egress, expiry
"""
from __future__ import annotations

import contextlib
from typing import Any, Callable, Optional

from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel

from deeparchive.billing import (
    CATALOG,
    BillingService,
    NoEntitlementError,
    PaymentError,
    PlanId,
    UsageMeter,
    WebhookVerificationError,
    make_entitlement,
    verify_webhook,
)
from deeparchive.billing.subscription import SubscriptionService
from deeparchive.notify import Notifier, payment_failed
from deeparchive.services.api.auth import AuthError, KeyStore, extract_bearer


class PurchaseBody(BaseModel):
    plan_id: str
    payment_token: str
    units: int = 1


class WebhookBody(BaseModel):
    event_type: str
    account_id: str
    plan_id: str
    units: int = 1


def build_billing_router(
    key_store: KeyStore,
    billing: BillingService,
    meter: UsageMeter,
    webhook_secret: str = "",
    subscriptions: SubscriptionService | None = None,
    notifier: Notifier | None = None,
    notify_email_for: Callable[[str], str] | None = None,
    identity_validate: Callable[[str], str] | None = None,
) -> APIRouter:
    router = APIRouter(prefix="/v1/billing")
    subs = subscriptions if subscriptions is not None else SubscriptionService(meter=meter)

    def _account(authorization: Optional[str]) -> str:
        token = extract_bearer(authorization)
        if not token:
            raise HTTPException(status_code=401, detail="missing API key")
        # In the split deployment, keys are issued by the IDENTITY service, so
        # validate there (billing has no local key store of issued keys). Falls
        # back to the local KeyStore when no identity validator is wired (tests).
        if identity_validate is not None:
            try:
                return identity_validate(token)
            except PermissionError as exc:
                raise HTTPException(status_code=401, detail="invalid API key") from exc
        try:
            return key_store.authenticate(token).org_id
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc

    @router.post("/purchase")
    def purchase(
        body: PurchaseBody, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        account_id = _account(authorization)
        try:
            plan_id = PlanId(body.plan_id)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="unknown plan") from exc
        try:
            ent = billing.purchase(account_id, plan_id, body.payment_token, body.units)
        except PaymentError as exc:
            raise HTTPException(status_code=402, detail=str(exc)) from exc
        return {"status": "purchased", "quota_bytes": ent.quota_bytes,
                "expires_at": ent.expires_at}

    @router.post("/subscribe")
    def subscribe(
        body: PurchaseBody, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        """Start a recurring (monthly) subscription; charges + grants first period."""
        account_id = _account(authorization)
        try:
            plan_id = PlanId(body.plan_id)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="unknown plan") from exc
        try:
            billing.processor.charge(
                account_id, CATALOG[plan_id].price_usd_cents, body.payment_token
            )
        except PaymentError as exc:
            raise HTTPException(status_code=402, detail=str(exc)) from exc
        sub = subs.start(account_id, plan_id, units=body.units)
        return {"status": "subscribed", "plan_id": plan_id.value,
                "current_period_end": sub.current_period_end}

    @router.post("/cancel")
    def cancel(authorization: Optional[str] = Header(default=None)) -> dict[str, str]:
        account_id = _account(authorization)
        try:
            sub = subs.cancel(account_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no subscription") from exc
        return {"status": sub.status.value}

    @router.get("/pricing")
    def pricing(country: str) -> dict[str, Any]:
        from deeparchive.billing import CATALOG, CountryNotPricedError, localized_price

        try:
            items = []
            for plan in CATALOG.values():
                lp = localized_price(plan, country)
                items.append({
                    "plan_id": plan.plan_id.value,
                    "billing_period": plan.billing_period,
                    "currency": lp.currency,
                    "amount_minor": lp.amount_minor,
                })
        except CountryNotPricedError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return {"country": country.upper(), "plans": items}

    @router.post("/webhook")
    async def webhook(
        request: Request, stripe_signature: Optional[str] = Header(default=None)
    ) -> dict[str, str]:
        """Processor calls this when a charge settles (UPI/Pix confirm async).

        When a webhook secret is configured, the Stripe-Signature header is
        verified (rejects forged webhooks). On payment.succeeded we grant the
        entitlement. In dev (no secret) the JSON body is trusted directly.
        """
        raw = await request.body()
        if webhook_secret:
            try:
                event = verify_webhook(raw, stripe_signature or "", webhook_secret)
            except WebhookVerificationError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            ev: Any = event
            data = ev.get("data", {}).get("object", {})
            meta = data.get("metadata", {})
            event_type = str(ev.get("type", ""))
            account_id = str(meta.get("account_id", ""))
            plan_raw = str(meta.get("plan_id", ""))
            units = int(meta.get("units", 1))
        else:
            body = WebhookBody.model_validate_json(raw)
            event_type = body.event_type
            account_id = body.account_id
            plan_raw = body.plan_id
            units = body.units

        if event_type == "invoice.payment_succeeded":
            # Recurring charge cleared -> extend the subscription/entitlement.
            try:
                subs.renew(account_id)
            except KeyError:
                return {"status": "no_subscription"}
            return {"status": "renewed", "account_id": account_id}
        if event_type == "invoice.payment_failed":
            try:
                subs.mark_past_due(account_id)
            except KeyError:
                return {"status": "no_subscription"}
            # Best-effort: tell the customer their payment failed (data retained).
            if notifier is not None and notify_email_for is not None:
                with contextlib.suppress(Exception):
                    notifier.send(payment_failed(
                        notify_email_for(account_id),
                        plan=plan_raw or "your plan", amount="your last charge",
                    ))
            return {"status": "past_due", "account_id": account_id}
        if event_type != "payment.succeeded":
            return {"status": "ignored"}
        try:
            plan_id = PlanId(plan_raw)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="unknown plan") from exc
        ent = make_entitlement(account_id, CATALOG[plan_id], units=units)
        meter.set_entitlement(ent)
        return {"status": "granted", "account_id": account_id}

    @router.get("/account")
    def account(authorization: Optional[str] = Header(default=None)) -> dict[str, Any]:
        account_id = _account(authorization)
        usage = meter.usage(account_id)
        try:
            remaining = meter.remaining_quota(account_id)
            active = True
        except NoEntitlementError:
            remaining = 0
            active = False
        return {
            "account_id": account_id,
            "active": active,
            "stored_bytes": usage.stored_bytes,
            "egress_bytes": usage.egress_bytes,
            "remaining_bytes": remaining,
        }

    return router
