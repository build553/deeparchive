"""FastAPI app exposing the /v1 surface.

Endpoints (thin wrappers over the core library):
    GET  /v1/health                     liveness
    GET  /v1/regions                    which countries we serve
    POST /v1/restore                    start a 48h restore for a tarball
    GET  /v1/restore/{key:path}         poll restore status

Storage is obtained per-request via a dependency so tests can inject a fake and
real deployments resolve the caller's region. No archival logic here.
"""
from __future__ import annotations

import base64
from collections.abc import Callable
from typing import Optional

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from deeparchive import config, regions
from deeparchive.billing import NoEntitlementError, QuotaExceededError
from deeparchive.manifest import Manifest
from deeparchive.restore import (
    RestoreJob,
    RestoreState,
    check_restore,
    request_restore,
)
from deeparchive.services.api.auth import (
    AuthError,
    KeyStore,
    Principal,
    extract_bearer,
)
from deeparchive.services.api.ratelimit import RateLimiter
from deeparchive.storage import Storage
from deeparchive.storage.errors import PermanentStorageError, StorageError

# A factory: given a country, return a Storage. Overridable in tests.
StorageProvider = Callable[[str], Storage]


def _default_storage_provider(country: str) -> Storage:
    return Storage.for_country(country)


def _owns(principal: Principal, tarball_key: str) -> bool:
    """Tarball keys are data/<org>/... -- a caller may only touch its own org."""
    prefix = f"{config.DATA_PREFIX}{principal.org_id}/"
    return tarball_key.startswith(prefix)


def _manifest_for_tarball(storage: Storage, org_id: str, tarball_key: str) -> Manifest | None:
    """Find the manifest whose tarball matches (for the restore size check)."""
    for m in storage.list_manifests(org_id):
        if m.tarball_key == tarball_key:
            return m
    return None


class RestoreRequestBody(BaseModel):
    country: str
    tarball_key: str


class RestoreResponse(BaseModel):
    tarball_key: str
    state: str
    sla_hours: int = 48


class UploadUrlBody(BaseModel):
    country: str
    tarball_key: str


class UploadUrlResponse(BaseModel):
    url: str
    tarball_key: str


class PackCompleteBody(BaseModel):
    country: str
    manifest_json: str


class ThumbnailBody(BaseModel):
    image_base64: str


def create_app(
    storage_provider: StorageProvider = _default_storage_provider,
    key_store: KeyStore | None = None,
    rate_limiter: RateLimiter | None = None,
    approval_provider: Optional[Callable[[str], object]] = None,
    usage_meter: object | None = None,
) -> FastAPI:
    app = FastAPI(title="DeepArchive API", version="0.1.0")
    keys = key_store if key_store is not None else KeyStore()
    limiter = rate_limiter
    approvals = approval_provider
    meter = usage_meter

    def get_storage(country: str) -> Storage:
        try:
            return storage_provider(country)
        except regions.CountryNotServedError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    def authenticate(authorization: str | None) -> Principal:
        try:
            principal = keys.authenticate(extract_bearer(authorization))
        except AuthError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        if limiter is not None and not limiter.allow(principal.org_id):
            raise HTTPException(status_code=429, detail="rate limit exceeded")
        return principal

    def require_ownership(principal: Principal, tarball_key: str) -> None:
        if not _owns(principal, tarball_key):
            raise HTTPException(status_code=403, detail="not your org's data")

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/v1/regions")
    def list_regions() -> dict[str, list[str]]:
        return {"active_countries": regions.active_countries()}

    @app.post("/v1/restore", response_model=RestoreResponse)
    def start_restore(
        body: RestoreRequestBody, authorization: Optional[str] = Header(default=None)
    ) -> RestoreResponse:
        principal = authenticate(authorization)
        require_ownership(principal, body.tarball_key)
        storage = get_storage(body.country)

        # Org egress governance: if an approval service exists for this org, a
        # restore over threshold must be admin-approved before it runs.
        if approvals is not None:
            svc = approvals(principal.org_id)
            if svc is not None:
                manifest = _manifest_for_tarball(storage, principal.org_id, body.tarball_key)
                size = manifest.tarball_bytes if manifest else 0
                req = svc.request(principal.org_id, body.tarball_key, size)  # type: ignore[attr-defined]
                if not svc.is_cleared(req.request_id):  # type: ignore[attr-defined]
                    return RestoreResponse(
                        tarball_key=body.tarball_key, state="PENDING_APPROVAL"
                    )

        try:
            job = request_restore(storage, body.tarball_key)
        except StorageError as exc:
            # e.g. object not yet in Deep Archive (InvalidObjectState), missing, etc.
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return RestoreResponse(tarball_key=job.tarball_key, state=job.state.value)

    @app.post("/v1/packs/upload-url", response_model=UploadUrlResponse)
    def pack_upload_url(
        body: UploadUrlBody, authorization: Optional[str] = Header(default=None)
    ) -> UploadUrlResponse:
        principal = authenticate(authorization)
        require_ownership(principal, body.tarball_key)
        storage = get_storage(body.country)
        url = storage.presigned_put_url(body.tarball_key)
        return UploadUrlResponse(url=url, tarball_key=body.tarball_key)

    @app.post("/v1/packs/complete")
    def pack_complete(
        body: PackCompleteBody, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, str]:
        principal = authenticate(authorization)
        manifest = Manifest.from_json(body.manifest_json)
        # The manifest's tarball must belong to the caller's org.
        require_ownership(principal, manifest.tarball_key)
        if manifest.org_id != principal.org_id:
            raise HTTPException(status_code=403, detail="manifest org mismatch")
        # Enforce prepaid quota (if a meter is configured).
        if meter is not None:
            try:
                meter.check_and_record_upload(principal.org_id, manifest.tarball_bytes)  # type: ignore[attr-defined]
            except NoEntitlementError as exc:
                raise HTTPException(status_code=402, detail="no active plan") from exc
            except QuotaExceededError as exc:
                raise HTTPException(status_code=402, detail=str(exc)) from exc
        storage = get_storage(body.country)
        storage.register_manifest(manifest)
        return {"status": "registered", "pack_id": manifest.pack_id}

    @app.get("/v1/restore/{tarball_key:path}/download")
    def restore_download(
        tarball_key: str,
        country: str,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, object]:
        principal = authenticate(authorization)
        require_ownership(principal, tarball_key)
        storage = get_storage(country)
        if not storage.restore_ready(tarball_key):
            raise HTTPException(status_code=409, detail="restore not ready")
        url = storage.presigned_get_url(tarball_key)
        return {"tarball_key": tarball_key, "download_url": url}

    @app.get("/v1/restore/{tarball_key:path}", response_model=RestoreResponse)
    def restore_status(
        tarball_key: str,
        country: str,
        authorization: Optional[str] = Header(default=None),
    ) -> RestoreResponse:
        principal = authenticate(authorization)
        require_ownership(principal, tarball_key)
        storage = get_storage(country)
        job = RestoreJob(tarball_key=tarball_key, state=RestoreState.RESTORING)
        job = check_restore(storage, job)
        return RestoreResponse(tarball_key=job.tarball_key, state=job.state.value)

    @app.post("/v1/restore/{request_id}/approve")
    def approve_restore(
        request_id: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, str]:
        from deeparchive.accounts.approval import NotAuthorizedError
        principal = authenticate(authorization)
        if approvals is None:
            raise HTTPException(status_code=404, detail="approvals not enabled")
        svc = approvals(principal.org_id)
        if svc is None:
            raise HTTPException(status_code=404, detail="no approvals for org")
        try:
            req = svc.approve(request_id, principal.org_id)  # type: ignore[attr-defined]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no such request") from exc
        except NotAuthorizedError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        return {"request_id": request_id, "state": req.state.value}

    @app.post("/v1/restore/{request_id}/reject")
    def reject_restore(
        request_id: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, str]:
        from deeparchive.accounts.approval import NotAuthorizedError
        principal = authenticate(authorization)
        if approvals is None:
            raise HTTPException(status_code=404, detail="approvals not enabled")
        svc = approvals(principal.org_id)
        if svc is None:
            raise HTTPException(status_code=404, detail="no approvals for org")
        try:
            req = svc.reject(request_id, principal.org_id)  # type: ignore[attr-defined]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no such request") from exc
        except NotAuthorizedError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        return {"request_id": request_id, "state": req.state.value}

    @app.get("/v1/files")
    def find_file(
        path: str, country: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, object]:
        principal = authenticate(authorization)
        storage = get_storage(country)
        found = storage.find_file(principal.org_id, path)
        if found is None:
            raise HTTPException(status_code=404, detail="file not found in archive")
        manifest, entry = found
        return {
            "path": entry.path,
            "pack_id": manifest.pack_id,
            "tarball_key": manifest.tarball_key,
            "offset": entry.offset,
            "length": entry.length,
            "sha256": entry.sha256,
            "retention": manifest.retention_class.value,
            "legal_hold": manifest.legal_hold,
            "encrypted": bool(manifest.encryption_nonce),
        }

    @app.put("/v1/thumbnails/{archive_path:path}")
    def put_thumbnail(
        archive_path: str,
        country: str,
        body: ThumbnailBody,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        principal = authenticate(authorization)
        storage = get_storage(country)
        raw = base64.b64decode(body.image_base64)
        key = storage.put_thumbnail(principal.org_id, archive_path, raw)
        return {"status": "stored", "key": key}

    @app.get("/v1/thumbnails/{archive_path:path}")
    def get_thumbnail(
        archive_path: str,
        country: str,
        authorization: Optional[str] = Header(default=None),
    ) -> Response:
        principal = authenticate(authorization)
        storage = get_storage(country)
        try:
            data = storage.get_thumbnail(principal.org_id, archive_path)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=404, detail="no thumbnail") from exc
        return Response(content=data, media_type="image/jpeg")

    @app.delete("/v1/packs/{pack_id}")
    def delete_pack(
        pack_id: str,
        country: str,
        hard: bool = False,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        principal = authenticate(authorization)
        storage = get_storage(country)
        try:
            if hard:
                storage.hard_delete(principal.org_id, pack_id)
                return {"status": "hard_deleted", "pack_id": pack_id}
            storage.soft_delete(principal.org_id, pack_id)
            return {"status": "soft_deleted", "pack_id": pack_id}
        except PermanentStorageError as exc:
            # e.g. legal hold blocks hard delete.
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    return app
