"""Main app assembly: the entrypoint that wires everything together.

Builds one FastAPI app with the core endpoints + account/registration routes,
using the store factory so persistence is DynamoDB when configured
(DEEPARCHIVE_USE_DDB=1) or in-memory otherwise. This is what a deployment runs
(e.g. `uvicorn deeparchive.services.api.main:app`).
"""
from __future__ import annotations

from fastapi import FastAPI

from deeparchive import config
from deeparchive.billing import (
    BillingService,
    FakeProcessor,
    PaymentProcessor,
    RoutingProcessor,
    UsageMeter,
)
from deeparchive.services.api.accounts_api import build_accounts_router
from deeparchive.services.api.app import create_app
from deeparchive.services.api.billing_api import build_billing_router
from deeparchive.services.api.ratelimit import RateLimiter
from deeparchive.services.api.wiring import build_accounts_deps, ddb_enabled


def _payment_processor() -> PaymentProcessor:
    """Real Stripe routing when a key is configured; fake otherwise (dev/tests)."""
    if config.STRIPE_API_KEY:
        return RoutingProcessor(api_key=config.STRIPE_API_KEY)
    return FakeProcessor()


def build_app() -> FastAPI:
    """Assemble the full service. Persistence chosen by the store factory."""
    deps = build_accounts_deps()
    meter = UsageMeter()
    billing = BillingService(processor=_payment_processor(), meter=meter)
    # Core endpoints, with quota enforcement via the usage meter.
    app = create_app(
        key_store=deps.api_keys, rate_limiter=RateLimiter(), usage_meter=meter
    )
    app.include_router(build_accounts_router(deps))
    app.include_router(
        build_billing_router(
            deps.api_keys, billing, meter, webhook_secret=config.STRIPE_WEBHOOK_SECRET
        )
    )
    return app


def payment_mode() -> str:
    return "stripe" if config.STRIPE_API_KEY else "fake"


def storage_mode() -> str:
    return "dynamodb" if ddb_enabled() else "in-memory"


# Module-level app for `uvicorn deeparchive.services.api.main:app`.
app = build_app()
