"""CLI: the first usable gateway. Thin wrapper over the core library.

Commands:
    pack     <src_dir> <out_dir> --org O --retention 7y   -> write tarballs+manifests
    upload   <out_dir> --country US --org O                -> push packs to that region
    restore  <tarball_key> --country US                    -> start a 48h restore
    status   <tarball_key> --country US                    -> check restore state

No archival logic here -- everything delegates to packer/storage/restore.
"""
from __future__ import annotations

import argparse
import os
import sys

from deeparchive.manifest import Manifest, RetentionClass
from deeparchive.packer import Pack, SourceFile, pack
from deeparchive.restore import check_restore, request_restore
from deeparchive.storage import Storage


def _iter_source_files(src_dir: str, retention: RetentionClass) -> list[SourceFile]:
    sources: list[SourceFile] = []
    for root, _dirs, names in os.walk(src_dir):
        for name in names:
            local = os.path.join(root, name)
            archive = os.path.relpath(local, src_dir)
            sources.append(SourceFile(local, archive, retention))
    return sources


def _cmd_pack(args: argparse.Namespace) -> int:
    retention = RetentionClass(args.retention)
    sources = _iter_source_files(args.src_dir, retention)
    if not sources:
        print(f"No files found under {args.src_dir}", file=sys.stderr)
        return 1
    packs = pack(sources, out_dir=args.out_dir, org_id=args.org)
    for p in packs:
        _write_manifest_beside(p)
        print(f"{p.tarball_path}  ({len(p.manifest.files)} files, "
              f"{p.manifest.tarball_bytes} bytes)")
    print(f"Packed {len(packs)} tarball(s) into {args.out_dir}")
    return 0


def _write_manifest_beside(p: Pack) -> None:
    """Persist the manifest next to its tarball so upload/restore can find it."""
    with open(p.tarball_path + ".manifest.json", "w") as f:
        f.write(p.manifest.to_json())


def _cmd_upload(args: argparse.Namespace) -> int:
    storage = Storage.for_country(args.country)
    count = 0
    for name in os.listdir(args.out_dir):
        if not name.endswith(".tar"):
            continue
        tarball_path = os.path.join(args.out_dir, name)
        manifest = Manifest.from_json(_read(tarball_path + ".manifest.json"))
        storage.upload_pack(Pack(tarball_path=tarball_path, manifest=manifest))
        print(f"Uploaded {manifest.tarball_key}")
        count += 1
    print(f"Uploaded {count} pack(s) to region {storage.region}")
    return 0


def _cmd_restore(args: argparse.Namespace) -> int:
    storage = Storage.for_country(args.country)
    job = request_restore(storage, args.tarball_key)
    print(f"Restore started: {job.tarball_key} [{job.state.value}] (SLA within 48h)")
    return 0


def _cmd_status(args: argparse.Namespace) -> int:
    storage = Storage.for_country(args.country)
    from deeparchive.restore import RestoreJob, RestoreState

    job = RestoreJob(tarball_key=args.tarball_key, state=RestoreState.RESTORING)
    job = check_restore(storage, job)
    print(f"{job.tarball_key} [{job.state.value}]")
    return 0


def _read(path: str) -> str:
    with open(path) as f:
        return f.read()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="deeparchive")
    sub = parser.add_subparsers(dest="command", required=True)

    p_pack = sub.add_parser("pack", help="pack a directory into tarballs")
    p_pack.add_argument("src_dir")
    p_pack.add_argument("out_dir")
    p_pack.add_argument("--org", required=True)
    p_pack.add_argument("--retention", default="7y",
                        choices=[r.value for r in RetentionClass])
    p_pack.set_defaults(func=_cmd_pack)

    p_up = sub.add_parser("upload", help="upload packed tarballs to a region")
    p_up.add_argument("out_dir")
    p_up.add_argument("--country", required=True)
    p_up.add_argument("--org", required=True)
    p_up.set_defaults(func=_cmd_upload)

    p_re = sub.add_parser("restore", help="start a 48h restore of a tarball")
    p_re.add_argument("tarball_key")
    p_re.add_argument("--country", required=True)
    p_re.set_defaults(func=_cmd_restore)

    p_st = sub.add_parser("status", help="check restore status of a tarball")
    p_st.add_argument("tarball_key")
    p_st.add_argument("--country", required=True)
    p_st.set_defaults(func=_cmd_status)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    result: int = args.func(args)
    return result


if __name__ == "__main__":
    sys.exit(main())
