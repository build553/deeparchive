"""CLI: command-line surface. Thin wrapper over the core modules.

First gateway. Exposes: pack, upload, restore, status. No archival logic here.
"""
from deeparchive.services.cli.cli import build_parser, main

__all__ = ["build_parser", "main"]
