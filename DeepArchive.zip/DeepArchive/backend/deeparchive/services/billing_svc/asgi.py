"""ASGI entrypoint for billing: identity-backed auth + notifier + email resolver.

uvicorn deeparchive.services.billing_svc.asgi:app
"""
from deeparchive.services.billing_svc import build_billing_app
from deeparchive.services.internal_client import IdentityClient
from deeparchive.services.prod_wiring import (
    Httpx,
    build_email_resolver,
    build_notifier,
)

_http = Httpx()
_identity = IdentityClient(_http)


def _validate(api_key: str) -> str:
    """Validate a key via the identity service and return the account id.

    Raises PermissionError on an invalid key (handled by the billing router).
    """
    return str(_identity.validate(api_key)["account_id"])


app = build_billing_app(
    notifier=build_notifier(),
    notify_email_for=build_email_resolver(_http),
    identity_validate=_validate,
)
