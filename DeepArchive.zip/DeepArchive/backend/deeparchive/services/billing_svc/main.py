"""Billing service: money + quota, isolated from data operations.

Owns plans, pricing, purchase, subscriptions, Stripe webhooks, and usage/quota.
Ingest calls its /internal/quota before accepting an upload.

Public:   /v1/billing/*
Internal: POST /internal/quota {account_id, size_bytes} -> {allowed}
"""
from __future__ import annotations

from typing import Any, Callable

from fastapi import FastAPI
from pydantic import BaseModel

from deeparchive import config
from deeparchive.billing import (
    BillingService,
    FakeProcessor,
    NoEntitlementError,
    QuotaExceededError,
    RoutingProcessor,
    UsageMeter,
)
from deeparchive.notify import Notifier, quota_low
from deeparchive.services.api.auth import KeyStore
from deeparchive.services.api.billing_api import build_billing_router

# Notify when stored usage crosses this fraction of quota.
_QUOTA_LOW_THRESHOLD = 0.9


class QuotaBody(BaseModel):
    account_id: str
    size_bytes: int


def _processor() -> Any:
    if config.STRIPE_API_KEY:
        return RoutingProcessor(api_key=config.STRIPE_API_KEY)
    return FakeProcessor()


def _ddb_enabled() -> bool:
    from deeparchive.services.api.wiring import ddb_enabled
    return ddb_enabled()


def build_billing_app(
    key_store: KeyStore | None = None,
    meter: UsageMeter | None = None,
    notifier: Notifier | None = None,
    notify_email_for: Callable[[str], str] | None = None,
    identity_validate: Callable[[str], str] | None = None,
) -> FastAPI:
    keys = key_store or KeyStore()
    # Shared, durable usage/entitlements across hosts when DDB is enabled;
    # otherwise in-memory (tests / single-process). This fixes purchases not
    # sticking across the multi-host fleet.
    if meter is not None:
        usage: Any = meter
    elif _ddb_enabled():
        from deeparchive.persistence import DdbUsageMeter, create_tables, resource
        create_tables(resource())  # idempotent; ensures the billing table exists
        usage = DdbUsageMeter()
    else:
        usage = UsageMeter()
    billing = BillingService(processor=_processor(), meter=usage)
    app = FastAPI(title="DeepArchive Billing", version="0.1.0")
    app.include_router(build_billing_router(
        keys, billing, usage, webhook_secret=config.STRIPE_WEBHOOK_SECRET,
        notifier=notifier, notify_email_for=notify_email_for,
        identity_validate=identity_validate))

    def _maybe_notify_quota_low(account_id: str) -> None:
        """After a successful upload, warn if usage crossed the threshold."""
        if notifier is None or notify_email_for is None:
            return
        try:
            frac = usage.quota_fraction_used(account_id)
            if frac >= _QUOTA_LOW_THRESHOLD:
                u = usage.usage(account_id)
                ent = usage._active_entitlement(account_id)  # noqa: SLF001
                gb = 1024 ** 3
                notifier.send(quota_low(
                    notify_email_for(account_id),
                    used_gb=u.stored_bytes / gb, quota_gb=ent.quota_bytes / gb,
                ))
        except Exception:  # noqa: BLE001 - notification is best-effort
            return

    @app.post("/internal/quota")
    def quota(body: QuotaBody) -> dict[str, bool]:
        """Reserve quota for an upload. Called by ingest before accepting bytes."""
        try:
            usage.check_and_record_upload(body.account_id, body.size_bytes)
        except (NoEntitlementError, QuotaExceededError):
            return {"allowed": False}
        _maybe_notify_quota_low(body.account_id)
        return {"allowed": True}

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "billing"}

    return app


app = build_billing_app()
