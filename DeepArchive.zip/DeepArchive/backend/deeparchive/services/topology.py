"""Service topology: where each microservice lives.

Local default = separate processes on localhost, one port each. In production
these become service DNS names. Overridable via env (DEEPARCHIVE_<SVC>_URL).
"""
from __future__ import annotations

import os

# Default local ports (each service is its own uvicorn process on this host).
PORTS = {
    "identity": 8001,
    "billing": 8002,
    "ingest": 8003,
    "restore": 8004,
    "metadata": 8005,
    "gateway": 8000,
}


def service_url(name: str) -> str:
    env = os.environ.get(f"DEEPARCHIVE_{name.upper()}_URL")
    if env:
        return env.rstrip("/")
    return f"http://127.0.0.1:{PORTS[name]}"
