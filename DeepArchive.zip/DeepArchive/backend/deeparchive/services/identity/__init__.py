"""Identity microservice: accounts, orgs, SCIM, keys, region authority."""
from deeparchive.services.identity.main import build_identity_app

__all__ = ["build_identity_app"]
