"""Identity service: the security boundary.

Owns accounts, orgs, SCIM, API keys, encryption keys, and each account's home
region. Other services call its /internal/* endpoints to validate keys and
resolve the account's authoritative region (residency enforced HERE, not from
request bodies).

Public:   /v1/accounts/*, /v1/orgs, /scim/v2/*
Internal: POST /internal/validate {api_key} -> {account_id, region}
          GET  /internal/region/{account_id} -> {region}
"""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from deeparchive.accounts.scim import ScimService
from deeparchive.audit import AuditLog, NullAudit, emit
from deeparchive.services.api.accounts_api import build_accounts_router
from deeparchive.services.api.auth import AuthError, extract_bearer
from deeparchive.services.api.scim_api import build_scim_router
from deeparchive.services.api.wiring import build_accounts_deps


class ValidateBody(BaseModel):
    api_key: str


def build_identity_app(deps: Any = None, audit: AuditLog | NullAudit | None = None) -> FastAPI:
    # In a DDB deployment, ensure the tables exist before serving (idempotent).
    # Identity owns account/key/org tables, so it creates them on startup.
    from deeparchive.services.api.wiring import ddb_enabled
    if ddb_enabled():
        from deeparchive.persistence import create_tables, resource
        create_tables(resource())

    deps = deps or build_accounts_deps()
    app = FastAPI(title="DeepArchive Identity", version="0.1.0")
    app.include_router(build_accounts_router(deps))
    # One SCIM service per org, resolved lazily from the org store.
    scim_orgs: dict[str, ScimService] = {}

    def scim_provider(org_id: str) -> ScimService:
        if org_id not in scim_orgs:
            org = deps.orgs.orgs.get(org_id)
            scim_orgs[org_id] = ScimService(org=org)
        return scim_orgs[org_id]

    app.include_router(build_scim_router(deps.api_keys, scim_provider))

    @app.post("/internal/validate")
    def validate(body: ValidateBody) -> dict[str, Any]:
        """Validate an API key -> account_id + home region. Called by other services.

        Note: successful validates are high-volume (every authenticated request),
        so we audit only FAILED attempts here -- the security-relevant signal.
        """
        try:
            principal = deps.api_keys.authenticate(extract_bearer(f"Bearer {body.api_key}"))
        except AuthError as exc:
            emit(audit, "unknown", "unknown", "auth.failed", "internal/validate",
                 detail={"reason": str(exc)})
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        account_id = principal.org_id
        try:
            acc = deps.account_service.accounts.get(account_id)
            region_country = acc.country
        except KeyError:
            region_country = "US"
        return {"account_id": account_id, "country": region_country}

    @app.get("/internal/region/{account_id}")
    def region(account_id: str) -> dict[str, str]:
        """Resolve an account's authoritative home country (residency)."""
        try:
            acc = deps.account_service.accounts.get(account_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no account") from exc
        return {"account_id": account_id, "country": acc.country}

    @app.get("/internal/contact/{account_id}")
    def contact(account_id: str) -> dict[str, str]:
        """Resolve an account's notification email (for restore-ready etc.)."""
        try:
            acc = deps.account_service.accounts.get(account_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no account") from exc
        return {"account_id": account_id, "email": acc.email or ""}

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "identity"}

    return app


app = build_identity_app()
