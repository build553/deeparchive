"""Ingest flow: stage files, then pack + upload only when qualified.

Ties the StagingBuffer (threshold logic) to the packer + storage pipeline.
Files are added to a per-org buffer; when it qualifies (>= size threshold or
aged), we pack the staged files into tarballs and upload them. This realizes
the "archive when they hit the range" behavior end to end.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from deeparchive.manifest import RetentionClass
from deeparchive.packer import SourceFile, pack
from deeparchive.staging import StagedFile, StagingBuffer
from deeparchive.storage import Storage


@dataclass
class IngestService:
    """Per-org staging + flush-to-archive when qualified."""

    storage: Storage
    out_dir: str
    _buffers: dict[str, StagingBuffer] = field(default_factory=dict)

    def _buffer(self, org_id: str) -> StagingBuffer:
        if org_id not in self._buffers:
            self._buffers[org_id] = StagingBuffer(org_id=org_id)
        return self._buffers[org_id]

    def stage(
        self,
        org_id: str,
        local_path: str,
        archive_path: str,
        size: int,
        retention: RetentionClass = RetentionClass.SEVEN_YEAR,
        legal_hold: bool = False,
    ) -> None:
        """Add a file to the org's staging buffer (not yet archived)."""
        self._buffer(org_id).add(
            StagedFile(
                local_path=local_path, archive_path=archive_path, size=size,
                retention=retention, staged_at=time.time(), legal_hold=legal_hold,
            )
        )

    def qualifies(self, org_id: str) -> bool:
        return self._buffer(org_id).qualifies()

    def flush(self, org_id: str) -> int:
        """If the org's buffer qualifies, pack + upload it. Returns packs uploaded."""
        buffer = self._buffer(org_id)
        if not buffer.qualifies():
            return 0
        staged = buffer.drain()
        sources = [
            SourceFile(
                local_path=s.local_path, archive_path=s.archive_path,
                retention=s.retention, legal_hold=s.legal_hold,
            )
            for s in staged
        ]
        packs = pack(sources, out_dir=self.out_dir, org_id=org_id)
        for p in packs:
            self.storage.upload_pack(p)
        return len(packs)
