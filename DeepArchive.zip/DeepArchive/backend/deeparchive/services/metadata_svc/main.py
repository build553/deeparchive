"""Metadata service: vends the browsable file catalog (what the customer sees).

Reads an org's WARM manifests (db/<org>/*.json) and serves a browsable listing
-- files, sizes, folders. Instant; never touches Glacier. When the customer
picks a file to retrieve, the entry already carries its tarball_key + offset so
the restore/handoff knows exactly what to thaw and extract.

Public: GET /v1/catalog            -> all files
        GET /v1/catalog?prefix=x/  -> files under a folder
        GET /v1/folders?prefix=x/  -> immediate sub-folders (tree nav)
"""
from __future__ import annotations

from typing import Any, Callable, Optional

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import Response

from deeparchive.audit import AuditLog, NullAudit, emit
from deeparchive.catalog import build_catalog, filter_prefix, find, list_folders
from deeparchive.services.internal_client import IdentityClient
from deeparchive.storage import Storage
from deeparchive.storage.errors import StorageError

StorageForCountry = Callable[[str], Storage]


def _nonce_for(storage: Storage, org_id: str, pack_id: str) -> str:
    """Read the pack's manifest to get its encryption nonce (for decrypt)."""
    return storage.get_manifest(org_id, pack_id).encryption_nonce


def build_metadata_app(
    identity: IdentityClient,
    storage_for_country: Optional[StorageForCountry] = None,
    audit: Optional[AuditLog | NullAudit] = None,
) -> FastAPI:
    app = FastAPI(title="DeepArchive Metadata", version="0.1.0")

    def _client_ip(request: Request) -> str:
        return request.client.host if request.client else ""

    def _resolve(authorization: Optional[str]) -> tuple[str, Storage]:
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(status_code=401, detail="missing API key")
        try:
            info = identity.validate(authorization.split(" ", 1)[1])
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="invalid API key") from exc
        country = info["country"]
        storage = (storage_for_country or (lambda c: Storage.for_country(c)))(country)
        return info["account_id"], storage

    def _catalog(account_id: str, storage: Storage) -> list:  # type: ignore[type-arg]
        try:
            return build_catalog(storage.list_manifests(account_id))
        except StorageError as exc:
            # S3 unavailable (e.g. throttle/expired creds) -> clean 503, not 500.
            raise HTTPException(status_code=503, detail="catalog temporarily unavailable") from exc

    @app.get("/v1/catalog")
    def catalog(
        prefix: str = "", authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        account_id, storage = _resolve(authorization)
        entries = filter_prefix(_catalog(account_id, storage), prefix)
        return {"prefix": prefix, "count": len(entries),
                "files": [e.to_dict() for e in entries]}

    @app.get("/v1/folders")
    def folders(
        prefix: str = "", authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        account_id, storage = _resolve(authorization)
        subs = list_folders(_catalog(account_id, storage), prefix)
        return {"prefix": prefix, "folders": subs}

    @app.get("/v1/files/{path:path}/content")
    def get_file(
        path: str, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> Response:
        """The turnkey 'get me this file': locate -> (if restored) extract+decrypt.

        If the file's tarball is still cold/thawing, returns 409 with the state so
        the caller knows to wait (restore is requested via the restore service).
        """
        account_id, storage = _resolve(authorization)
        entry = find(_catalog(account_id, storage), path)
        if entry is None:
            raise HTTPException(status_code=404, detail="file not in catalog")
        if not storage.restore_ready(entry.tarball_key):
            raise HTTPException(
                status_code=409,
                detail="file's archive not restored yet; request a restore first",
            )
        nonce = _nonce_for(storage, account_id, entry.pack_id) if entry.encrypted else ""
        data = storage.extract_file(
            account_id, entry.tarball_key, entry.offset, entry.size, nonce
        )
        emit(audit, account_id, account_id, "file.retrieve", path,
             source_ip=_client_ip(request),
             detail={"tarball_key": entry.tarball_key, "bytes": entry.size})
        return Response(content=data, media_type="application/octet-stream")

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "metadata"}

    return app
