"""ASGI entrypoint for metadata: real identity client + audit."""
from deeparchive.services.internal_client import IdentityClient
from deeparchive.services.metadata_svc import build_metadata_app
from deeparchive.services.prod_wiring import Httpx, build_audit

_http = Httpx()
app = build_metadata_app(identity=IdentityClient(_http), audit=build_audit())
