"""Metadata microservice: vends the browsable file catalog from warm manifests."""
from deeparchive.services.metadata_svc.main import build_metadata_app

__all__ = ["build_metadata_app"]
