"""Services: thin deployable surfaces that import the core modules.

Rule: services orchestrate core modules (manifest, packer, storage, restore).
They contain NO archival logic of their own -- keep the logic in core.
"""
