"""Website gateway: serves the static single-page UI that calls the /v1 API."""
from deeparchive.services.web.web import create_web_app, index_html

__all__ = ["create_web_app", "index_html"]
