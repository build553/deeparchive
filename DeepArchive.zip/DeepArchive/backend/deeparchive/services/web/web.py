"""Website gateway: serves the static single-page UI.

The page (index.html) calls the /v1 API. In a full deployment you'd mount both
on one app (API routes + this static page) or serve the page from a CDN/S3 and
point it at the API origin. Here we expose a small app that serves the page so
it's real and testable.
"""
from __future__ import annotations

import os

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

_HERE = os.path.dirname(__file__)
_INDEX = os.path.join(_HERE, "index.html")


def index_html() -> str:
    with open(_INDEX, encoding="utf-8") as f:
        return f.read()


def create_web_app() -> FastAPI:
    app = FastAPI(title="DeepArchive Web")

    @app.get("/", response_class=HTMLResponse)
    def home() -> str:
        return index_html()

    return app
