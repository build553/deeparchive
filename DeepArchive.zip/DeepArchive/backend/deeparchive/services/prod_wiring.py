"""Shared production wiring for the ASGI entrypoints.

Constructs the REAL dependencies (HTTP transport, audit log, notifier, email
resolver) from config/env, so each service's asgi.py stays a one-liner. All of
these degrade to None/no-op when not configured -- dev/test run with nothing set
and behave exactly as before.
"""
from __future__ import annotations

from typing import Any, Callable

from deeparchive import config
from deeparchive.audit import AuditLog, NullAudit
from deeparchive.notify import Notifier, RoutingNotifier, SesNotifier, SnsNotifier


class Httpx:  # pragma: no cover - real network at runtime
    """Minimal httpx-backed transport for the internal_client resolvers."""

    def request(self, method: str, url: str, headers: Any = None, json: Any = None) -> Any:
        import httpx
        return httpx.request(method, url, headers=headers or {}, json=json)


def build_audit() -> AuditLog | NullAudit:
    """Real S3 audit log when enabled, else a no-op sink."""
    if not config.AUDIT_ENABLED:
        return NullAudit()
    import boto3
    s3 = boto3.client("s3", region_name=config.REGION)
    return AuditLog(bucket=config.BUCKET, s3=s3)


def build_notifier() -> Notifier | None:
    """SES email (+ SNS SMS) notifier when a sender is configured, else None."""
    if not config.NOTIFY_ENABLED:
        return None
    email = SesNotifier(sender=config.NOTIFY_EMAIL_SENDER, region=config.REGION)
    sms = SnsNotifier(region=config.REGION)
    return RoutingNotifier(email=email, sms=sms)


def build_email_resolver(http: Httpx) -> Callable[[str], str] | None:
    """Resolve account_id -> notification email via identity's internal API.

    Returns None when notifications are disabled (no point resolving emails).
    """
    if not config.NOTIFY_ENABLED:
        return None
    from deeparchive.services.topology import PORTS

    def resolve(account_id: str) -> str:  # pragma: no cover - real network
        base = f"http://127.0.0.1:{PORTS['identity']}"
        resp = http.request("GET", f"{base}/internal/contact/{account_id}")
        data = resp.json()
        return str(data.get("email", ""))

    return resolve
