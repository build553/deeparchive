"""Restore microservice: 48h retrieval, status, download. Region from identity."""
from deeparchive.services.restore_svc.main import build_restore_app

__all__ = ["build_restore_app"]
