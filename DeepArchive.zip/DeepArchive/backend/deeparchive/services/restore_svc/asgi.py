"""ASGI entrypoint for restore: real identity client, audit, and notifier.

Note: approval_provider is left unset here -- egress-approval governance needs
access to the org store (which lives in the identity service). Wiring it in the
split deployment means exposing org membership over an internal API; that is a
deliberate follow-up, so restore runs without approval gating unless provided.
"""
from deeparchive.services.internal_client import IdentityClient
from deeparchive.services.prod_wiring import (
    Httpx,
    build_audit,
    build_email_resolver,
    build_notifier,
)
from deeparchive.services.restore_svc import build_restore_app

_http = Httpx()
app = build_restore_app(
    identity=IdentityClient(_http),
    audit=build_audit(),
    notifier=build_notifier(),
    notify_email_for=build_email_resolver(_http),
)
