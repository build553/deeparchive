"""Restore service: async, long-lived retrieval (48h Glacier jobs).

Owns restore-request, status polling, and download delivery. Region resolved
from identity (account home region). Separate process because its lifecycle
(48h waits, event-driven) is totally different from synchronous ingest.

Public: POST /v1/restore, GET /v1/restore/{key}, GET /v1/restore/{key}/download
"""
from __future__ import annotations

from typing import Any, Callable, Optional

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from deeparchive.audit import AuditLog, NullAudit, emit
from deeparchive.notify import Notifier, restore_ready
from deeparchive.restore import (
    RestoreJob,
    RestoreState,
    check_restore,
    request_restore,
)
from deeparchive.services.ingest_svc.main import StorageForCountry
from deeparchive.services.internal_client import IdentityClient
from deeparchive.storage import Storage
from deeparchive.storage.errors import StorageError

# An approval provider maps an org_id -> its ApprovalService (or None if the org
# has no egress governance). Typed loosely to avoid a hard import dependency.
ApprovalProvider = Callable[[str], Any]


class RestoreBody(BaseModel):
    tarball_key: str


def build_restore_app(
    identity: IdentityClient,
    storage_for_country: Optional[StorageForCountry] = None,
    audit: Optional[AuditLog | NullAudit] = None,
    approval_provider: Optional[ApprovalProvider] = None,
    notifier: Optional[Notifier] = None,
    notify_email_for: Optional[Callable[[str], str]] = None,
) -> FastAPI:
    app = FastAPI(title="DeepArchive Restore", version="0.1.0")

    def _client_ip(request: Request) -> str:
        return request.client.host if request.client else ""

    def _account(authorization: Optional[str]) -> str:
        """Authenticate and return the caller's account_id (no ownership check)."""
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(status_code=401, detail="missing API key")
        try:
            info = identity.validate(authorization.split(" ", 1)[1])
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="invalid API key") from exc
        return str(info["account_id"])

    def _resolve(authorization: Optional[str], tarball_key: str) -> tuple[str, Storage]:
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(status_code=401, detail="missing API key")
        try:
            info = identity.validate(authorization.split(" ", 1)[1])
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="invalid API key") from exc
        account_id, country = info["account_id"], info["country"]
        if not tarball_key.startswith(f"data/{account_id}/"):
            raise HTTPException(status_code=403, detail="not your org's data")
        storage = (storage_for_country or (lambda c: Storage.for_country(c)))(country)
        return account_id, storage

    def _notify_ready(account_id: str, tarball_key: str) -> None:
        """Fire the 'restore ready' notification (best-effort, never fatal)."""
        if notifier is None or notify_email_for is None:
            return
        try:
            to = notify_email_for(account_id)
            notifier.send(restore_ready(to, tarball_key))
        except Exception:  # noqa: BLE001 - notification is best-effort
            return

    def _manifest_for_tarball(storage: Storage, account_id: str, tarball_key: str) -> Any:
        """Find the manifest whose tarball matches (for the restore size check)."""
        for m in storage.list_manifests(account_id):
            if m.tarball_key == tarball_key:
                return m
        return None

    @app.post("/v1/restore")
    def start(
        body: RestoreBody, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, object]:
        account_id, storage = _resolve(authorization, body.tarball_key)
        # Org egress governance: a large restore must be admin-approved first.
        if approval_provider is not None:
            svc = approval_provider(account_id)
            if svc is not None:
                manifest = _manifest_for_tarball(storage, account_id, body.tarball_key)
                size = manifest.tarball_bytes if manifest else 0
                req = svc.request(account_id, body.tarball_key, size)
                if not svc.is_cleared(req.request_id):
                    emit(audit, account_id, account_id, "restore.pending_approval",
                         body.tarball_key, source_ip=_client_ip(request),
                         detail={"request_id": req.request_id})
                    return {"tarball_key": body.tarball_key,
                            "state": "PENDING_APPROVAL",
                            "request_id": req.request_id}
        try:
            job = request_restore(storage, body.tarball_key)
        except StorageError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        emit(audit, account_id, account_id, "restore.request", body.tarball_key,
             source_ip=_client_ip(request))
        return {"tarball_key": job.tarball_key, "state": job.state.value, "sla_hours": 48}

    @app.post("/v1/restore/{request_id}/approve")
    def approve(
        request_id: str, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        from deeparchive.accounts.approval import NotAuthorizedError
        account_id = _account(authorization)
        if approval_provider is None:
            raise HTTPException(status_code=404, detail="approvals not enabled")
        svc = approval_provider(account_id)
        if svc is None:
            raise HTTPException(status_code=404, detail="no approvals for org")
        try:
            req = svc.approve(request_id, account_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no such request") from exc
        except NotAuthorizedError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        emit(audit, account_id, account_id, "restore.approve", req.tarball_key,
             source_ip=_client_ip(request), detail={"request_id": request_id})
        return {"request_id": request_id, "state": req.state.value}

    @app.post("/v1/restore/{request_id}/reject")
    def reject(
        request_id: str, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        from deeparchive.accounts.approval import NotAuthorizedError
        account_id = _account(authorization)
        if approval_provider is None:
            raise HTTPException(status_code=404, detail="approvals not enabled")
        svc = approval_provider(account_id)
        if svc is None:
            raise HTTPException(status_code=404, detail="no approvals for org")
        try:
            req = svc.reject(request_id, account_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="no such request") from exc
        except NotAuthorizedError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        emit(audit, account_id, account_id, "restore.reject", req.tarball_key,
             source_ip=_client_ip(request), detail={"request_id": request_id})
        return {"request_id": request_id, "state": req.state.value}

    @app.get("/v1/restore/{tarball_key:path}/download")
    def download(
        tarball_key: str, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, object]:
        account_id, storage = _resolve(authorization, tarball_key)
        try:
            ready = storage.restore_ready(tarball_key)
        except StorageError as exc:
            # Object missing / not accessible -> clean 404, not a 500.
            raise HTTPException(status_code=404, detail=f"not found: {exc}") from exc
        if not ready:
            raise HTTPException(status_code=409, detail="restore not ready")
        emit(audit, account_id, account_id, "restore.download", tarball_key,
             source_ip=_client_ip(request))
        return {"tarball_key": tarball_key, "download_url": storage.presigned_get_url(tarball_key)}

    @app.get("/v1/restore/{tarball_key:path}")
    def status(
        tarball_key: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, object]:
        account_id, storage = _resolve(authorization, tarball_key)
        job = RestoreJob(tarball_key=tarball_key, state=RestoreState.RESTORING)
        try:
            job = check_restore(storage, job)
        except StorageError as exc:
            # Object missing / not accessible -> clean 404, not a 500.
            raise HTTPException(status_code=404, detail=f"not found: {exc}") from exc
        # When a restore first becomes READY, notify the customer (best-effort).
        if job.state == RestoreState.READY:
            _notify_ready(account_id, tarball_key)
        return {"tarball_key": job.tarball_key, "state": job.state.value}

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "restore"}

    return app
