"""Internal service-to-service client: local-first, remote-fallback.

Locality-aware routing to protect latency AND network cost: a service ALWAYS
tries its co-located instance (127.0.0.1) first -- free, sub-ms. Only if the
local instance is unhealthy does it fall back to the cluster URL
(DEEPARCHIVE_<SVC>_URL, an LB/DNS that routes to a healthy instance on another
host). Local health is cached so we don't probe on every call.

  normal call  -> local (free)
  local down   -> remote via LB (rare, costs cross-host traffic)
"""
from __future__ import annotations

import time
from typing import Any, Protocol

from deeparchive.services.topology import PORTS, service_url


class InternalHttp(Protocol):
    def request(
        self, method: str, url: str, headers: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any: ...


class _Resolver:
    """Resolves a service to local-first / remote-fallback base URLs, with a
    cached local-health flag so we don't re-probe every call."""

    def __init__(self, http: InternalHttp, health_ttl: float = 5.0):
        self._http = http
        self._ttl = health_ttl
        # service -> (local_healthy, checked_at)
        self._health: dict[str, tuple[bool, float]] = {}

    def _local_url(self, service: str) -> str:
        return f"http://127.0.0.1:{PORTS[service]}"

    def _remote_url(self, service: str) -> str:
        return service_url(service)  # env DEEPARCHIVE_<SVC>_URL -> LB/DNS

    def _local_healthy(self, service: str, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        cached = self._health.get(service)
        if cached is not None and (now - cached[1]) < self._ttl:
            return cached[0]
        healthy = self._probe(self._local_url(service))
        self._health[service] = (healthy, now)
        return healthy

    def _probe(self, base: str) -> bool:
        try:
            resp = self._http.request("GET", f"{base}/v1/health")
            return bool(resp.status_code == 200)
        except Exception:  # noqa: BLE001 - any error => unhealthy
            return False

    def bases(self, service: str) -> list[str]:
        """Ordered base URLs to try: local first (if healthy), then remote."""
        local = self._local_url(service)
        remote = self._remote_url(service)
        if self._local_healthy(service):
            # Local healthy -> try local, then remote as a safety net.
            return [local] if local == remote else [local, remote]
        # Local unhealthy -> go straight to the cluster (remote), local last.
        return [remote] if local == remote else [remote, local]

    def call(
        self, service: str, method: str, path: str,
        json: dict[str, Any] | None = None,
    ) -> Any:
        """Call an endpoint, trying local-first then failing over to remote."""
        last_exc: Exception | None = None
        for base in self.bases(service):
            try:
                resp = self._http.request(method, f"{base}{path}", json=json)
                # Mark local health based on the outcome.
                if base == self._local_url(service):
                    self._health[service] = (resp.status_code < 500, time.time())
                return resp
            except Exception as exc:  # noqa: BLE001 - try the next base
                last_exc = exc
                if base == self._local_url(service):
                    self._health[service] = (False, time.time())
        raise ConnectionError(
            f"all instances of {service!r} unreachable"
        ) from last_exc


class IdentityClient:
    """Calls the identity service (local-first) to validate keys + resolve region."""

    def __init__(self, http: InternalHttp, resolver: _Resolver | None = None):
        self._r = resolver or _Resolver(http)

    def validate(self, api_key: str) -> dict[str, Any]:
        resp = self._r.call("identity", "POST", "/internal/validate",
                            json={"api_key": api_key})
        if resp.status_code != 200:
            raise PermissionError("invalid API key")
        return dict(resp.json())


class BillingClient:
    """Calls the billing service (local-first) to check quota."""

    def __init__(self, http: InternalHttp, resolver: _Resolver | None = None):
        self._r = resolver or _Resolver(http)

    def check_quota(self, account_id: str, size_bytes: int) -> bool:
        resp = self._r.call("billing", "POST", "/internal/quota",
                            json={"account_id": account_id, "size_bytes": size_bytes})
        return bool(resp.status_code == 200 and resp.json().get("allowed"))
