"""Ingest service: the regional, high-throughput hot path.

Owns pack upload (presigned), manifest registration, file lookup, thumbnails,
encryption. REGION IS RESOLVED FROM IDENTITY (the account's authoritative home
region), never trusted from the request -- this enforces residency. Quota is
checked via the billing service before a manifest is accepted.

Public: POST /v1/packs/upload-url, POST /v1/packs/complete, GET /v1/files,
        PUT/GET /v1/thumbnails/{path}
"""
from __future__ import annotations

import base64
from typing import Any, Callable, Optional

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel

from deeparchive import regions
from deeparchive.audit import AuditLog, NullAudit, emit
from deeparchive.manifest import Manifest
from deeparchive.services.internal_client import BillingClient, IdentityClient
from deeparchive.storage import Storage

StorageForCountry = Callable[[str], Storage]


class UploadUrlBody(BaseModel):
    tarball_key: str


class PackCompleteBody(BaseModel):
    manifest_json: str


class ThumbnailBody(BaseModel):
    image_base64: str


def build_ingest_app(
    identity: IdentityClient,
    billing: BillingClient,
    storage_for_country: Optional[StorageForCountry] = None,
    audit: Optional[AuditLog | NullAudit] = None,
) -> FastAPI:
    app = FastAPI(title="DeepArchive Ingest", version="0.1.0")

    def _resolve(authorization: Optional[str]) -> tuple[str, Storage]:
        """Authenticate via identity -> (account_id, region-bound Storage).

        Region comes from the ACCOUNT (identity), not the request body.
        """
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(status_code=401, detail="missing API key")
        api_key = authorization.split(" ", 1)[1]
        try:
            info = identity.validate(api_key)
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail="invalid API key") from exc
        account_id = info["account_id"]
        country = info["country"]  # authoritative, from the account
        if storage_for_country is not None:
            storage = storage_for_country(country)
        else:
            storage = Storage.for_country(country)
        return account_id, storage

    def _owns(account_id: str, tarball_key: str) -> None:
        if not tarball_key.startswith(f"data/{account_id}/"):
            raise HTTPException(status_code=403, detail="not your org's data")

    def _client_ip(request: Request) -> str:
        return request.client.host if request.client else ""

    @app.post("/v1/packs/upload-url")
    def upload_url(
        body: UploadUrlBody, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        account_id, storage = _resolve(authorization)
        _owns(account_id, body.tarball_key)
        emit(audit, account_id, account_id, "pack.upload_url", body.tarball_key,
             source_ip=_client_ip(request))
        return {"url": storage.presigned_put_url(body.tarball_key),
                "tarball_key": body.tarball_key}

    @app.post("/v1/packs/complete")
    def complete(
        body: PackCompleteBody, request: Request,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        account_id, storage = _resolve(authorization)
        try:
            manifest = Manifest.from_json(body.manifest_json)
        except (KeyError, ValueError, TypeError) as exc:
            # Malformed / incomplete manifest JSON -> client error, not a 500.
            raise HTTPException(status_code=400, detail=f"invalid manifest: {exc}") from exc
        _owns(account_id, manifest.tarball_key)
        if manifest.org_id != account_id:
            raise HTTPException(status_code=403, detail="manifest org mismatch")
        # Quota check via billing service.
        if not billing.check_quota(account_id, manifest.tarball_bytes):
            raise HTTPException(status_code=402, detail="quota exceeded or no plan")
        storage.register_manifest(manifest)
        emit(audit, account_id, account_id, "pack.register", manifest.tarball_key,
             source_ip=_client_ip(request),
             detail={"pack_id": manifest.pack_id, "bytes": manifest.tarball_bytes})
        return {"status": "registered", "pack_id": manifest.pack_id}

    @app.get("/v1/files")
    def find_file(
        path: str, authorization: Optional[str] = Header(default=None)
    ) -> dict[str, Any]:
        account_id, storage = _resolve(authorization)
        found = storage.find_file(account_id, path)
        if found is None:
            raise HTTPException(status_code=404, detail="not found")
        manifest, entry = found
        return {"path": entry.path, "tarball_key": manifest.tarball_key,
                "offset": entry.offset, "length": entry.length, "sha256": entry.sha256}

    @app.put("/v1/thumbnails/{archive_path:path}")
    def put_thumb(
        archive_path: str, body: ThumbnailBody,
        authorization: Optional[str] = Header(default=None),
    ) -> dict[str, str]:
        account_id, storage = _resolve(authorization)
        key = storage.put_thumbnail(account_id, archive_path, base64.b64decode(body.image_base64))
        return {"status": "stored", "key": key}

    @app.get("/v1/thumbnails/{archive_path:path}")
    def get_thumb(
        archive_path: str, authorization: Optional[str] = Header(default=None)
    ) -> Response:
        account_id, storage = _resolve(authorization)
        try:
            data = storage.get_thumbnail(account_id, archive_path)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=404, detail="no thumbnail") from exc
        return Response(content=data, media_type="image/jpeg")

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "ingest"}

    _ = regions  # region resolution happens via identity; regions used server-side
    return app
