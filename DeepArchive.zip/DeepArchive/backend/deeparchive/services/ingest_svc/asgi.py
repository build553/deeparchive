"""ASGI entrypoint for ingest: wires real internal clients + audit."""
from deeparchive.services.ingest_svc import build_ingest_app
from deeparchive.services.internal_client import BillingClient, IdentityClient
from deeparchive.services.prod_wiring import Httpx, build_audit

_http = Httpx()
app = build_ingest_app(
    identity=IdentityClient(_http),
    billing=BillingClient(_http),
    audit=build_audit(),
)
