"""Ingest microservice: packing, upload, encryption, thumbnails, file lookup.

Region resolved from identity (account home region); quota checked via billing.
"""
from deeparchive.services.ingest_svc.main import build_ingest_app

__all__ = ["build_ingest_app"]
