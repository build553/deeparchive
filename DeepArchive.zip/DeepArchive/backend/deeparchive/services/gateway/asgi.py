"""ASGI entrypoint for the gateway: uvicorn deeparchive.services.gateway.asgi:app"""
from deeparchive.services.gateway import build_gateway_app

app = build_gateway_app()
