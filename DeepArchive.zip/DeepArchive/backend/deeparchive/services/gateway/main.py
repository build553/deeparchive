"""Gateway: the thin public edge, with retry-and-failover.

Routes public requests to the right backend service. If an instance returns a
5xx or is unreachable, the gateway RETRIES against another instance (local-first,
then the remote cluster pool) so a single unhealthy instance doesn't surface as
a user-facing error. Only when ALL instances fail does it return the error.
"""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from deeparchive.observability import METRICS, log_event
from deeparchive.services.topology import PORTS, service_url

_ROUTES = [
    ("/v1/accounts", "identity"),
    ("/v1/orgs", "identity"),
    ("/scim", "identity"),
    ("/v1/billing", "billing"),
    ("/v1/packs", "ingest"),
    ("/v1/files/", "metadata"),   # /v1/files/{path}/content -> metadata (single-file get)
    ("/v1/files", "ingest"),      # /v1/files?path= lookup -> ingest
    ("/v1/thumbnails", "ingest"),
    ("/v1/catalog", "metadata"),
    ("/v1/folders", "metadata"),
    ("/v1/restore", "restore"),
]

# 5xx status codes that should trigger a failover retry to another instance.
_RETRYABLE = frozenset({500, 502, 503, 504})


def route_for(path: str) -> str | None:
    for prefix, svc in _ROUTES:
        if path.startswith(prefix):
            return svc
    return None


def _instances(service: str) -> list[str]:
    """Ordered instance base URLs: local first, then the remote cluster pool."""
    local = f"http://127.0.0.1:{PORTS[service]}"
    remote = service_url(service)
    return [local] if local == remote else [local, remote]


def build_gateway_app(http: Any = None) -> FastAPI:
    app = FastAPI(title="DeepArchive Gateway", version="0.1.0")

    @app.get("/v1/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "service": "gateway"}

    @app.api_route("/{full_path:path}", methods=["GET", "POST", "PUT", "DELETE"])
    async def proxy(full_path: str, request: Request) -> JSONResponse:
        svc = route_for("/" + full_path)
        if svc is None:
            return JSONResponse({"detail": "no route"}, status_code=404)

        client = http
        if client is None:  # pragma: no cover - real httpx at runtime
            import httpx
            client = httpx

        body = await request.body()
        headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
        params = dict(request.query_params)

        last: JSONResponse | None = None
        for i, base in enumerate(_instances(svc)):
            target = f"{base}/{full_path}"
            try:
                resp = client.request(request.method, target, headers=headers,
                                      params=params, content=body)
            except Exception:  # noqa: BLE001 - instance unreachable -> try next
                log_event("gateway_instance_unreachable", service=svc, base=base)
                METRICS.incr("gateway_failover")
                continue
            # 5xx from this instance -> try the next instance (failover).
            if resp.status_code in _RETRYABLE and i < len(_instances(svc)) - 1:
                log_event("gateway_5xx_failover", service=svc, base=base,
                          status=resp.status_code)
                METRICS.incr("gateway_failover")
                last = _as_json(resp)
                continue
            return _as_json(resp)

        # All instances failed.
        if last is not None:
            return last
        return JSONResponse({"detail": f"{svc} unavailable"}, status_code=503)

    return app


def _as_json(resp: Any) -> JSONResponse:
    try:
        payload = resp.json()
    except Exception:  # noqa: BLE001
        payload = {"raw": getattr(resp, "text", "")}
    return JSONResponse(payload, status_code=resp.status_code)
