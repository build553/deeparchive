"""Gateway microservice: thin public edge that routes to backend services."""
from deeparchive.services.gateway.main import build_gateway_app, route_for

__all__ = ["build_gateway_app", "route_for"]
