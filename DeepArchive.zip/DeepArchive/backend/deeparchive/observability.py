"""Observability: structured logging + lightweight metrics.

Structured (JSON) logs make operations searchable in CloudWatch/etc. Metrics are
simple in-process counters (a real deployment ships them to CloudWatch/EMF).
Kept dependency-free and cheap; safe to call from anywhere.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from collections import Counter
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

_LOGGER_NAME = "deeparchive"


def get_logger() -> logging.Logger:
    """A JSON-emitting logger, configured once."""
    logger = logging.getLogger(_LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(_JsonFormatter())
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "level": record.levelname,
            "msg": record.getMessage(),
            "logger": record.name,
        }
        extra = getattr(record, "fields", None)
        if isinstance(extra, dict):
            payload.update(extra)
        return json.dumps(payload, sort_keys=True)


def log_event(event: str, **fields: Any) -> None:
    """Emit a structured info log line: {'msg': event, ...fields}."""
    get_logger().info(event, extra={"fields": fields})


class Metrics:
    """In-process counters + timers. Swap for CloudWatch/EMF in prod."""

    def __init__(self) -> None:
        self.counters: Counter[str] = Counter()
        self.timers_ms: dict[str, float] = {}

    def incr(self, name: str, by: int = 1) -> None:
        self.counters[name] += by

    @contextmanager
    def timed(self, name: str) -> Iterator[None]:
        start = time.perf_counter()
        try:
            yield
        finally:
            self.timers_ms[name] = (time.perf_counter() - start) * 1000.0


# A default process-wide metrics sink (tests can create their own).
METRICS = Metrics()
