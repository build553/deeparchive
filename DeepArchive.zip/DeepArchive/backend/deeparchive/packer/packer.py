"""Pack files into ~256MB tarballs and build their manifests.

Groups files by retention class (never mixes classes in one tarball), fills
tarballs up to the configured pack size, and records sha256 + offset/length for
every file so a single file can later be extracted without unpacking the rest.

No S3 here -- this module only produces (tarball_path, Manifest) pairs on local
disk. Uploading is the storage module's job.
"""
from __future__ import annotations

import hashlib
import os
import tarfile
import uuid
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import datetime, timezone

from deeparchive import config
from deeparchive.index import ArchiveIndex
from deeparchive.manifest import FileEntry, Manifest, RetentionClass

_READ_CHUNK = 1024 * 1024  # 1 MiB


@dataclass(frozen=True)
class SourceFile:
    """A file to archive: where it is on disk, its logical path, and its class."""

    local_path: str
    archive_path: str  # path recorded in the manifest / tarball
    retention: RetentionClass
    legal_hold: bool = False


@dataclass(frozen=True)
class Pack:
    """Result of packing: the tarball on disk plus its manifest."""

    tarball_path: str
    manifest: Manifest


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(_READ_CHUNK):
            h.update(chunk)
    return h.hexdigest()


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _group_key(f: SourceFile) -> tuple[RetentionClass, bool]:
    return (f.retention, f.legal_hold)


def _batches_by_size(
    files: list[SourceFile], pack_size: int
) -> Iterator[list[SourceFile]]:
    """Yield batches whose total size stays near pack_size (one file never split)."""
    batch: list[SourceFile] = []
    total = 0
    for f in files:
        size = os.path.getsize(f.local_path)
        if batch and total + size > pack_size:
            yield batch
            batch, total = [], 0
        batch.append(f)
        total += size
    if batch:
        yield batch


def pack(
    files: Iterable[SourceFile],
    out_dir: str,
    org_id: str,
    pack_size: int = config.PACK_SIZE_BYTES,
    index: ArchiveIndex | None = None,
) -> list[Pack]:
    """Pack files into tarballs grouped by (retention, legal_hold).

    If an ArchiveIndex is given, files already archived (same path + sha256) are
    skipped -- this makes backups incremental and reruns resume-safe.

    Returns one Pack per tarball produced. Writes tarballs into out_dir.
    """
    os.makedirs(out_dir, exist_ok=True)

    # Group by retention class + legal hold so one tarball = one policy.
    # Skip files already archived (incremental / resume).
    groups: dict[tuple[RetentionClass, bool], list[SourceFile]] = {}
    for f in files:
        if index is not None and index.is_archived(f.archive_path, _sha256_of_file(f.local_path)):
            continue
        groups.setdefault(_group_key(f), []).append(f)

    packs: list[Pack] = []
    for (retention, legal_hold), group_files in groups.items():
        for batch in _batches_by_size(group_files, pack_size):
            packs.append(
                _write_one_pack(batch, out_dir, org_id, retention, legal_hold)
            )
    return packs


def _write_one_pack(
    batch: list[SourceFile],
    out_dir: str,
    org_id: str,
    retention: RetentionClass,
    legal_hold: bool,
) -> Pack:
    pack_id = f"pack_{uuid.uuid4().hex[:16]}"
    tarball_name = f"{pack_id}.tar"
    tarball_path = os.path.join(out_dir, tarball_name)
    tarball_key = f"{config.DATA_PREFIX}{org_id}/{retention.value}/{tarball_name}"

    # Write the tarball first, recording sha256 per source file.
    shas: dict[str, str] = {}
    with tarfile.open(tarball_path, "w") as tar:
        for src in batch:
            info = tar.gettarinfo(name=src.local_path, arcname=src.archive_path)
            with open(src.local_path, "rb") as fh:
                tar.addfile(info, fileobj=fh)
            shas[src.archive_path] = _sha256_of_file(src.local_path)

    # Read offsets back from the finished tarball, where offset_data is
    # authoritative (tarfile computes it correctly on read).
    entries: list[FileEntry] = []
    with tarfile.open(tarball_path, "r") as tar:
        for member in tar.getmembers():
            entries.append(
                FileEntry(
                    path=member.name,
                    offset=member.offset_data,
                    length=member.size,
                    sha256=shas[member.name],
                    modified=_now_iso(),
                )
            )

    manifest = Manifest(
        pack_id=pack_id,
        org_id=org_id,
        created_at=_now_iso(),
        tarball_key=tarball_key,
        tarball_sha256=_sha256_of_file(tarball_path),
        tarball_bytes=os.path.getsize(tarball_path),
        retention_class=retention,
        legal_hold=legal_hold,
        files=entries,
    )
    return Pack(tarball_path=tarball_path, manifest=manifest)
