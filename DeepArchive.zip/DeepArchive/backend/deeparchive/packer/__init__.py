"""Packer: bundle many files into ~256MB tarballs + build their manifest.

Single responsibility: turn a set of files into (tarball, manifest) pairs,
grouped by retention class, computing sha256 + offset/length per file.
Depends on: manifest. No S3 here (that's storage).
"""
from deeparchive.packer.packer import Pack, SourceFile, pack

__all__ = ["Pack", "SourceFile", "pack"]
