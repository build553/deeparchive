"""Central configuration for DeepArchive.

Every surface (CLI, SDK, server) imports settings from here so behavior stays
consistent. Values can be overridden via environment variables.
"""
import os

# --- AWS / bucket ---
BUCKET = os.environ.get("DEEPARCHIVE_BUCKET", "deep-archive-lab")
REGION = os.environ.get("DEEPARCHIVE_REGION", "us-east-1")

# --- Prefixes (mirror the serac layout) ---
DATA_PREFIX = "data/"        # tarballs -> transitioned to Deep Archive
INDEX_PREFIX = "db/"         # manifests -> stay warm in S3 Standard
REPORTS_PREFIX = "reports/"  # human-readable rollups -> warm
THUMBS_PREFIX = "thumbs/"    # small previews -> warm (S3 Standard-IA), browsable

# --- Packing ---
PACK_SIZE_BYTES = int(os.environ.get("DEEPARCHIVE_PACK_SIZE", 256 * 1024 * 1024))  # 256 MiB

# --- Retrieval ---
# 48h SLA -> Bulk tier for Deep Archive (cheapest).
RESTORE_TIER = os.environ.get("DEEPARCHIVE_RESTORE_TIER", "Bulk")
RESTORE_SLA_HOURS = 48
# How many days a restored (temporarily warm) copy stays available.
RESTORE_AVAILABILITY_DAYS = int(os.environ.get("DEEPARCHIVE_RESTORE_DAYS", 7))

MANIFEST_VERSION = "1.0"

# --- Payments (Stripe) ---
# Empty = dev/test (FakeProcessor). Set at deploy to go live.
STRIPE_API_KEY = os.environ.get("DEEPARCHIVE_STRIPE_API_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("DEEPARCHIVE_STRIPE_WEBHOOK_SECRET", "")

# --- Ops maturity (audit + notifications). All near-zero fixed cost. ---
# Audit: append events to S3 JSONL (this bucket). Off = no-op (dev/test).
AUDIT_ENABLED = os.environ.get("DEEPARCHIVE_AUDIT_ENABLED", "").lower() in ("1", "true", "yes")
# Notifications: SES email + SNS SMS (pay-per-use). Set sender to enable email.
NOTIFY_EMAIL_SENDER = os.environ.get("DEEPARCHIVE_NOTIFY_SENDER", "")
NOTIFY_ENABLED = bool(NOTIFY_EMAIL_SENDER)

# --- Multipart upload (large tarballs) ---
MULTIPART_THRESHOLD_BYTES = int(
    os.environ.get("DEEPARCHIVE_MULTIPART_THRESHOLD", 64 * 1024 * 1024)
)  # 64 MiB -> switch to multipart above this
MULTIPART_CHUNK_BYTES = int(
    os.environ.get("DEEPARCHIVE_MULTIPART_CHUNK", 16 * 1024 * 1024)
)  # 16 MiB parts
MULTIPART_MAX_CONCURRENCY = int(os.environ.get("DEEPARCHIVE_MULTIPART_CONCURRENCY", 4))

# --- Retries ---
# Adaptive retry handles throttling/5xx; high attempts for large archival jobs.
S3_MAX_ATTEMPTS = int(os.environ.get("DEEPARCHIVE_S3_MAX_ATTEMPTS", 10))

# --- DynamoDB (metadata persistence) ---
# DDB_ENDPOINT_URL: unset = real AWS DynamoDB; set (e.g. http://localhost:8000)
# = DynamoDB Local running on our own server. Same code either way.
DDB_ENDPOINT_URL = os.environ.get("DEEPARCHIVE_DDB_ENDPOINT") or None
DDB_TABLE_PREFIX = os.environ.get("DEEPARCHIVE_DDB_TABLE_PREFIX", "deeparchive")
