"""Catalog: the browsable file listing vended from warm manifests.

The customer BROWSES this (instant, warm) -- it's what they see. It never touches
Glacier. Each entry says which tarball + offset holds the file, so when the
customer requests a specific file, retrieval knows exactly what to thaw + extract.

Built by aggregating an org's db/<org>/*.json manifests.
"""
from __future__ import annotations

from dataclasses import dataclass

from deeparchive.manifest import Manifest


@dataclass(frozen=True)
class CatalogEntry:
    """One browsable file in the catalog."""

    path: str
    size: int
    modified: str
    retention: str
    legal_hold: bool
    encrypted: bool
    # Location (for retrieval; the UI may hide these):
    tarball_key: str
    offset: int
    pack_id: str

    def to_dict(self) -> dict[str, object]:
        return {
            "path": self.path,
            "size": self.size,
            "modified": self.modified,
            "retention": self.retention,
            "legal_hold": self.legal_hold,
            "encrypted": self.encrypted,
            "tarball_key": self.tarball_key,
            "offset": self.offset,
            "pack_id": self.pack_id,
        }


def build_catalog(manifests: list[Manifest]) -> list[CatalogEntry]:
    """Flatten an org's manifests into a browsable, sorted file catalog."""
    entries: list[CatalogEntry] = []
    for m in manifests:
        for f in m.files:
            entries.append(
                CatalogEntry(
                    path=f.path, size=f.length, modified=f.modified,
                    retention=m.retention_class.value, legal_hold=m.legal_hold,
                    encrypted=bool(m.encryption_nonce),
                    tarball_key=m.tarball_key, offset=f.offset, pack_id=m.pack_id,
                )
            )
    entries.sort(key=lambda e: e.path)
    return entries


def filter_prefix(entries: list[CatalogEntry], prefix: str) -> list[CatalogEntry]:
    """Browse a 'folder': entries whose path starts with the prefix."""
    if not prefix:
        return entries
    return [e for e in entries if e.path.startswith(prefix)]


def list_folders(entries: list[CatalogEntry], prefix: str = "") -> list[str]:
    """The immediate sub-folder names under a prefix (for tree navigation)."""
    folders: set[str] = set()
    plen = len(prefix)
    for e in entries:
        if not e.path.startswith(prefix):
            continue
        rest = e.path[plen:]
        if "/" in rest:
            folders.add(rest.split("/", 1)[0])
    return sorted(folders)


def find(entries: list[CatalogEntry], path: str) -> CatalogEntry | None:
    for e in entries:
        if e.path == path:
            return e
    return None
