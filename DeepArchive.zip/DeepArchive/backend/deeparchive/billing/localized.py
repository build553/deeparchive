"""Localized pricing: per-country currency + regional cost + PPP adjustment.

Base prices are cost + margin in USD (billing.plans). Localization:
  1. Regional cost: AWS Deep Archive rates differ by region, so cost is computed
     from the country's region rate.
  2. Currency: the price is converted to the country's currency for display/charge.
  3. Purchasing-power adjustment (optional): a per-country multiplier so pricing
     is fair across markets (e.g. India lower than US).

Rates/FX here are static defaults; a deployment refreshes them from a feed.
"""
from __future__ import annotations

from dataclasses import dataclass

from deeparchive.billing.plans import (
    MARGIN_MONTHLY,
    MARGIN_PREPAID_30Y,
    METADATA_OVERHEAD_FRACTION,
    Plan,
)

_GB = 1024 * 1024 * 1024
_MONTH_SECONDS = 30 * 24 * 3600


@dataclass(frozen=True)
class CountryPricing:
    """Localization inputs for a country."""

    country: str
    currency: str                      # ISO 4217, e.g. "USD", "INR", "EUR"
    region_usd_per_gb_month: float     # AWS Deep Archive rate in that region
    usd_to_local_fx: float             # 1 USD -> local currency units
    ppp_multiplier: float = 1.0        # purchasing-power adjustment (<1 = cheaper)


# Per-country pricing table (aligns with the active regions). Static defaults;
# refresh region rates + FX from a live feed in production.
PRICING: dict[str, CountryPricing] = {
    "US": CountryPricing("US", "USD", 0.00099, 1.0, 1.0),
    "IN": CountryPricing("IN", "INR", 0.0010, 83.0, 0.5),    # Mumbai; PPP-lower
    "DE": CountryPricing("DE", "EUR", 0.00108, 0.92, 1.0),   # Frankfurt
    "FR": CountryPricing("FR", "EUR", 0.00108, 0.92, 1.0),
    "IE": CountryPricing("IE", "EUR", 0.00099, 0.92, 1.0),
}


class CountryNotPricedError(Exception):
    """Raised when we have no pricing for a country."""


@dataclass(frozen=True)
class LocalPrice:
    country: str
    currency: str
    amount_minor: int   # in the currency's minor units (cents/paise)


def _base_cost_usd(quota_bytes: int, duration_seconds: float, rate: float) -> float:
    gb = quota_bytes / _GB
    months = duration_seconds / _MONTH_SECONDS
    return gb * rate * months * (1 + METADATA_OVERHEAD_FRACTION)


def _margin_for(plan: Plan) -> float:
    return MARGIN_MONTHLY if plan.billing_period == "monthly" else MARGIN_PREPAID_30Y


def localized_price(plan: Plan, country: str) -> LocalPrice:
    """Compute a plan's price for a country: regional cost -> margin -> PPP -> FX."""
    cp = PRICING.get(country.upper())
    if cp is None:
        raise CountryNotPricedError(f"no pricing for country {country!r}")
    cost_usd = _base_cost_usd(plan.quota_bytes, plan.duration_seconds, cp.region_usd_per_gb_month)
    price_usd = cost_usd * (1 + _margin_for(plan)) * cp.ppp_multiplier
    price_local = price_usd * cp.usd_to_local_fx
    return LocalPrice(
        country=cp.country,
        currency=cp.currency,
        amount_minor=round(price_local * 100),
    )
