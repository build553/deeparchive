"""Usage metering + quota enforcement.

Tracks per-account stored bytes (counts against the prepaid quota) and egress
bytes (the metered cost risk from restores/downloads). Enforces the entitlement:
uploads over quota or after expiry are rejected.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from deeparchive.billing.plans import Entitlement


class QuotaExceededError(Exception):
    """Raised when an upload would exceed the account's quota."""


class NoEntitlementError(Exception):
    """Raised when an account has no active entitlement."""


@dataclass
class Usage:
    stored_bytes: int = 0
    egress_bytes: int = 0


@dataclass
class UsageMeter:
    """Per-account usage + quota checks against entitlements."""

    _usage: dict[str, Usage] = field(default_factory=dict)
    _entitlements: dict[str, Entitlement] = field(default_factory=dict)

    def set_entitlement(self, ent: Entitlement) -> None:
        self._entitlements[ent.account_id] = ent

    def usage(self, account_id: str) -> Usage:
        return self._usage.setdefault(account_id, Usage())

    def _active_entitlement(self, account_id: str, now: float | None = None) -> Entitlement:
        ent = self._entitlements.get(account_id)
        if ent is None or not ent.is_active(now):
            raise NoEntitlementError(f"no active entitlement for {account_id}")
        return ent

    def check_and_record_upload(
        self, account_id: str, size_bytes: int, now: float | None = None
    ) -> None:
        """Reject if over quota / expired; otherwise record the stored bytes."""
        ent = self._active_entitlement(account_id, now)
        usage = self.usage(account_id)
        if usage.stored_bytes + size_bytes > ent.quota_bytes:
            raise QuotaExceededError(
                f"quota exceeded: {usage.stored_bytes + size_bytes} > {ent.quota_bytes}"
            )
        usage.stored_bytes += size_bytes

    def record_egress(self, account_id: str, size_bytes: int) -> None:
        """Meter egress (restore/download) -- the real cost driver."""
        self.usage(account_id).egress_bytes += size_bytes

    def record_delete(self, account_id: str, size_bytes: int) -> None:
        """Free stored bytes back to quota on (hard) delete."""
        usage = self.usage(account_id)
        usage.stored_bytes = max(0, usage.stored_bytes - size_bytes)

    def remaining_quota(self, account_id: str, now: float | None = None) -> int:
        ent = self._active_entitlement(account_id, now)
        return max(0, ent.quota_bytes - self.usage(account_id).stored_bytes)

    def quota_fraction_used(self, account_id: str, now: float | None = None) -> float:
        """Fraction of quota consumed (0.0-1.0+). Raises if no active plan."""
        ent = self._active_entitlement(account_id, now)
        if ent.quota_bytes <= 0:
            return 1.0
        return self.usage(account_id).stored_bytes / ent.quota_bytes
