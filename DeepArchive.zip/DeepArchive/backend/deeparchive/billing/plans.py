"""Billing plans + entitlements.

The model is PREPAID: a customer buys a plan once and receives an Entitlement
(a storage quota + an expiry date). No recurring subscription.

PRICING = cost + margin. Price is DERIVED from the real S3 Glacier Deep Archive
storage rate over the plan's duration, plus a small metadata overhead, times a
margin multiplier. Our profit is the margin -- which we earn by running the
packing/dedup/ops efficiently enough that our true cost stays under the priced
cost. Egress (restores) is metered separately (it's the real variable cost).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum

_GB = 1024 * 1024 * 1024
_MONTH_SECONDS = 30 * 24 * 3600
_YEAR_SECONDS = 365 * 24 * 3600

# --- Cost basis (S3 Glacier Deep Archive, us-east-1) ---
DEEP_ARCHIVE_USD_PER_GB_MONTH = 0.00099
# Metadata/index/request overhead as a fraction of storage cost. Metadata is a
# few small DynamoDB + warm-index entries per pack -- pennies -- so it's a small
# % of storage, NOT a flat per-GB charge (which would dwarf archive cost).
METADATA_OVERHEAD_FRACTION = 0.10  # +10% of storage cost

# Margins by commitment: monthly pays more (70%); prepaid 30yr is discounted (50%)
# to reward the long commitment (and the upfront cash).
MARGIN_MONTHLY = 0.70
MARGIN_PREPAID_30Y = 0.50
# Back-compat alias.
MARGIN = MARGIN_PREPAID_30Y


def price_cents(quota_bytes: int, duration_seconds: float, margin: float = MARGIN) -> int:
    """Derive the price: storage cost * (1 + metadata%) * (1 + margin)."""
    gb = quota_bytes / _GB
    months = duration_seconds / _MONTH_SECONDS
    storage_cost = gb * DEEP_ARCHIVE_USD_PER_GB_MONTH * months
    cost = storage_cost * (1 + METADATA_OVERHEAD_FRACTION)
    return round(cost * (1 + margin) * 100)


class PlanId(str, Enum):
    # Monthly (70% margin, pay-as-you-go, cancel anytime).
    INDIVIDUAL_100_MONTHLY = "individual-100-monthly"
    ORG_PER_TB_MONTHLY = "org-per-tb-monthly"
    # Prepaid 30-year (50% margin, discounted for the long commitment).
    INDIVIDUAL_100_30Y = "individual-100-30y"
    ORG_PER_TB_30Y = "org-per-tb-30y"


@dataclass(frozen=True)
class Plan:
    """A purchasable plan. price_usd_cents is derived from cost + margin."""

    plan_id: PlanId
    quota_bytes: int
    duration_seconds: int
    price_usd_cents: int
    billing_period: str  # "monthly" | "one-time"


def _plan(
    plan_id: PlanId, quota_bytes: int, duration_seconds: int, margin: float, period: str
) -> Plan:
    return Plan(
        plan_id=plan_id,
        quota_bytes=quota_bytes,
        duration_seconds=duration_seconds,
        price_usd_cents=price_cents(quota_bytes, duration_seconds, margin),
        billing_period=period,
    )


# The catalog: monthly (70%) and prepaid-30yr (50%) tiers.
CATALOG: dict[PlanId, Plan] = {
    PlanId.INDIVIDUAL_100_MONTHLY: _plan(
        PlanId.INDIVIDUAL_100_MONTHLY, 100 * _GB, _MONTH_SECONDS,
        MARGIN_MONTHLY, "monthly",
    ),
    PlanId.ORG_PER_TB_MONTHLY: _plan(
        PlanId.ORG_PER_TB_MONTHLY, 1024 * _GB, _MONTH_SECONDS,
        MARGIN_MONTHLY, "monthly",
    ),
    PlanId.INDIVIDUAL_100_30Y: _plan(
        PlanId.INDIVIDUAL_100_30Y, 100 * _GB, 30 * _YEAR_SECONDS,
        MARGIN_PREPAID_30Y, "one-time",
    ),
    PlanId.ORG_PER_TB_30Y: _plan(
        PlanId.ORG_PER_TB_30Y, 1024 * _GB, 30 * _YEAR_SECONDS,
        MARGIN_PREPAID_30Y, "one-time",
    ),
}


@dataclass
class Entitlement:
    """What an account is entitled to after a prepaid purchase."""

    account_id: str
    plan_id: PlanId
    quota_bytes: int
    expires_at: float          # epoch seconds
    purchased_at: float

    def is_active(self, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        return now < self.expires_at

    def to_dict(self) -> dict[str, object]:
        return {
            "account_id": self.account_id,
            "plan_id": self.plan_id.value,
            "quota_bytes": self.quota_bytes,
            "expires_at": self.expires_at,
            "purchased_at": self.purchased_at,
        }


def make_entitlement(
    account_id: str, plan: Plan, units: int = 1, now: float | None = None
) -> Entitlement:
    """Build an entitlement from a plan. `units` scales quota+duration (e.g. TB)."""
    now = time.time() if now is None else now
    return Entitlement(
        account_id=account_id,
        plan_id=plan.plan_id,
        quota_bytes=plan.quota_bytes * units,
        expires_at=now + plan.duration_seconds,
        purchased_at=now,
    )
