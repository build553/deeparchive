"""Billing: prepaid plans, entitlements, usage metering, quota, payments.

Depends on: (stdlib). Payment processor is pluggable (fake for tests, Stripe-ready).
"""
from deeparchive.billing.localized import (
    CountryNotPricedError,
    CountryPricing,
    LocalPrice,
    localized_price,
)
from deeparchive.billing.payments import (
    BillingService,
    Charge,
    FakeProcessor,
    PaymentError,
    PaymentProcessor,
)
from deeparchive.billing.plans import (
    CATALOG,
    Entitlement,
    Plan,
    PlanId,
    make_entitlement,
    price_cents,
)
from deeparchive.billing.stripe_processor import (
    PayMethod,
    RoutingProcessor,
    StripeProcessor,
    WebhookVerificationError,
    method_for_country,
    verify_webhook,
)
from deeparchive.billing.subscription import (
    Subscription,
    SubscriptionService,
    SubStatus,
)
from deeparchive.billing.usage import (
    NoEntitlementError,
    QuotaExceededError,
    Usage,
    UsageMeter,
)

__all__ = [
    "CATALOG",
    "BillingService",
    "Charge",
    "CountryNotPricedError",
    "CountryPricing",
    "Entitlement",
    "FakeProcessor",
    "LocalPrice",
    "NoEntitlementError",
    "PayMethod",
    "PaymentError",
    "PaymentProcessor",
    "Plan",
    "PlanId",
    "QuotaExceededError",
    "RoutingProcessor",
    "StripeProcessor",
    "SubStatus",
    "Subscription",
    "SubscriptionService",
    "Usage",
    "UsageMeter",
    "WebhookVerificationError",
    "make_entitlement",
    "method_for_country",
    "price_cents",
    "localized_price",
    "verify_webhook",
]
