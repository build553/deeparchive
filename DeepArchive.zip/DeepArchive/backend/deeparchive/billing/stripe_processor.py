"""Stripe-backed payments with per-country method routing.

Stripe is the processor everywhere. The PAYMENT METHOD is routed by country to
the cheapest local rail Stripe supports:
    India  -> UPI   (near-free)
    Brazil -> Pix   (near-free)
    else   -> card  (universal fallback)

StripeProcessor imports the `stripe` SDK lazily (deploy-time dep + API key), so
tests use the FakeProcessor. Test mode is free; live mode charges Stripe's fee
only on real payments.
"""
from __future__ import annotations

from enum import Enum

from deeparchive.billing.payments import Charge, PaymentError, PaymentProcessor


class PayMethod(str, Enum):
    CARD = "card"
    UPI = "upi"      # India
    PIX = "pix"      # Brazil


# Country -> cheapest Stripe-supported method.
_METHOD_BY_COUNTRY: dict[str, PayMethod] = {
    "IN": PayMethod.UPI,
    "BR": PayMethod.PIX,
}


def method_for_country(country: str) -> PayMethod:
    """Cheapest payment method for a country (UPI/Pix where available, else card)."""
    return _METHOD_BY_COUNTRY.get(country.upper(), PayMethod.CARD)


class StripeProcessor(PaymentProcessor):
    """Charges via Stripe. Method (card/UPI/Pix) chosen by the caller/router.

    `stripe` SDK imported lazily; configure with your secret key at deploy.
    In test mode this uses Stripe test keys (free).
    """

    def __init__(self, api_key: str, method: PayMethod = PayMethod.CARD):
        self._api_key = api_key
        self._method = method

    def charge(self, account_id: str, amount_cents: int, token: str) -> Charge:
        try:
            import stripe  # noqa: E501
        except ImportError as exc:  # pragma: no cover - only if dep missing
            raise PaymentError("stripe SDK not installed") from exc
        stripe.api_key = self._api_key
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency="usd",
                payment_method=token,
                payment_method_types=[self._method.value],
                confirm=True,
                metadata={"account_id": account_id},
            )
        except Exception as exc:  # noqa: BLE001 - stripe raises many error types
            raise PaymentError(f"stripe charge failed: {exc}") from exc
        return Charge(charge_id=str(intent["id"]), amount_cents=amount_cents)


class RoutingProcessor(PaymentProcessor):
    """Routes a charge to a Stripe processor using the country's cheapest method.

    Stripe everywhere; UPI for India, Pix for Brazil, card elsewhere.
    """

    def __init__(self, api_key: str):
        self._api_key = api_key

    def charge_for_country(
        self, country: str, account_id: str, amount_cents: int, token: str
    ) -> Charge:
        method = method_for_country(country)
        return StripeProcessor(self._api_key, method=method).charge(
            account_id, amount_cents, token
        )

    # PaymentProcessor interface (defaults to card when country is unknown).
    def charge(self, account_id: str, amount_cents: int, token: str) -> Charge:
        return StripeProcessor(self._api_key, method=PayMethod.CARD).charge(
            account_id, amount_cents, token
        )


class WebhookVerificationError(Exception):
    """Raised when a Stripe webhook signature is invalid."""


def verify_webhook(payload: bytes, signature: str, webhook_secret: str) -> dict[str, object]:
    """Verify a Stripe webhook signature and return the parsed event.

    Uses stripe.Webhook.construct_event, which checks the Stripe-Signature header
    against the endpoint's webhook secret (prevents forged webhooks). Raises
    WebhookVerificationError on any failure.
    """
    try:
        import stripe  # noqa: E501
    except ImportError as exc:  # pragma: no cover - only if dep missing
        raise WebhookVerificationError("stripe SDK not installed") from exc
    try:
        event = stripe.Webhook.construct_event(payload, signature, webhook_secret)
    except Exception as exc:  # noqa: BLE001 - stripe raises SignatureVerificationError etc.
        raise WebhookVerificationError(f"invalid webhook signature: {exc}") from exc
    return dict(event)
