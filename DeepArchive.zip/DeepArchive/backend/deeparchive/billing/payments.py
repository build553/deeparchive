"""Payment processing + purchase flow (pluggable).

A PaymentProcessor charges a customer; on success we grant an Entitlement and
register it with the UsageMeter. FakeProcessor is used for tests/dev (no real
charge). A real StripeProcessor implements the same interface at deploy (needs
API keys), so no business logic changes.
"""
from __future__ import annotations

from dataclasses import dataclass

from deeparchive.billing.plans import CATALOG, Entitlement, PlanId, make_entitlement
from deeparchive.billing.usage import UsageMeter


class PaymentError(Exception):
    """Raised when a charge fails."""


@dataclass(frozen=True)
class Charge:
    """Result of a successful charge."""

    charge_id: str
    amount_cents: int


class PaymentProcessor:
    """Charges a customer. One impl per provider (Stripe, etc)."""

    def charge(self, account_id: str, amount_cents: int, token: str) -> Charge:
        raise NotImplementedError


class FakeProcessor(PaymentProcessor):
    """Test/dev processor: succeeds unless token == 'decline'. No real charge."""

    def __init__(self) -> None:
        self.charges: list[Charge] = []
        self._seq = 0

    def charge(self, account_id: str, amount_cents: int, token: str) -> Charge:
        if token == "decline":
            raise PaymentError("card declined")
        self._seq += 1
        ch = Charge(charge_id=f"ch_fake_{self._seq}", amount_cents=amount_cents)
        self.charges.append(ch)
        return ch


@dataclass
class BillingService:
    """Purchase flow: charge -> grant entitlement -> register with the meter."""

    processor: PaymentProcessor
    meter: UsageMeter

    def purchase(
        self,
        account_id: str,
        plan_id: PlanId,
        payment_token: str,
        units: int = 1,
        now: float | None = None,
    ) -> Entitlement:
        plan = CATALOG[plan_id]
        amount = plan.price_usd_cents * units
        self.processor.charge(account_id, amount, payment_token)  # raises on failure
        entitlement = make_entitlement(account_id, plan, units=units, now=now)
        self.meter.set_entitlement(entitlement)
        return entitlement
