"""Recurring subscriptions: monthly auto-renew.

For monthly plans, Stripe (Subscriptions) charges the customer each cycle and
fires invoice webhooks. On each successful cycle we RENEW: extend the account's
entitlement by one period. A failed charge marks the subscription past_due; a
cancel stops future renewals (access lasts until the current period ends).

This module holds the subscription state + renewal logic; the webhook layer
drives it from Stripe events.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum

from deeparchive.billing.plans import CATALOG, PlanId, make_entitlement
from deeparchive.billing.usage import UsageMeter


class SubStatus(str, Enum):
    ACTIVE = "active"
    PAST_DUE = "past_due"     # a renewal charge failed
    CANCELED = "canceled"     # no more renewals (access until period end)


@dataclass
class Subscription:
    account_id: str
    plan_id: PlanId
    status: SubStatus
    current_period_end: float   # epoch seconds
    units: int = 1

    def is_active(self, now: float | None = None) -> bool:
        """Active if within the paid period. Canceled subs keep access until the
        period ends (they paid for it); they just won't renew."""
        now = time.time() if now is None else now
        return now < self.current_period_end


@dataclass
class SubscriptionService:
    """Manages recurring subscriptions and drives entitlement renewals."""

    meter: UsageMeter
    _subs: dict[str, Subscription] = field(default_factory=dict)

    def start(
        self, account_id: str, plan_id: PlanId, units: int = 1, now: float | None = None
    ) -> Subscription:
        """Begin a subscription and grant the first period's entitlement."""
        now = time.time() if now is None else now
        plan = CATALOG[plan_id]
        sub = Subscription(
            account_id=account_id, plan_id=plan_id, status=SubStatus.ACTIVE,
            current_period_end=now + plan.duration_seconds, units=units,
        )
        self._subs[account_id] = sub
        self.meter.set_entitlement(make_entitlement(account_id, plan, units=units, now=now))
        return sub

    def renew(self, account_id: str, now: float | None = None) -> Subscription:
        """On a successful recurring charge: extend one more period."""
        now = time.time() if now is None else now
        sub = self._subs[account_id]
        plan = CATALOG[sub.plan_id]
        # Extend from the later of now / current end (no gaps, no double-credit).
        base = max(now, sub.current_period_end)
        sub.current_period_end = base + plan.duration_seconds
        sub.status = SubStatus.ACTIVE
        # Refresh the entitlement to the new period end.
        self.meter.set_entitlement(make_entitlement(account_id, plan, units=sub.units, now=now))
        return sub

    def mark_past_due(self, account_id: str) -> Subscription:
        """A renewal charge failed -- flag it (dunning); access continues to period end."""
        sub = self._subs[account_id]
        sub.status = SubStatus.PAST_DUE
        return sub

    def cancel(self, account_id: str) -> Subscription:
        """Stop future renewals. Access remains until current_period_end."""
        sub = self._subs[account_id]
        sub.status = SubStatus.CANCELED
        return sub

    def get(self, account_id: str) -> Subscription:
        return self._subs[account_id]
