"""Content-addressable blocks: split a file into fixed-size, hash-keyed chunks.

This is the Dropbox-style model. A file is split into fixed 4 MiB blocks; each
block is identified by the SHA-256 of its bytes (content address). A file then
becomes an ordered list of block hashes (a "block list").

Why this matters for archival:
  - DEDUP: identical blocks (same bytes anywhere -- across files, across versions,
    across customers within a scope) are stored once, keyed by hash.
  - DELTA: re-archiving a changed file only stores the blocks that actually
    changed; unchanged blocks are already present by hash.

This module is pure bytes-in/bytes-out -- NO storage or S3 logic. Callers decide
where blocks live and which are already stored (see the dedup index).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

# 4 MiB, matching Dropbox's block size -- a good balance of dedup granularity vs
# per-block overhead.
BLOCK_SIZE = 4 * 1024 * 1024


@dataclass(frozen=True)
class Block:
    """One content-addressed block: its hash and its bytes."""

    hash: str      # sha256 hex of `data`
    data: bytes

    def __post_init__(self) -> None:
        if len(self.hash) != 64:
            raise ValueError("Block.hash must be 64 hex chars")


def block_hash(data: bytes) -> str:
    """The content address of a block: SHA-256 hex of its bytes."""
    return hashlib.sha256(data).hexdigest()


def split(data: bytes, block_size: int = BLOCK_SIZE) -> list[Block]:
    """Split bytes into content-addressed blocks of at most `block_size`.

    The final block may be shorter. Empty input yields no blocks.
    """
    if block_size <= 0:
        raise ValueError("block_size must be > 0")
    blocks: list[Block] = []
    for start in range(0, len(data), block_size):
        chunk = data[start : start + block_size]
        blocks.append(Block(hash=block_hash(chunk), data=chunk))
    return blocks


def block_list(data: bytes, block_size: int = BLOCK_SIZE) -> list[str]:
    """The ordered list of block hashes for a file (its content fingerprint)."""
    return [b.hash for b in split(data, block_size)]


def reassemble(hashes: list[str], store: dict[str, bytes]) -> bytes:
    """Rebuild a file from its ordered block hashes + a hash->bytes store.

    Raises KeyError if a required block is missing from the store.
    """
    out = bytearray()
    for h in hashes:
        if h not in store:
            raise KeyError(f"missing block {h}")
        out.extend(store[h])
    return bytes(out)
