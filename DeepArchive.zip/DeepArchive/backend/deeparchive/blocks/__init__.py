"""Blocks: content-addressable 4MiB chunking for dedup + delta."""
from deeparchive.blocks.blocks import (
    BLOCK_SIZE,
    Block,
    block_hash,
    block_list,
    reassemble,
    split,
)
from deeparchive.blocks.dedup import BlockIndex, DedupStats

__all__ = [
    "BLOCK_SIZE",
    "Block",
    "BlockIndex",
    "DedupStats",
    "block_hash",
    "block_list",
    "reassemble",
    "split",
]
