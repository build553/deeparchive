"""Block dedup index: which blocks are already stored, and what's new (delta).

Given a file's block hashes, this answers two questions that turn the block model
into real savings:

  DEDUP  -> which of these blocks do we already have? (store them once)
  DELTA  -> which are new? (re-archiving a changed file uploads only new blocks)

The index is just a set of known block hashes plus a refcount (so a block is
only truly droppable when no file references it). It holds NO bytes and NO S3
logic -- callers store the actual block bytes wherever they like (a blocks/
prefix in S3) and consult this index to skip already-stored blocks.

In-memory here; the persistent (DynamoDB-backed) variant mirrors the DdbKeyStore
pattern so both hosts share dedup state.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass


@dataclass
class DedupStats:
    """Result of adding a file's blocks: how much was new vs deduplicated."""

    total_blocks: int
    new_blocks: int
    deduped_blocks: int
    new_bytes: int
    deduped_bytes: int

    @property
    def dedup_ratio(self) -> float:
        """Fraction of blocks that were already stored (0.0-1.0)."""
        if self.total_blocks == 0:
            return 0.0
        return self.deduped_blocks / self.total_blocks


class BlockIndex:
    """Tracks stored block hashes with refcounts for dedup + delta."""

    def __init__(self) -> None:
        self._refcount: dict[str, int] = {}

    def has(self, block_hash: str) -> bool:
        return block_hash in self._refcount

    def which_new(self, hashes: Iterable[str]) -> list[str]:
        """The subset of `hashes` NOT yet stored -- what actually needs uploading.

        De-duplicates within the input too (a block repeated in one file is
        uploaded once).
        """
        new: list[str] = []
        seen: set[str] = set()
        for h in hashes:
            if h in seen:
                continue
            seen.add(h)
            if h not in self._refcount:
                new.append(h)
        return new

    def add_file(self, hashes: list[str], sizes: dict[str, int]) -> DedupStats:
        """Register a file's blocks. Increments refcounts; returns dedup stats.

        `sizes` maps block hash -> byte length (for reporting new vs saved bytes).
        Unknown sizes default to 0.
        """
        total = new = deduped = 0
        new_bytes = deduped_bytes = 0
        for h in hashes:
            total += 1
            size = sizes.get(h, 0)
            if h in self._refcount:
                deduped += 1
                deduped_bytes += size
            else:
                new += 1
                new_bytes += size
            self._refcount[h] = self._refcount.get(h, 0) + 1
        return DedupStats(
            total_blocks=total, new_blocks=new, deduped_blocks=deduped,
            new_bytes=new_bytes, deduped_bytes=deduped_bytes,
        )

    def remove_file(self, hashes: list[str]) -> list[str]:
        """Decrement refcounts for a file's blocks (e.g. on delete/version prune).

        Returns the blocks whose refcount hit zero -- now safe to physically
        delete from block storage.
        """
        droppable: list[str] = []
        for h in hashes:
            if h not in self._refcount:
                continue
            self._refcount[h] -= 1
            if self._refcount[h] <= 0:
                del self._refcount[h]
                droppable.append(h)
        return droppable

    def __len__(self) -> int:
        return len(self._refcount)
