"""Compression: shrink file bytes before they go into a tarball.

Archival data is write-once and rarely read, so spending CPU to compress on the
way in is a clear win -- less stored, less to restore, lower cost. We record the
codec per file so extraction knows how to decompress (and can mix compressed and
stored files in one tarball).

Codec choice:
  - GZIP: always available (Python stdlib), good ratio, portable.
  - STORE: no compression (already-compressed data -- jpg/mp4/zip -- where gzip
    would waste CPU for ~0 gain).

zstd would compress better/faster but needs a third-party dep; gzip keeps the
core dependency-free. The Codec enum makes adding zstd later a one-line change.
"""
from __future__ import annotations

import gzip
from enum import Enum


class Codec(str, Enum):
    """How a file's bytes are stored inside the tarball."""

    STORE = "store"   # raw, no compression
    GZIP = "gzip"     # gzip-compressed


# File extensions whose contents are already compressed -- compressing again
# wastes CPU for negligible gain, so we STORE them as-is.
_ALREADY_COMPRESSED = frozenset({
    "jpg", "jpeg", "png", "gif", "webp", "heic",
    "mp4", "mov", "avi", "mkv", "webm",
    "mp3", "aac", "flac", "ogg",
    "zip", "gz", "bz2", "xz", "7z", "rar", "zst",
    "pdf",
})


def choose_codec(path: str, size: int) -> Codec:
    """Pick a codec by file type + size.

    Already-compressed formats and tiny files (< 512 B, where gzip's header
    overhead can make output larger) are STOREd; everything else is GZIPped.
    """
    if size < 512:
        return Codec.STORE
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    if ext in _ALREADY_COMPRESSED:
        return Codec.STORE
    return Codec.GZIP


def compress(data: bytes, codec: Codec) -> bytes:
    """Compress bytes with the given codec (mtime=0 for reproducible output)."""
    if codec is Codec.STORE:
        return data
    if codec is Codec.GZIP:
        return gzip.compress(data, compresslevel=6, mtime=0)
    raise ValueError(f"unknown codec: {codec}")


def decompress(data: bytes, codec: Codec) -> bytes:
    """Reverse compress()."""
    if codec is Codec.STORE:
        return data
    if codec is Codec.GZIP:
        return gzip.decompress(data)
    raise ValueError(f"unknown codec: {codec}")
