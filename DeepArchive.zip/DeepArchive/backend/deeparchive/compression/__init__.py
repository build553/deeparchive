"""Compression: per-file codec (STORE/GZIP) for shrinking archived data."""
from deeparchive.compression.compression import (
    Codec,
    choose_codec,
    compress,
    decompress,
)

__all__ = ["Codec", "choose_codec", "compress", "decompress"]
