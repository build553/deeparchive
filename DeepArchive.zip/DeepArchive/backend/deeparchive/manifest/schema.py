"""Manifest schema: maps files to their location inside a tarball.

Types are designed so illegal states are hard to express:
- RetentionClass is an Enum, not a free string.
- FileEntry cannot exist without path/offset/length/sha256.
- Manifest cannot exist without a tarball key + retention class, and validates
  its invariants on construction (one retention class per manifest).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from deeparchive import config

_SHA256_HEX_LEN = 64


class RetentionClass(str, Enum):
    """Allowed retention classes. One per tarball (drives packing + deletion)."""

    ONE_YEAR = "1y"
    THREE_YEAR = "3y"
    SEVEN_YEAR = "7y"
    INDEFINITE = "indefinite"


@dataclass(frozen=True)
class FileEntry:
    """One file's location inside a tarball. Immutable once built."""

    path: str
    offset: int
    length: int          # bytes as STORED in the tarball (compressed size)
    sha256: str          # sha256 of the ORIGINAL (uncompressed) file
    modified: str  # ISO-8601
    tags: dict[str, str] = field(default_factory=dict)
    codec: str = "store"      # how the bytes are stored: "store" | "gzip"
    original_size: int = -1   # uncompressed size; -1 means "same as length"

    def __post_init__(self) -> None:
        if not self.path:
            raise ValueError("FileEntry.path must be non-empty")
        if self.offset < 0:
            raise ValueError("FileEntry.offset must be >= 0")
        if self.length < 0:
            raise ValueError("FileEntry.length must be >= 0")
        if len(self.sha256) != _SHA256_HEX_LEN:
            raise ValueError("FileEntry.sha256 must be 64 hex chars")

    def to_dict(self) -> dict[str, object]:
        return {
            "path": self.path,
            "offset": self.offset,
            "length": self.length,
            "sha256": self.sha256,
            "modified": self.modified,
            "tags": dict(self.tags),
            "codec": self.codec,
            "original_size": self.original_size,
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> FileEntry:
        raw_tags = d.get("tags") or {}
        tags = {str(k): str(v) for k, v in raw_tags.items()}
        return FileEntry(
            path=str(d["path"]),
            offset=int(d["offset"]),
            length=int(d["length"]),
            sha256=str(d["sha256"]),
            modified=str(d["modified"]),
            tags=tags,
            codec=str(d.get("codec", "store")),
            original_size=int(d.get("original_size", -1)),
        )


@dataclass(frozen=True)
class Manifest:
    """A single tarball's manifest. Stored warm in db/. Immutable once built."""

    pack_id: str
    org_id: str
    created_at: str  # ISO-8601
    tarball_key: str
    tarball_sha256: str
    tarball_bytes: int
    retention_class: RetentionClass
    legal_hold: bool
    files: list[FileEntry]
    manifest_version: str = config.MANIFEST_VERSION
    encryption_nonce: str = ""  # hex GCM nonce; "" means the tarball is unencrypted

    def __post_init__(self) -> None:
        if not self.pack_id:
            raise ValueError("Manifest.pack_id must be non-empty")
        if not self.tarball_key:
            raise ValueError("Manifest.tarball_key must be non-empty")
        if len(self.tarball_sha256) != _SHA256_HEX_LEN:
            raise ValueError("Manifest.tarball_sha256 must be 64 hex chars")
        if self.tarball_bytes < 0:
            raise ValueError("Manifest.tarball_bytes must be >= 0")
        if not self.files:
            raise ValueError("Manifest must contain at least one file")

    def to_json(self) -> str:
        payload: dict[str, object] = {
            "manifest_version": self.manifest_version,
            "pack_id": self.pack_id,
            "org_id": self.org_id,
            "created_at": self.created_at,
            "tarball_key": self.tarball_key,
            "tarball_sha256": self.tarball_sha256,
            "tarball_bytes": self.tarball_bytes,
            "retention_class": self.retention_class.value,
            "legal_hold": self.legal_hold,
            "files": [f.to_dict() for f in self.files],
            "encryption_nonce": self.encryption_nonce,
        }
        return json.dumps(payload, indent=2, sort_keys=True)

    @staticmethod
    def from_json(text: str) -> Manifest:
        d: dict[str, Any] = json.loads(text)
        return Manifest(
            manifest_version=str(d.get("manifest_version", config.MANIFEST_VERSION)),
            pack_id=str(d["pack_id"]),
            org_id=str(d["org_id"]),
            created_at=str(d["created_at"]),
            tarball_key=str(d["tarball_key"]),
            tarball_sha256=str(d["tarball_sha256"]),
            tarball_bytes=int(d["tarball_bytes"]),
            retention_class=RetentionClass(d["retention_class"]),
            legal_hold=bool(d["legal_hold"]),
            files=[FileEntry.from_dict(f) for f in d["files"]],
            encryption_nonce=str(d.get("encryption_nonce", "")),
        )
