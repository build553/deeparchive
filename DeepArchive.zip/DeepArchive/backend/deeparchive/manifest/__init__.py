"""Manifest: the schema that maps files to their location inside a tarball.

Single responsibility: define + (de)serialize the manifest. One manifest per
tarball. Stored warm in db/. No S3, no packing logic here.
"""
from deeparchive.manifest.schema import FileEntry, Manifest, RetentionClass

__all__ = ["FileEntry", "Manifest", "RetentionClass"]
