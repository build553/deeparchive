"""Restore: the 48h retrieval state machine.

Flow:
    request_restore()  -> starts a Bulk Glacier restore, returns a RestoreJob (RESTORING)
    check_restore()    -> polls S3; flips RESTORING -> READY when the copy is available
    download_verify()  -> downloads the restored tarball and verifies its sha256
                          against the manifest (integrity guarantee)

State machine (illegal transitions are not representable):
    RESTORING -> READY -> (download)      happy path
    RESTORING -> FAILED                    on error
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, replace
from enum import Enum

from deeparchive.crypto import decrypt
from deeparchive.manifest import Manifest
from deeparchive.storage import Storage

_READ_CHUNK = 1024 * 1024


class RestoreState(str, Enum):
    RESTORING = "RESTORING"
    READY = "READY"
    FAILED = "FAILED"


@dataclass(frozen=True)
class RestoreJob:
    """Immutable snapshot of a restore's progress. Transitions produce new jobs."""

    tarball_key: str
    state: RestoreState


def request_restore(storage: Storage, tarball_key: str) -> RestoreJob:
    """Start a Bulk restore. Returns a job in RESTORING state."""
    storage.start_restore(tarball_key)
    return RestoreJob(tarball_key=tarball_key, state=RestoreState.RESTORING)


def check_restore(storage: Storage, job: RestoreJob) -> RestoreJob:
    """Poll S3. Returns a new job: READY if available, else unchanged (RESTORING)."""
    if job.state is not RestoreState.RESTORING:
        return job
    if storage.restore_ready(job.tarball_key):
        return replace(job, state=RestoreState.READY)
    return job


class RestoreNotReadyError(Exception):
    """Raised when download is attempted before the job is READY."""


class IntegrityError(Exception):
    """Raised when a downloaded tarball's sha256 does not match its manifest."""


def download_verify(
    storage: Storage, job: RestoreJob, manifest: Manifest, dest_path: str
) -> None:
    """Download the restored tarball, decrypt if needed, and verify sha256.

    If the manifest carries an encryption nonce, the downloaded bytes are
    ciphertext: decrypt with the customer's key before verifying the plaintext
    sha256 (which the manifest records for the *unencrypted* tarball).
    """
    if job.state is not RestoreState.READY:
        raise RestoreNotReadyError(f"job for {job.tarball_key} is {job.state.value}")

    storage.download(job.tarball_key, dest_path)

    if manifest.encryption_nonce:
        key = storage.customer_key(manifest.org_id)
        with open(dest_path, "rb") as f:
            plaintext = decrypt(f.read(), key, manifest.encryption_nonce)
        with open(dest_path, "wb") as f:
            f.write(plaintext)

    h = hashlib.sha256()
    with open(dest_path, "rb") as f:
        while chunk := f.read(_READ_CHUNK):
            h.update(chunk)
    actual = h.hexdigest()
    if actual != manifest.tarball_sha256:
        raise IntegrityError(
            f"sha256 mismatch for {job.tarball_key}: "
            f"expected {manifest.tarball_sha256}, got {actual}"
        )
