"""Restore orchestration: persistent, trackable restore jobs.

Adapts the AWS glacier-restore pattern (persist jobs, advance lifecycle, redrive
failures) to our stack. The in-memory RestoreJob in deeparchive.restore is the
per-request state; this module makes jobs DURABLE and OPERABLE across the 48h
window and process restarts.

Lifecycle:  PENDING -> RESTORING -> READY -> (downloaded)
            RESTORING -> FAILED -> (redrive) -> PENDING
            READY -> (availability expires) -> EXPIRED
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class JobStatus(str, Enum):
    PENDING = "PENDING"        # created, restore not yet requested
    RESTORING = "RESTORING"    # restore requested, waiting (up to 48h)
    READY = "READY"            # restored copy available to download
    FAILED = "FAILED"          # restore request failed; can be redriven
    EXPIRED = "EXPIRED"        # restored copy's availability window lapsed


@dataclass
class RestoreRecord:
    """A durable restore job record."""

    job_id: str
    org_id: str
    tarball_key: str
    status: JobStatus
    created_at: float
    updated_at: float
    attempts: int = 0
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> RestoreRecord:
        return RestoreRecord(
            job_id=str(d["job_id"]),
            org_id=str(d["org_id"]),
            tarball_key=str(d["tarball_key"]),
            status=JobStatus(d["status"]),
            created_at=float(d["created_at"]),
            updated_at=float(d["updated_at"]),
            attempts=int(d["attempts"]),
            error=str(d.get("error", "")),
        )


class JobStore:
    """Persistence for restore records. Swap for DynamoDB in prod."""

    def put(self, record: RestoreRecord) -> None:
        raise NotImplementedError

    def get(self, job_id: str) -> RestoreRecord:
        raise NotImplementedError

    def list_by_status(self, status: JobStatus) -> list[RestoreRecord]:
        raise NotImplementedError


class LocalJobStore(JobStore):
    """Restore records in a local JSON file. Simple; DynamoDB-swappable later."""

    def __init__(self, path: str):
        self._path = path
        self._records: dict[str, dict[str, object]] = {}
        if os.path.exists(path):
            with open(path) as f:
                self._records = json.load(f)

    def put(self, record: RestoreRecord) -> None:
        self._records[record.job_id] = record.to_dict()
        self._flush()

    def get(self, job_id: str) -> RestoreRecord:
        if job_id not in self._records:
            raise KeyError(f"no restore job {job_id!r}")
        return RestoreRecord.from_dict(self._records[job_id])

    def list_by_status(self, status: JobStatus) -> list[RestoreRecord]:
        return [
            RestoreRecord.from_dict(r)
            for r in self._records.values()
            if r["status"] == status.value
        ]

    def _flush(self) -> None:
        with open(self._path, "w") as f:
            json.dump(self._records, f)


def _now() -> float:
    return time.time()


@dataclass
class Orchestrator:
    """Drives restore jobs through their lifecycle over a JobStore + Storage."""

    store: JobStore
    storage: object  # a deeparchive.storage.Storage (kept loose to avoid a cycle)
    max_attempts: int = 3
    _counter: int = field(default=0, repr=False)

    def create(self, org_id: str, tarball_key: str) -> RestoreRecord:
        """Register a new restore job and kick off the Glacier restore."""
        self._counter += 1
        job_id = f"rst_{int(_now() * 1000)}_{self._counter}"
        now = _now()
        record = RestoreRecord(
            job_id=job_id,
            org_id=org_id,
            tarball_key=tarball_key,
            status=JobStatus.PENDING,
            created_at=now,
            updated_at=now,
        )
        self.store.put(record)
        return self._request(record)

    def _request(self, record: RestoreRecord) -> RestoreRecord:
        """Issue the Glacier restore; move PENDING -> RESTORING (or FAILED)."""
        record.attempts += 1
        try:
            self.storage.start_restore(record.tarball_key)  # type: ignore[attr-defined]
            record.status = JobStatus.RESTORING
            record.error = ""
        except Exception as exc:  # noqa: BLE001
            record.status = JobStatus.FAILED
            record.error = str(exc)
        record.updated_at = _now()
        self.store.put(record)
        return record

    def advance(self, job_id: str) -> RestoreRecord:
        """Poll a RESTORING job; flip to READY once the copy is available."""
        record = self.store.get(job_id)
        if record.status is not JobStatus.RESTORING:
            return record
        if self.storage.restore_ready(record.tarball_key):  # type: ignore[attr-defined]
            record.status = JobStatus.READY
            record.updated_at = _now()
            self.store.put(record)
        return record

    def redrive(self, job_id: str) -> RestoreRecord:
        """Retry a FAILED job, up to max_attempts."""
        record = self.store.get(job_id)
        if record.status is not JobStatus.FAILED:
            return record
        if record.attempts >= self.max_attempts:
            return record
        record.status = JobStatus.PENDING
        return self._request(record)

    def redrive_all_failed(self) -> list[RestoreRecord]:
        """Redrive every FAILED job under the attempt cap (batch operation)."""
        return [self.redrive(r.job_id) for r in self.store.list_by_status(JobStatus.FAILED)]
