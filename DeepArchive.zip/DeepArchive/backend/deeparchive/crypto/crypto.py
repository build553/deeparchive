"""Client-side encryption: one AES-256-GCM key per customer (org).

Simple and free (no KMS). Each org has a 256-bit key stored in a pluggable
KeyStore. Tarballs are encrypted with the org's key + a fresh random nonce
before upload, and decrypted after restore. AES-GCM is authenticated, so it also
detects tampering.

Honest tradeoff: this is NOT zero-knowledge -- whoever can read the KeyStore can
read the keys. Protect the key store (strict file perms now; a secrets manager
or encrypted DB later). Keys never live in code, git, or beside the data.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_KEY_BYTES = 32  # 256-bit
_NONCE_BYTES = 12  # standard GCM nonce


@dataclass(frozen=True)
class Encrypted:
    """Ciphertext plus the nonce needed to decrypt (nonce is not secret)."""

    ciphertext: bytes
    nonce: str  # hex


def encrypt(plaintext: bytes, key: bytes) -> Encrypted:
    if len(key) != _KEY_BYTES:
        raise ValueError("key must be 32 bytes (256-bit)")
    nonce = os.urandom(_NONCE_BYTES)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)
    return Encrypted(ciphertext=ciphertext, nonce=nonce.hex())


def decrypt(ciphertext: bytes, key: bytes, nonce_hex: str) -> bytes:
    if len(key) != _KEY_BYTES:
        raise ValueError("key must be 32 bytes (256-bit)")
    nonce = bytes.fromhex(nonce_hex)
    # Raises cryptography.exceptions.InvalidTag on tamper/wrong key.
    return AESGCM(key).decrypt(nonce, ciphertext, None)


class KeyStore:
    """Maps org_id -> 256-bit key. One key per customer (1:1)."""

    def get_or_create_key(self, org_id: str) -> bytes:
        raise NotImplementedError

    def get_key(self, org_id: str) -> bytes:
        raise NotImplementedError


class LocalKeyStore(KeyStore):
    """Keys in a local JSON file (hex) with strict permissions. Simple + free.

    Swap for a DB/secrets-backed store later without touching crypto code.
    """

    def __init__(self, path: str):
        self._path = path
        self._keys: dict[str, str] = {}
        if os.path.exists(path):
            with open(path) as f:
                self._keys = json.load(f)

    def get_or_create_key(self, org_id: str) -> bytes:
        if org_id not in self._keys:
            self._keys[org_id] = os.urandom(_KEY_BYTES).hex()
            self._flush()
        return bytes.fromhex(self._keys[org_id])

    def get_key(self, org_id: str) -> bytes:
        if org_id not in self._keys:
            raise KeyError(f"no key for org {org_id!r}")
        return bytes.fromhex(self._keys[org_id])

    def _flush(self) -> None:
        # Write then lock down permissions (owner read/write only).
        with open(self._path, "w") as f:
            json.dump(self._keys, f)
        os.chmod(self._path, 0o600)


class SsmKeyStore(KeyStore):
    """Keys in AWS SSM Parameter Store as SecureString params. Free + encrypted.

    Standard-tier SecureString parameters are free and encrypted at rest via the
    free AWS-managed KMS key, IAM-controlled and audited. One param per customer:
    <prefix>/<org_id>. No per-key monthly charge (unlike KMS CMKs).
    """

    def __init__(self, region: str, prefix: str = "/deeparchive/keys", ssm: object = None):
        self._prefix = prefix.rstrip("/")
        if ssm is None:
            import boto3

            ssm = boto3.client("ssm", region_name=region)
        self._ssm = ssm

    def _name(self, org_id: str) -> str:
        return f"{self._prefix}/{org_id}"

    def get_or_create_key(self, org_id: str) -> bytes:
        try:
            return self.get_key(org_id)
        except KeyError:
            key = os.urandom(_KEY_BYTES)
            self._ssm.put_parameter(  # type: ignore[attr-defined]
                Name=self._name(org_id),
                Value=key.hex(),
                Type="SecureString",
                Overwrite=False,
            )
            return key

    def get_key(self, org_id: str) -> bytes:
        try:
            resp = self._ssm.get_parameter(  # type: ignore[attr-defined]
                Name=self._name(org_id), WithDecryption=True
            )
        except Exception as exc:  # noqa: BLE001
            raise KeyError(f"no key for org {org_id!r}") from exc
        return bytes.fromhex(resp["Parameter"]["Value"])
