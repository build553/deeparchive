"""Client-side encryption: one AES-256-GCM key per customer.

Simple, free (no KMS). Depends on: cryptography. No S3 here.
"""
from deeparchive.crypto.crypto import (
    Encrypted,
    KeyStore,
    LocalKeyStore,
    SsmKeyStore,
    decrypt,
    encrypt,
)

__all__ = [
    "Encrypted",
    "KeyStore",
    "LocalKeyStore",
    "SsmKeyStore",
    "decrypt",
    "encrypt",
]
