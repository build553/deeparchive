"""Staging / threshold layer: archive only when a customer qualifies.

Files trickle in. We do NOT pack a tiny tarball per file (per-object cost). We
buffer each customer's files in a StagingBuffer and archive only when they
QUALIFY: total staged bytes >= threshold (default ~256MB) OR the oldest staged
file is older than a max age (default N days). This is the "archive when they hit
the range" behavior.

Staging holds lightweight records (path, size, staged_at, retention). The actual
bytes live in warm staging storage until qualified; here we model the decision
+ hand-off to the packer.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from deeparchive import config
from deeparchive.manifest import RetentionClass

_DEFAULT_MAX_AGE_SECONDS = 7 * 24 * 3600  # 7 days


@dataclass(frozen=True)
class StagedFile:
    """A file waiting in staging (bytes stored warm elsewhere; this is metadata)."""

    local_path: str
    archive_path: str
    size: int
    retention: RetentionClass
    staged_at: float
    legal_hold: bool = False


@dataclass
class StagingBuffer:
    """Per-customer staging buffer with a qualify-for-archive rule."""

    org_id: str
    threshold_bytes: int = config.PACK_SIZE_BYTES
    max_age_seconds: float = _DEFAULT_MAX_AGE_SECONDS
    files: list[StagedFile] = field(default_factory=list)

    def add(self, staged: StagedFile) -> None:
        self.files.append(staged)

    def total_bytes(self) -> int:
        return sum(f.size for f in self.files)

    def oldest_age(self, now: float | None = None) -> float:
        if not self.files:
            return 0.0
        now = time.time() if now is None else now
        return now - min(f.staged_at for f in self.files)

    def qualifies(self, now: float | None = None) -> bool:
        """True when staged data should be packed + archived.

        Qualify on EITHER: enough bytes (>= threshold) OR aged past max age.
        """
        if not self.files:
            return False
        if self.total_bytes() >= self.threshold_bytes:
            return True
        return self.oldest_age(now) >= self.max_age_seconds

    def drain(self) -> list[StagedFile]:
        """Return staged files and clear the buffer (called once qualified)."""
        drained = list(self.files)
        self.files.clear()
        return drained
