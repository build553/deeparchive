"""Staging: per-customer buffer that archives only when qualified.

Qualify = total bytes >= threshold OR oldest file aged past max age.
Depends on: config, manifest. No S3 here.
"""
from deeparchive.staging.staging import StagedFile, StagingBuffer

__all__ = ["StagedFile", "StagingBuffer"]
