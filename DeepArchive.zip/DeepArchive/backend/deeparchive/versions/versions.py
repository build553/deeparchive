"""File versioning / history from manifest generations.

A customer who archives the same path more than once (a nightly backup, an edited
document) produces multiple manifests, each with its own `created_at` and its own
FileEntry for that path. The *history* of a file is simply all those entries,
newest first. No extra storage model is needed -- versions fall out of the
manifests we already keep warm in db/.

This module is pure: callers feed it manifests (loaded from db/); it groups and
orders them. Restoring a specific version = locate that version's tarball + entry
and thaw/extract it (same path as any single-file retrieval).
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from deeparchive.manifest import FileEntry, Manifest


@dataclass(frozen=True)
class FileVersion:
    """One historical version of a file: when, where, and how big."""

    path: str
    created_at: str        # ISO-8601 of the manifest that captured this version
    pack_id: str
    tarball_key: str
    sha256: str            # sha of the original file bytes (identifies content)
    size: int              # stored (possibly compressed) size in the tarball
    offset: int
    entry: FileEntry       # the full entry (codec, original_size, etc.)


def _version_of(m: Manifest, e: FileEntry) -> FileVersion:
    return FileVersion(
        path=e.path,
        created_at=m.created_at,
        pack_id=m.pack_id,
        tarball_key=m.tarball_key,
        sha256=e.sha256,
        size=e.length,
        offset=e.offset,
        entry=e,
    )


def list_versions(manifests: Iterable[Manifest], path: str) -> list[FileVersion]:
    """All versions of `path`, newest first (by manifest created_at).

    Consecutive identical-content versions (same sha256) are kept -- the history
    shows every capture; callers can collapse duplicates if they wish.
    """
    versions = [
        _version_of(m, e)
        for m in manifests
        for e in m.files
        if e.path == path
    ]
    versions.sort(key=lambda v: v.created_at, reverse=True)
    return versions


def latest_version(manifests: Iterable[Manifest], path: str) -> FileVersion | None:
    """The most recent version of `path`, or None if it was never archived."""
    versions = list_versions(manifests, path)
    return versions[0] if versions else None


def version_at(
    manifests: Iterable[Manifest], path: str, created_at: str
) -> FileVersion | None:
    """The version of `path` captured at a specific manifest timestamp."""
    for v in list_versions(manifests, path):
        if v.created_at == created_at:
            return v
    return None


def version_count(manifests: Iterable[Manifest], path: str) -> int:
    """How many historical versions exist for `path`."""
    return len(list_versions(manifests, path))
