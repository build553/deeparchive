# Backend structure

Python package `deeparchive/` (~7,000 lines). The modules are flat on disk (so
Python imports like `deeparchive.storage` keep working), but they group into
these logical areas:

```
deeparchive/
│
├── ENGINE  (the core archival model — how data is stored/retrieved)
│   ├── manifest/       schema: maps each file -> tarball + offset + sha256
│   ├── packer/         packs many files into ~256 MB tarballs
│   ├── storage/        region-aware S3 access (the only boto3 module)
│   ├── restore/        48h Glacier restore state machine + orchestrator
│   ├── crypto/         per-customer AES-256-GCM encryption
│   ├── index/          incremental backup + resume (skip already-archived)
│   ├── catalog/        flatten manifests -> browsable file listing
│   └── regions.py      strict data-residency (serve US/IN/EU only)
│
├── DATA FEATURES  (Dropbox-parity, library-level)
│   ├── compression/    per-file gzip/store codec
│   ├── blocks/         4 MiB content-addressable blocks + dedup/delta index
│   └── versions/       file history from manifest generations
│
├── ACCOUNTS  (identity & access)
│   └── accounts/       accounts, orgs, roles, SCIM, social login, OTP,
│                       restore-approval workflow
│
├── BILLING  (money)
│   └── billing/        plans, localized pricing, usage/quota, Stripe,
│                       subscriptions, payments
│
├── PLATFORM  (cross-cutting)
│   ├── persistence/    DynamoDB-backed durable stores (shared across hosts)
│   ├── audit/          append-only S3 JSONL audit log
│   ├── backup/         S3 versioning + cross-region replication config
│   ├── notify/         SES email / SNS SMS notifications
│   ├── staging/        upload staging buffer
│   ├── observability.py  structured JSON logs + metrics
│   └── config.py       all settings (bucket, prefixes, sizes, SLA)
│
├── SERVICES  (the running API — FastAPI microservices)
│   └── services/
│       ├── gateway/       :8000  public entry, path-routes to the others
│       ├── identity/      :8001  accounts, keys, SCIM, /internal/validate
│       ├── billing_svc/   :8002  plans, quota, webhooks
│       ├── ingest_svc/    :8003  upload-url, manifest register
│       ├── restore_svc/   :8004  restore request/status/download
│       ├── metadata_svc/  :8005  catalog, folders, single-file get
│       ├── api/           shared: auth, wiring, routers, rate limit
│       ├── internal_client.py  local-first failover between services
│       ├── prod_wiring.py      dependency injection for ASGI entrypoints
│       ├── topology.py         service ports
│       └── cli/           the `deeparchive` CLI entrypoint
│
└── sdk/                Python client SDK (boto3-style) for customers

deploy/tooling (outside the package):
├── cdk/                AWS deployment (CDK-Python): ALB + 2-host ASG + S3 + DDB
├── scripts/            check.sh (lint+types+tests), build.sh, bypass_test.py
├── tests/              65 files, 333 tests
├── server/             (legacy/placeholder)
├── docs/               API contract + design notes
├── pyproject.toml      package + dependencies
└── AGENTS.md           coding methodology (Mantle model)
```

## Request flow (live)

```
client (web/cli/app)
   -> ALB  (public)
   -> gateway :8000   (path-routes by URL)
   -> identity/billing/ingest/restore/metadata
   -> DynamoDB (shared state)  +  S3 (deep-archive-lab bucket)
```

## Run / test the backend

```
cd backend
python -m venv .venv && source .venv/bin/activate && pip install -e .
bash scripts/check.sh          # ruff + mypy(strict) + pytest  (333 tests)
python scripts/bypass_test.py  # exercise all services in-process, no AWS
```
