# DeepArchive — Design Journal & Conversation Summary

This captures the full design conversation, decisions, and where we stopped, so
work can resume cleanly. (See NOTES.md for the terse live status.)

---

## The idea

Ultra-low-cost long-term archival storage on S3 Glacier Deep Archive. Store data
for ~30 years at a fraction of consumer cloud prices (Google/Amazon/Apple/OneDrive
~$20-36/yr for 100GB; our raw Deep Archive storage ~$1.19/yr). Win by staying
cold: 48h retrieval, rare restores, packing to kill per-object costs.

### Honest market conclusion (reached together)
- Mass consumer product vs Google Photos / free tiers (Jio 50GB): **unlikely to win.**
  Retrieval delay + free tiers + trust barrier.
- Real market: **data hoarders, "permanent vault" positioning, and B2B/enterprise
  cold archival** (banks storing statements, compliance retention).
- Egress ($0.09/GB out) is the real cost risk, NOT storage. Design so restore is rare.
- Bigger vision ("HuggingFace for Amazon") needs WARM storage — different product;
  this cold-archive work is a foundational skill-build + a real B2B tool.

---

## Locked decisions

| Decision | Choice |
|---|---|
| Storage tier | S3 Glacier Deep Archive |
| Pack size | ~256 MB tarballs (packing is mandatory — per-object cost/overhead) |
| Retrieval SLA | within 48h (Bulk tier, cheapest) |
| Delete model | soft (recoverable within SLA) + explicit hard delete |
| Language | Python (Go only later for the desktop FUSE mount if needed) |
| Methodology | Mantle model: small modules, simple code, strict feedback loop, |
|              | make illegal states hard, examples > rules, human owns every line |
| Feedback loop | `bash scripts/check.sh` = ruff + mypy(strict) + pytest, ALL GREEN |
| Region model | Strict residency — serve a country only if in-country region. |
|               | Active: US (us-east-1), IN (ap-south-1), EU (DE/FR/IE). |
| Encryption | Per-customer AES-256-GCM, ONE key per customer (1:1), no KMS |
| Key storage | LocalKeyStore (dev, free) / SsmKeyStore (prod, free SecureString) |
| Bucket (lab) | deep-archive-lab (env DEEPARCHIVE_BUCKET; us-east-1), public access blocked, |
|              | lifecycle data/->Deep Archive, db/+reports/ stay Standard |

---

## Architecture: SDK-packs-client-side, thin server

Company devs call an SDK per-file (`client.put(file)`); the SDK packs locally into
256MB tarballs grouped by retention class, then makes few large calls to the server.
Big tarballs upload presigned direct-to-S3 (bypass our compute). Warm manifest in
db/ maps file -> tarball + offset + length + sha256 (enables single-file retrieval
without unpacking; the reason 256MB packs work for tiny-file customers like banks).

Rule: one retention/legal-hold class per tarball (clean deletion + compliance).

---

## What's BUILT (48 tests green, all committed)

Core library (deeparchive/):
- config.py            settings (bucket, prefixes, 256MB, 48h/Bulk, multipart, retries)
- regions.py           country->region registry, strict residency
- manifest/            RetentionClass enum, FileEntry, Manifest (+ encryption_nonce), JSON
- packer/              pack files by retention -> tarball + manifest + sha256 + offsets
- index/               ArchiveIndex (incremental + resume; borrowed from serac)
- storage/             region-aware S3 (only boto3 module); multipart upload;
                       adaptive retries + transient/permanent error taxonomy;
                       per-customer encryption on upload
- crypto/              AES-256-GCM; LocalKeyStore + SsmKeyStore (one key per customer)
- restore/             48h state machine + download/decrypt/verify
- restore/orchestrator persistent RestoreRecord + LocalJobStore + Orchestrator
                       (create/advance/redrive, from aws-glacier-restore)

Services (deeparchive/services/):
- cli/                 deeparchive pack/upload/restore/status (console script)
- api/                 FastAPI /v1: health, regions, POST restore, GET restore/{key}
- api/auth.py          hashed API keys, Principal(org_id), org isolation (401/403)

Verified once against REAL AWS (scripts/first_upload.py) — store path works live.

### The 6 hardening features (all done)
1. Multipart upload  2. Incremental+resume  3. Error handling+retries
4. API auth+org isolation  5. Per-customer encryption  6. Restore orchestration

---

## What's LEFT (resume here)

### NEXT UP: Accounts / registration (in active discussion when we paused)
Design agreed, NOT yet built:
- Registration via email OR mobile (OTP / passwordless — user leaning this way,
  final confirm pending).
- On register: generate internal opaque `account_id` (the spine). It maps to:
  encryption key (crypto KeyStore), API key(s) (auth), region (residency),
  storage prefix data/<account_id>/, profile.
- account_id REPLACES the ad-hoc org_id we pass around today.
- Account has a `type`: INDIVIDUAL or ENTERPRISE.
  - INDIVIDUAL: self-service OTP; account = one person.
  - ENTERPRISE: admin-provisioned org; account = org with MANY members;
    automated jobs (e.g. HDFC batch) use the ORG API KEY (already built);
    human employees log in via SSO (SAML/OIDC) — the big, LATER piece.
- Build plan: accounts/ module (Account, AccountStore local+DynamoDB-swappable,
  register()/verify() wiring account_id -> keys+region), pluggable CodeSender
  (fake for tests/offline; SES email + SNS SMS for prod — SMS is the one real
  recurring cost + needs rate limiting to prevent abuse). APIs:
  POST /v1/accounts/register, POST /v1/accounts/verify, GET /v1/accounts/me.
  Enterprise = same machinery + type flag + members list; SSO stubbed for later.
- OPEN QUESTION when we resume: confirm passwordless OTP (recommended) vs password.

### Other remaining work
- Staging/threshold layer ("archive when they qualify"): buffer per-customer,
  pack only when >=256MB OR aged N days. User raised this; NOT built. pack()
  currently packs immediately.
- API upload + file-lookup endpoints (POST /v1/packs presigned, GET /v1/files).
- SDK (client.put()/flush()) for customers.
- Observability: structured logging + metrics (absent).
- Live end-to-end test: real >128KB object through the actual 48h restore + decrypt.
- Other gateways: mobile app, desktop FUSE mount (Go, single binary), website.
- GitHub polish before publishing: add LICENSE (user to pick — MIT?), remove
  account id from scripts/first_upload.py, add GitHub Actions CI running check.sh.
  Also decide commit author email for a public repo.

---

## Research assets
GitHub repos cloned/read in ~/archive-research/ (NOT in this package):
serac (packing + SHA-index = incremental), S3mediaArchival (self-hosted Deep
Archive web app + restore flow), zimly (Android S3 backup), glacier-backup-manager
(web UI + scheduling), aws-glacier-restore (restore orchestration), restic,
ChunkGate (dedup), huskhoard (cold tiering), ogive (per-file encryption).
Borrowed: serac (incremental), aws-glacier-restore (orchestration), ogive (per-key idea).

## Working rhythm
Small module -> its test -> run check.sh -> ALL GREEN -> human reviews -> commit -> next.
Just-in-time file reads; NOTES.md + this file are durable state across context resets.
