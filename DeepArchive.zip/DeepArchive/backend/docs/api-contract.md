# Deep Archive Service — SDK + Server API Contract

## Model: client-side packing, thin server

Company devs call an SDK **per-file** (simple). The SDK **packs locally** into
~256MB tarballs grouped by retention class, then makes **few large calls** to the
server. Server only ever sees packed tarballs + manifests.

```
their code (per-file)  ->  SDK (buffer + pack + manifest)  ->  server API (few big calls)  ->  Glacier + warm index
```

---

## 1. Client SDK (what HDFC's developers write)

```python
from deeparchive import Client

client = Client(api_key="org_live_xxx", org_id="hdfc")

# Feels per-file. SDK buffers + packs under the hood.
client.put(
    path="statements/cust_000047_jan2026.pdf",
    data=pdf_bytes,
    retention="7y",          # drives which pack it goes into
    legal_hold=False,
    tags={"customer_id": "47", "type": "statement", "period": "2026-01"},
)

# ... called millions of times ...

client.flush()   # force buffered files to pack + upload
```

### SDK responsibilities (the hard part, done for them)
- Buffer files grouped by `retention` + `legal_hold` (never mix classes in a tarball).
- At ~256MB (or on flush/timeout) build a tarball.
- SHA-256 per file; record offset + length within the tarball.
- Build the manifest.
- Upload tarball + manifest; retry/resume on failure.
- Never delete source files; caller owns them.

### SDK config
| Option | Default | Purpose |
|---|---|---|
| pack_size | 256 MB | tarball target |
| flush_interval | 15 min | force pack if idle |
| compression | on for text/pdf, off for media | pdfs/text compress well |
| encrypt | on | client-side encryption before upload |

---

## 2. Server API (what the SDK calls -- few, large requests)

Base: `https://api.deeparchive.example/v1`  Auth: `Bearer <org api key>`

### Upload a pack (large -> presigned direct-to-S3)
```
POST /v1/packs/upload-url   -> returns presigned S3 URL
  (SDK uploads tarball straight to S3)
POST /v1/packs/complete     -> send manifest, registers pack
201 { "pack_id": "pack_...", "status": "STORED", "file_count": 1300, "bytes": 268435456 }
```

### Look up a file (warm index -- instant)
```
GET /v1/files?path=statements/cust_000047_jan2026.pdf&org=hdfc
200 {
  "file_id": "...", "pack_id": "pack_...",
  "offset": 9832448, "length": 204800, "sha256": "abc123...",
  "storage_class": "DEEP_ARCHIVE", "retention": "7y", "legal_hold": false
}
```

### Request restore (48h SLA, Bulk tier)
```
POST /v1/restore   { "files": ["file_..."] }   // or pack_id, or query
202 { "restore_id": "rst_...", "status": "PENDING", "sla_hours": 48, "eta": "2026-09-23T11:00:00Z" }
```

### Poll restore / download
```
GET /v1/restore/rst_...
200 { "status": "READY", "download_url": "https://...(presigned, short TTL)", "expires_at": "..." }
    // status: PENDING | RESTORING | READY | EXPIRED | FAILED
```

### Delete
```
DELETE /v1/files/file_...            // soft: recoverable within 48h
DELETE /v1/files/file_...?hard=true  // irreversible; BLOCKED if legal_hold=true
```

---

## 3. Manifest schema (ties SDK <-> server <-> warm index)

One manifest per tarball. Stored warm in `db/` (S3 Standard). Enables single-file
retrieval without thawing everything.

```json
{
  "manifest_version": "1.0",
  "pack_id": "pack_01HXY...",
  "org_id": "hdfc",
  "created_at": "2026-09-21T11:00:00Z",
  "tarball_key": "data/hdfc/7y/pack-2026-01-15-000.tar",
  "tarball_sha256": "def456...",
  "tarball_bytes": 268435456,
  "retention_class": "7y",
  "legal_hold": false,
  "compression": "none",
  "encryption": "aes-256-gcm",
  "files": [
    {
      "path": "statements/cust_000047_jan2026.pdf",
      "offset": 9832448,
      "length": 204800,
      "sha256": "abc123...",
      "modified": "2026-01-31T00:00:00Z",
      "tags": { "customer_id": "47", "type": "statement", "period": "2026-01" }
    }
  ]
}
```

### Invariants
- One retention/legal-hold class per tarball (never mixed).
- Every file has offset+length -> extract one file / S3 byte-range.
- sha256 per file -> integrity check after restore.
- Manifest = warm storage; tarball = cold storage.

---

## 4. Escape hatch (10% of enterprises)

Won't run your SDK (security review, air-gap, unsupported language):
- Publish manifest spec + tarball format.
- They pack to spec, call POST /v1/packs directly.
- SDK for the 90%; documented format for the 10%.

---

## 5. Why this shape

| Concern | Handled by |
|---|---|
| Tiny files / per-object cost | SDK packs ~1,300 -> 1 tarball before API |
| Your ingestion cost | Server sees few big uploads, not millions of tiny requests |
| Integration effort | Feels per-file: client.put(file) |
| You keep control of rules | You wrote the SDK: sizing, grouping, checksums |
| Single-file retrieval | Warm manifest with offset/length |
| Compliance | retention_class + legal_hold first-class, drive packing & delete |
| 48h SLA | restore = Bulk tier, tracked async, notify on ready |
