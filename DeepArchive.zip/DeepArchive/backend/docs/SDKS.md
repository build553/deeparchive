# SDKs — multi-language strategy

DeepArchive follows the industry pattern (AWS/Stripe): **describe the API once,
generate thin clients for every language, hand-write only the smart bits.**

## The pipeline

```
FastAPI /v1 app
   └─ auto-generates OpenAPI 3.1 spec  (free, no work)
        └─ scripts/export_openapi.py  ->  openapi.json   (single source of truth)
             └─ scripts/make_sdks.sh   ->  generated-sdks/{python,java,typescript,go,csharp,ruby}
                  (via OpenAPI Generator; needs Java or Docker)
```

## Two layers per language

1. **Generated thin client** (free, any language): HTTP wrappers for every
   endpoint — `create_pack`, `restore`, `find_file`, `purchase`, etc. Regenerate
   whenever the API changes.

2. **Hand-written packing layer** (the hard part): the `put()`/`flush()` logic
   that bundles files into ~256MB tarballs client-side before upload. This is
   NOT generated — it's added on top of the thin client, per language, and only
   when a customer needs that language. The **Python SDK (`deeparchive.sdk`)** is
   the reference implementation of this layer.

## How to generate SDKs

```bash
python scripts/export_openapi.py          # refresh openapi.json
bash scripts/make_sdks.sh                  # default: python java typescript go csharp ruby
bash scripts/make_sdks.sh java typescript  # or specific languages
```

Requires `openapi-generator-cli` (Java) or Docker (`openapitools/openapi-generator-cli`).
Also: FastAPI serves the live spec at `GET /openapi.json`, so customers can
generate their own client from a running instance without any files from us.

## Status
- ✅ OpenAPI spec auto-generated + exported (20 paths, 21 ops, 14 schemas, valid)
- ✅ Generation script ready (runs anywhere with Java/Docker)
- ✅ Python SDK reference with the packing layer (deeparchive.sdk)
- ⏳ Generate Java/TS/Go/etc. on demand (needs Java/Docker; not in this sandbox)
- ⏳ Port the packing layer to a 2nd language when a paying customer needs it

## Recommendation
Don't hand-write 6 SDKs. Ship the generated thin clients from the spec, keep the
Python SDK as the packing reference, and hand-port the packing layer only when a
specific customer's language demands it.
