# DeepArchive

Ultra-low-cost long-term archival storage on S3 Glacier Deep Archive.

Store files for ~30 years at a fraction of consumer cloud prices, by packing
many files into large tarballs, keeping a warm searchable index, and treating
retrieval as a rare, SLA-bound operation.

## Core idea

- **Cold vault** (`data/`) — files packed into ~256MB tarballs, stored in
  Glacier Deep Archive (~$1/TB/month).
- **Warm index** (`db/`) — JSON manifests in S3 Standard: which tarball holds
  each file, at what offset, with what checksum. Instant to browse.
- **Retrieval** — request → Bulk restore → **within 48h** → download → verify.
- **Delete** — soft (recoverable within SLA) by default; explicit hard delete.

## Locked decisions

| Decision | Choice |
|---|---|
| Storage tier | Glacier Deep Archive |
| Pack size | ~256 MB tarballs |
| Retrieval SLA | within 48h (Bulk tier) |
| Delete model | soft default + explicit hard delete |
| Language | Python (Go only for desktop mount, later) |
| Bucket | deep-archive-lab (set DEEPARCHIVE_BUCKET; us-east-1) |

## Project layout

```
deeparchive/          core library (shared by every surface)
  config.py           central settings (bucket, prefixes, sizes)
  manifest.py         manifest schema: read/write/validate
  packer.py           pack files -> tarball + manifest (+ SHA-256)
  storage.py          S3/Glacier: upload, lifecycle, restore, presign
  restore.py          48h restore orchestration state machine
  (crypto.py)         client-side encryption (later)
  (index.py)          warm-index read/write, later DynamoDB

server/               FastAPI app exposing the /v1 API (later)
scripts/              one-off dev/test scripts
tests/                unit tests
docs/                 design docs (api-contract, etc.)
```

Rule: the **core** is written once. CLI, SDK, and server all import it —
never reimplement packing/restore logic in a surface.

## Setup

```
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Status

Bootstrapping. First milestone: pack a folder -> upload -> verify Deep Archive
transition -> restore -> download -> verify SHA-256 (the full loop).
