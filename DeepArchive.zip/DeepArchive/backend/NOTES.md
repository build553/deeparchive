# NOTES.md — durable project state

Structured note-taking (per Anthropic context-engineering guidance). This file is
the source of truth for project state so it survives context resets. Update it as
we go.

## What we're building
Ultra-low-cost archival storage on S3 Glacier Deep Archive. Pack files into ~256MB
tarballs (cold), warm JSON index (tarball + offset + sha256), retrieve within 48h.

## Locked decisions
- Storage: Glacier Deep Archive; pack size 256 MiB; retrieval Bulk / 48h SLA.
- Delete: soft (recoverable within SLA) default + explicit hard delete.
- Language: Python. (Go only later, for the desktop mount, if needed.)
- Methodology: Mantle model — small modules, simple code, strict feedback loop,
  make illegal states hard, examples > rules, minimal context, human owns every line.
- Bucket: deep-archive-lab (set DEEPARCHIVE_BUCKET; us-east-1). Public access blocked.
  Lifecycle: data/ -> Deep Archive (0 days); db/ + reports/ stay Standard.

## Feedback loop
`bash scripts/check.sh` = ruff + mypy(strict) + pytest. Must be ALL GREEN.

## Current status
- [x] Research (8 repos read in ~/archive-research)
- [x] AWS bucket + lifecycle live
- [x] Project scaffold + Mantle feedback loop (ALL GREEN)
- [x] Module boundaries segregated (Option 2)
- [x] manifest/ — schema (RetentionClass enum, FileEntry, Manifest, JSON round-trip)
- [x] packer/ — pack files grouped by retention -> tarball + manifest + sha256 + offsets (offset/length verified to slice exact bytes)
- [x] regions.py — country->region registry, strict residency (active: US, IN, EU)
- [x] storage/ — region-aware S3 (only boto3 module); refuses cross-region; tarball->data/, manifest->db/; start_restore/restore_ready/download
- [x] restore/ — 48h state machine (RESTORING->READY), download+verify sha256 integrity
- [x] first REAL upload to lab bucket (via scripts/first_upload.py) — store path verified live
- [x] CLI — deeparchive pack/upload/restore/status (console script; pack tested no-AWS)
- [x] HTTP API (FastAPI) — /v1/health, /v1/regions, POST /v1/restore, GET /v1/restore/{key}; injectable storage for tests; residency enforced (422 for unserved)
- [ ] API: add upload (presigned) + file lookup endpoints   <-- NEXT option
- [ ] SDK (pip-installable client for customers)
- [ ] live restore test with a >128KB object

Tests: 43 passing. All via check.sh. Core loop + CLI + API working.

## Hardening progress (6 features)
1. [x] Multipart upload (TransferConfig)
2. [x] Incremental + resume (ArchiveIndex, from serac)
3. [x] Error handling + retries (adaptive + transient/permanent taxonomy)
4. [x] API auth + org isolation (hashed keys, 401/403)
5. [x] Client-side encryption: per-customer AES-256-GCM; LocalKeyStore (free/dev)
      + SsmKeyStore (free SecureString, prod). Encrypt on upload (nonce in
      manifest), decrypt on restore, integrity verified. One key per customer.
6. [x] Restore orchestration: persistent RestoreRecord + LocalJobStore (DynamoDB-
      swappable) + Orchestrator (create->RESTORING, advance->READY, redrive FAILED
      with attempt cap). Adapted from aws-glacier-restore. 5 tests.

ALL 6 HARDENING FEATURES DONE. Tests: 48 passing.

## Region model
Strict residency: serve a country only if it has an active in-country region.
Launch active: US (us-east-1), IN (ap-south-1), EU (DE/FR/IE). Others listed but
inactive. Countries with no in-country region (e.g. NG) are refused, not
cross-border fallback. regions.resolve(country) enforces this.

## Layout (Option 2: one package, segregated modules)
```
deeparchive/
  config.py            settings (flat module)
  manifest/            manifest schema            [boundary defined, logic TODO]
  packer/              pack files -> tarball       [boundary defined, logic TODO]
  storage/             S3/Glacier (only boto3 here)[boundary defined, logic TODO]
  restore/             48h restore state machine   [boundary defined, logic TODO]
  services/
    cli/               command-line surface (thin) [boundary defined, logic TODO]
```
Each module = one responsibility, clear interface documented in its __init__.py.
Services import core modules; they hold NO archival logic.

## Working rhythm
Small module -> its test -> run check.sh -> ALL GREEN -> human reviews -> commit -> next.
