#!/usr/bin/env bash
# The "does it compile" loop, Mantle-style.
# Runs type-check + lint + tests. Green = safe to proceed.
set -euo pipefail
cd "$(dirname "$0")/.."

source .venv/bin/activate

echo "==> ruff (lint)"
ruff check deeparchive tests

echo "==> mypy (type check)"
mypy

echo "==> pytest (tests)"
pytest

echo ""
echo "ALL GREEN"
