#!/usr/bin/env bash
# Generate SDKs for many languages from the OpenAPI spec (Path B).
#
# One spec (openapi.json) -> thin clients in Python, Java, TypeScript, Go, C#,
# Ruby, etc. Regenerate whenever the API changes. The generated clients are HTTP
# wrappers; the client-side packing layer (put/flush) is hand-added on top per
# language (only the Python reference has it so far).
#
# Requires openapi-generator-cli (needs Java) OR the Docker image.
# Usage: bash scripts/make_sdks.sh [lang ...]   (default: a common set)
set -euo pipefail
cd "$(dirname "$0")/.."

SPEC="openapi.json"
OUT="generated-sdks"
LANGS=("${@:-python java typescript-axios go csharp ruby}")

if [ ! -f "$SPEC" ]; then
  echo "Missing $SPEC -- run: python scripts/export_openapi.py" >&2
  exit 1
fi

gen() {  # gen <lang>
  local lang="$1"
  echo "==> generating $lang"
  if command -v openapi-generator-cli >/dev/null 2>&1; then
    openapi-generator-cli generate -i "$SPEC" -g "$lang" -o "$OUT/$lang"
  elif command -v docker >/dev/null 2>&1; then
    docker run --rm -v "$PWD:/local" openapitools/openapi-generator-cli \
      generate -i "/local/$SPEC" -g "$lang" -o "/local/$OUT/$lang"
  else
    echo "  need openapi-generator-cli (Java) or Docker; skipping $lang" >&2
    return 1
  fi
}

for lang in ${LANGS[*]}; do
  gen "$lang" || true
done
echo "Done. SDKs under $OUT/"
