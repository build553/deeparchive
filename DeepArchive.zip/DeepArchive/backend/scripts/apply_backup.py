#!/usr/bin/env python3
"""Enable S3 versioning + residency-aware cross-region replication on a bucket.

INFRA CHANGE -- mutates bucket configuration. DRY-RUN by default: it prints the
plan and changes nothing. Pass --apply to actually make the changes.

Replication needs, on the AWS side (not created here):
  * the DR bucket to exist in the destination region (same jurisdiction), and
  * an IAM role S3 can assume to replicate (pass --role-arn).

Usage:
  python scripts/apply_backup.py --region us-east-1 --bucket deep-archive-us \\
      --role-arn arn:aws:iam::ACCT:role/s3-replication            # dry-run
  python scripts/apply_backup.py ... --apply                       # do it
"""
from __future__ import annotations

import argparse
import json
import sys

import boto3

from deeparchive.backup import (
    ResidencyViolationError,
    build_replication_plan,
    replication_config,
    versioning_config,
)


def main() -> int:
    ap = argparse.ArgumentParser(description="Apply S3 versioning + DR replication.")
    ap.add_argument("--region", required=True, help="source bucket region")
    ap.add_argument("--bucket", required=True, help="source bucket name")
    ap.add_argument("--role-arn", required=True, help="IAM role S3 uses to replicate")
    ap.add_argument("--apply", action="store_true", help="actually apply (default: dry-run)")
    args = ap.parse_args()

    try:
        plan = build_replication_plan(args.region, args.bucket)
    except ResidencyViolationError as exc:
        print(f"REFUSING: {exc}", file=sys.stderr)
        return 2

    versioning = versioning_config()
    replication = replication_config(plan, role_arn=args.role_arn)

    print("=== Backup / DR plan (residency-safe) ===")
    print(f"  source : {plan.source_bucket} ({plan.source_region})")
    print(f"  replica: {plan.dest_bucket} ({plan.dest_region})  [same jurisdiction]")
    print(f"  versioning: {versioning}")
    print(f"  replication rule:\n{json.dumps(replication, indent=2)}")

    if not args.apply:
        print("\nDRY-RUN: nothing changed. Re-run with --apply to enact.")
        return 0

    s3 = boto3.client("s3", region_name=args.region)
    print("\nApplying versioning...")
    s3.put_bucket_versioning(
        Bucket=plan.source_bucket, VersioningConfiguration=versioning
    )
    print("Applying replication...")
    s3.put_bucket_replication(
        Bucket=plan.source_bucket, ReplicationConfiguration=replication
    )
    print("Done. Versioning + cross-region replication enabled.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
