"""Live end-to-end test against the real lab bucket (NOT a unit test).

Exercises the full pipeline with encryption:
  pack -> encrypt (per-customer key) -> real S3 upload -> verify ciphertext in S3
  -> confirm manifest carries the nonce -> report storage classes -> cleanup.

Run: python scripts/live_e2e.py
"""
from __future__ import annotations

import os
import tempfile

import boto3

from deeparchive import regions
from deeparchive.crypto import LocalKeyStore
from deeparchive.manifest import Manifest, RetentionClass
from deeparchive.packer import SourceFile, pack
from deeparchive.storage import Storage

LAB_BUCKET = os.environ.get("DEEPARCHIVE_BUCKET", "deep-archive-lab")


def main() -> None:
    # Point US region at the existing lab bucket.
    regions.REGISTRY["US"] = regions.RegionInfo(
        country="US", region="us-east-1", bucket=LAB_BUCKET,
        in_country=True, active=True,
    )

    work = tempfile.mkdtemp(prefix="da_live_")
    src = os.path.join(work, "src")
    out = os.path.join(work, "out")
    os.makedirs(src)

    # Bank-style small files, one retention class.
    for i in range(5):
        with open(os.path.join(src, f"statement_{i}.pdf"), "wb") as f:
            f.write(f"PRIVATE bank statement {i}\n".encode() * 200)

    files = [
        SourceFile(os.path.join(src, n), f"statements/{n}", RetentionClass.SEVEN_YEAR)
        for n in os.listdir(src)
    ]

    packs = pack(files, out_dir=out, org_id="livetest")
    print(f"[1] Packed {len(packs)} tarball(s), {sum(len(p.manifest.files) for p in packs)} files")

    # Encrypt with a per-customer key + upload to REAL S3.
    keystore = LocalKeyStore(os.path.join(work, "keys.json"))
    storage = Storage.for_country("US", key_store=keystore)
    for p in packs:
        storage.upload_pack(p)
        print(f"[2] Encrypted + uploaded {p.manifest.tarball_key}")

    s3 = boto3.client("s3", region_name="us-east-1")

    # Verify: object exists, stored bytes are CIPHERTEXT (not the plaintext tarball).
    p0 = packs[0]
    with open(p0.tarball_path, "rb") as f:
        plaintext = f.read()
    stored = s3.get_object(Bucket=LAB_BUCKET, Key=p0.manifest.tarball_key)["Body"].read()
    print(f"[3] Stored bytes == plaintext tarball? {stored == plaintext}  "
          f"(expect False -> it's encrypted)")

    # Verify: uploaded manifest carries the encryption nonce.
    mkey = f"db/livetest/{p0.manifest.pack_id}.json"
    m = Manifest.from_json(s3.get_object(Bucket=LAB_BUCKET, Key=mkey)["Body"].read().decode())
    print(f"[4] Manifest has encryption nonce? {bool(m.encryption_nonce)}  "
          f"(len={len(m.encryption_nonce)})")

    # Report what's in the bucket now + storage classes.
    print("[5] Objects in bucket (livetest/):")
    resp = s3.list_objects_v2(Bucket=LAB_BUCKET, Prefix="")
    live_keys = []
    for obj in resp.get("Contents", []):
        if "livetest" in obj["Key"]:
            live_keys.append(obj["Key"])
            head = s3.head_object(Bucket=LAB_BUCKET, Key=obj["Key"])
            print(f"      {obj['Key']}  [{head.get('StorageClass', 'STANDARD')}]  {obj['Size']}B")

    # Cleanup: remove everything we just wrote.
    for k in live_keys:
        s3.delete_object(Bucket=LAB_BUCKET, Key=k)
    print(f"[6] Cleaned up {len(live_keys)} test object(s). Done.")


if __name__ == "__main__":
    main()
