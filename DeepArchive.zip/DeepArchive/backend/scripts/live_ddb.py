"""Live proof against REAL AWS DynamoDB (not a unit test).

Proves metadata persists durably: create tables, write account+org+job, then
read them back with BRAND-NEW store instances (simulating a server restart),
then delete the tables to leave nothing behind.

Uses a unique table prefix so it never collides with real data.

Run: python scripts/live_ddb.py
"""
from __future__ import annotations

import time

import boto3

from deeparchive import config
from deeparchive.accounts.accounts import Account, AccountType
from deeparchive.accounts.orgs import Organization, RetentionPolicy, Role
from deeparchive.manifest import RetentionClass
from deeparchive.restore.orchestrator import JobStatus, RestoreRecord

# Unique prefix for this run so we never touch anything else.
config.DDB_TABLE_PREFIX = f"deeparchive_livetest_{int(time.time())}"

from deeparchive.persistence import (  # noqa: E402  (after prefix set)
    DdbAccountStore,
    DdbJobStore,
    DdbOrgStore,
    create_tables,
    table_name,
)


def main() -> None:
    res = boto3.resource("dynamodb", region_name="us-east-1")
    print(f"[0] Using table prefix: {config.DDB_TABLE_PREFIX}")

    print("[1] Creating tables...")
    create_tables(res)
    print("    created:", table_name("accounts"), table_name("orgs"), table_name("jobs"))

    # --- Write with one set of store instances ---
    now = time.time()
    DdbAccountStore(resource=res).put(
        Account(
            account_id="acc_live", account_type=AccountType.ENTERPRISE,
            country="IN", region="ap-south-1", created_at=now,
            email="cto@hdfc.example", provider="google", provider_user_id="g-live",
        )
    )
    org = Organization(
        account_id="acc_live", name="HDFC",
        policy=RetentionPolicy(RetentionClass.SEVEN_YEAR, default_legal_hold=True),
    )
    org.add_member("cto@hdfc.example", Role.ADMIN)
    DdbOrgStore(resource=res).put(org)
    DdbJobStore(resource=res).put(
        RestoreRecord(
            job_id="rst_live", org_id="acc_live",
            tarball_key="data/acc_live/7y/p.tar", status=JobStatus.RESTORING,
            created_at=now, updated_at=now, attempts=1,
        )
    )
    print("[2] Wrote account + org + job.")

    # --- Read back with BRAND-NEW instances = restart proof ---
    acc = DdbAccountStore(resource=res).get("acc_live")
    org2 = DdbOrgStore(resource=res).get("acc_live")
    job = DdbJobStore(resource=res).get("rst_live")
    print("[3] Restart proof (fresh store instances read persisted data):")
    print(f"    account: {acc.account_id} type={acc.account_type.value} region={acc.region}")
    print(f"    org:     {org2.name} admin?={org2.role_of('cto@hdfc.example')}")
    print(f"    job:     {job.job_id} status={job.status.value}")

    # --- GSI lookup proof ---
    by_provider = DdbAccountStore(resource=res).find_by_provider("google", "g-live")
    by_email = DdbAccountStore(resource=res).find_by_email("cto@hdfc.example")
    print("[4] GSI lookups:")
    print(f"    by_provider(google,g-live) -> {by_provider.account_id if by_provider else None}")
    print(f"    by_email(cto@hdfc.example) -> {by_email.account_id if by_email else None}")

    # --- Cleanup: delete the tables ---
    print("[5] Deleting tables...")
    for kind in ("accounts", "orgs", "jobs"):
        res.Table(table_name(kind)).delete()
    print("    Done. Tables deleted, nothing left behind.")


if __name__ == "__main__":
    main()
