"""One-off: first real upload to the live us-east-1 bucket.

Packs a small set of files, uploads via our Storage library, and confirms the
objects landed. Uses the existing lab bucket by overriding the US region entry.

Run:  python scripts/first_upload.py
"""
from __future__ import annotations

import os
import tempfile

import boto3

from deeparchive import regions
from deeparchive.manifest import RetentionClass
from deeparchive.packer import SourceFile, pack
from deeparchive.storage import Storage

LAB_BUCKET = os.environ.get("DEEPARCHIVE_BUCKET", "deep-archive-lab")


def main() -> None:
    # Point the US region at the existing lab bucket (no new bucket, no hardcoding
    # the account id in library code).
    us = regions.REGISTRY["US"]
    regions.REGISTRY["US"] = regions.RegionInfo(
        country="US", region="us-east-1", bucket=LAB_BUCKET,
        in_country=True, active=True,
    )
    assert us  # (silence unused)

    work = tempfile.mkdtemp(prefix="da_first_")
    src_dir = os.path.join(work, "src")
    out_dir = os.path.join(work, "out")
    os.makedirs(src_dir)

    # A couple of realistic files, two retention classes.
    with open(os.path.join(src_dir, "tax_2019.pdf"), "wb") as f:
        f.write(b"pretend tax return pdf bytes\n" * 500)
    with open(os.path.join(src_dir, "photo.jpg"), "wb") as f:
        f.write(b"pretend jpeg bytes\n" * 800)

    files = [
        SourceFile(os.path.join(src_dir, "tax_2019.pdf"), "docs/tax_2019.pdf",
                   RetentionClass.SEVEN_YEAR),
        SourceFile(os.path.join(src_dir, "photo.jpg"), "media/photo.jpg",
                   RetentionClass.INDEFINITE),
    ]

    packs = pack(files, out_dir=out_dir, org_id="vemuvi")
    print(f"Packed {len(packs)} tarball(s).")

    storage = Storage.for_country("US")
    for p in packs:
        storage.upload_pack(p)
        print(f"Uploaded {p.manifest.tarball_key} "
              f"({p.manifest.tarball_bytes} bytes, {len(p.manifest.files)} files)")

    # Confirm objects exist and report their storage class.
    s3 = boto3.client("s3", region_name="us-east-1")
    resp = s3.list_objects_v2(Bucket=LAB_BUCKET)
    print("\nObjects now in bucket:")
    for obj in resp.get("Contents", []):
        head = s3.head_object(Bucket=LAB_BUCKET, Key=obj["Key"])
        sc = head.get("StorageClass", "STANDARD")
        print(f"  {obj['Key']}  [{sc}]  {obj['Size']} bytes")


if __name__ == "__main__":
    main()
