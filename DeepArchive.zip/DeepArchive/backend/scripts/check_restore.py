"""Check the live 48h restore started on 2026-09-22 and download when ready.

Run: python scripts/check_restore.py
When head-object shows ongoing-request="false", the object is downloadable.
"""
from __future__ import annotations

import boto3

BUCKET = "deep-archive-lab-197446684294"  # override via your own bucket
KEY = "data/restore-test/pack_restore_demo.tar"


def main() -> None:
    s3 = boto3.client("s3", region_name="us-east-1")
    head = s3.head_object(Bucket=BUCKET, Key=KEY)
    restore = head.get("Restore", "")
    print(f"StorageClass: {head.get('StorageClass')}")
    print(f"Restore header: {restore!r}")
    if 'ongoing-request="false"' in restore:
        print("READY -> downloading...")
        s3.download_file(BUCKET, KEY, "/tmp/da_restored.bin")
        print("Downloaded to /tmp/da_restored.bin")
    elif 'ongoing-request="true"' in restore:
        print("Still restoring (up to 48h from start). Check again later.")
    else:
        print("No restore in progress.")


if __name__ == "__main__":
    main()
