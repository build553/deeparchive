"""Per-API input/output demo: for each endpoint, print request IN and response OUT."""
from __future__ import annotations

import json

import boto3
from fastapi.testclient import TestClient

from deeparchive import regions

BUCKET = "deep-archive-lab-197446684294"
regions.REGISTRY["US"] = regions.RegionInfo("US", "us-east-1", BUCKET, True, True)

from deeparchive.billing import BillingService, FakeProcessor, UsageMeter  # noqa: E402
from deeparchive.services.api.accounts_api import build_accounts_router  # noqa: E402
from deeparchive.services.api.app import create_app  # noqa: E402
from deeparchive.services.api.auth import KeyStore  # noqa: E402
from deeparchive.services.api.billing_api import build_billing_router  # noqa: E402
from deeparchive.services.api.wiring import build_accounts_deps  # noqa: E402
from deeparchive.storage import Storage  # noqa: E402

keys = KeyStore()
meter = UsageMeter()
deps = build_accounts_deps(api_keys=keys)
s3 = boto3.client("s3", region_name="us-east-1")
app = create_app(key_store=keys, usage_meter=meter,
                 storage_provider=lambda c: Storage(regions.resolve(c), s3=s3))
app.include_router(build_accounts_router(deps))
app.include_router(build_billing_router(
    keys, BillingService(processor=FakeProcessor(), meter=meter), meter))
tc = TestClient(app)

_key = {"v": ""}
_acct = {"v": ""}


def show(title: str, method: str, path: str, body=None, use_auth=True) -> dict:
    headers = {"Authorization": f"Bearer {_key['v']}"} if use_auth and _key["v"] else {}
    print("\n" + "=" * 70)
    print(f"{title}")
    print(f"IN : {method} {path}")
    if headers:
        print(f"     Authorization: Bearer {headers['Authorization'][7:19]}...")
    if body is not None:
        print(f"     body: {json.dumps(body)}")
    resp = tc.request(method, path, json=body, headers=headers)
    try:
        out = resp.json()
    except Exception:
        out = resp.text[:80]
    print(f"OUT: {resp.status_code}  {json.dumps(out)[:400]}")
    return out if isinstance(out, dict) else {}


def main() -> None:
    show("1. Health", "GET", "/v1/health", use_auth=False)
    show("2. Regions", "GET", "/v1/regions", use_auth=False)

    org = show("3. Create Org", "POST", "/v1/orgs",
               {"name": "HDFC", "country": "US", "admin_user_ref": "admin"}, use_auth=False)
    _key["v"] = org["api_key"]
    _acct["v"] = org["account_id"]

    show("4. Account Me", "GET", "/v1/accounts/me")
    show("5. Pricing (India)", "GET", "/v1/billing/pricing?country=IN", use_auth=False)
    show("6. Purchase Plan", "POST", "/v1/billing/purchase",
         {"plan_id": "individual-100-30y", "payment_token": "tok"})
    show("7. Billing Account", "GET", "/v1/billing/account")

    tk = f"data/{_acct['v']}/7y/demo.tar"
    show("8. Pack Upload URL", "POST", "/v1/packs/upload-url",
         {"country": "US", "tarball_key": tk})

    # Register a manifest so file lookup works.
    from deeparchive.manifest import FileEntry, Manifest, RetentionClass
    m = Manifest(pack_id="demo", org_id=_acct["v"], created_at="2026-01-01T00:00:00Z",
                 tarball_key=tk, tarball_sha256="a" * 64, tarball_bytes=2048,
                 retention_class=RetentionClass.SEVEN_YEAR, legal_hold=False,
                 files=[FileEntry("docs/jan.pdf", 512, 1024, "b" * 64, "2026-01-01T00:00:00Z")])
    show("9. Pack Complete", "POST", "/v1/packs/complete",
         {"country": "US", "manifest_json": m.to_json()})
    show("10. Find File", "GET", "/v1/files?path=docs/jan.pdf&country=US")
    show("11. Restore", "POST", "/v1/restore", {"country": "US", "tarball_key": tk})
    show("12. Subscribe (monthly)", "POST", "/v1/billing/subscribe",
         {"plan_id": "individual-100-monthly", "payment_token": "tok"})
    show("13. Cancel Subscription", "POST", "/v1/billing/cancel")
    show("14. Delete Pack", "DELETE", f"/v1/packs/demo?country=US&hard=true")

    # cleanup
    for pref in (f"db/{_acct['v']}/", f"data/{_acct['v']}/"):
        for o in s3.list_objects_v2(Bucket=BUCKET, Prefix=pref).get("Contents", []):
            s3.delete_object(Bucket=BUCKET, Key=o["Key"])
    print("\n" + "=" * 70)
    print("cleanup: test objects removed")


if __name__ == "__main__":
    main()
