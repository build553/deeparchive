#!/usr/bin/env bash
# The BUILD step: gate on tests, then produce a deployable ARTIFACT.
#
# Python isn't "compiled" like Go/Rust, but there is still a real build: resolve
# + build the package and ALL its dependencies into wheels ONCE, here, so every
# host installs the identical, prebuilt, offline artifact -- no per-host compile,
# no PyPI dependency at boot, reproducible across the fleet.
#
# Output: cdk/artifact/  (a wheelhouse: deeparchive-*.whl + every dependency wheel)
# CDK's BucketDeployment ships THIS (small, clean), not raw source.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARTIFACT_DIR="$REPO_ROOT/cdk/artifact"

cd "$REPO_ROOT"

echo "==> 1/3 Test gate (never ship red code)"
bash scripts/check.sh

echo "==> 2/3 Clean previous artifact"
rm -rf "$ARTIFACT_DIR"
mkdir -p "$ARTIFACT_DIR"

echo "==> 3/3 Build the app wheel (deps resolve on host from PyPI via NAT)"
# Build ONLY the deeparchive wheel -- small, fast to upload. Its dependency
# versions are pinned in the wheel metadata, so host installs stay consistent.
# (Bundling boto3/botocore too made a 15MB artifact that was slow to publish.)
python -m pip wheel . -w "$ARTIFACT_DIR" --no-deps >/dev/null
# Record the built app version for traceability.
python -c "import tomllib,sys; print(tomllib.load(open('pyproject.toml','rb'))['project']['version'])" \
    > "$ARTIFACT_DIR/VERSION" 2>/dev/null || echo "0.0.0" > "$ARTIFACT_DIR/VERSION"

echo "==> Artifact ready: $ARTIFACT_DIR"
ls -1 "$ARTIFACT_DIR"/*.whl | wc -l | xargs echo "   wheels:"
echo "   version: $(cat "$ARTIFACT_DIR/VERSION")"
