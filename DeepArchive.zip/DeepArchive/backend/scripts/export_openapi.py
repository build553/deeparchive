"""Export the OpenAPI spec from the assembled app to openapi.json.

FastAPI auto-generates the spec from the /v1 endpoints -- this is the single
source of truth from which SDKs for any language are generated (Path B).

Run: python scripts/export_openapi.py  ->  writes openapi.json
"""
from __future__ import annotations

import json
import pathlib

from deeparchive.services.api.main import build_app


def main() -> None:
    spec = build_app().openapi()
    out = pathlib.Path(__file__).resolve().parent.parent / "openapi.json"
    out.write_text(json.dumps(spec, indent=2, sort_keys=True))
    print(f"Wrote {out}  ({len(spec['paths'])} paths, OpenAPI {spec['openapi']})")


if __name__ == "__main__":
    main()
