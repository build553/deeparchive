#!/usr/bin/env python3
"""Local no-auth test harness for ALL services, in-process, no AWS.

The SAFE way to "bypass auth and test everything": each service runs in-process
with a bypass identity (accepts any key) + in-memory fakes. Never exposed to the
internet (unlike disabling auth on the live ALB). Run: python scripts/bypass_test.py
"""
from __future__ import annotations

import io
from typing import Any

from fastapi.testclient import TestClient

from deeparchive import regions
from deeparchive.manifest import FileEntry, Manifest, RetentionClass
from deeparchive.services.billing_svc import build_billing_app
from deeparchive.services.identity import build_identity_app
from deeparchive.services.ingest_svc import build_ingest_app
from deeparchive.services.metadata_svc import build_metadata_app
from deeparchive.services.restore_svc import build_restore_app
from deeparchive.storage import Storage

AUTH = {"Authorization": "Bearer bypassed"}
PASS = 0
FAIL = 0


def check(label: str, got: int, want: int, body: Any = "") -> None:
    global PASS, FAIL
    ok = got == want
    mark = "\033[32mPASS\033[0m" if ok else "\033[31mFAIL\033[0m"
    if ok:
        PASS += 1
    else:
        FAIL += 1
    b = str(body)[:70]
    print(f"  {mark} {label:44s} {got} (want {want})  {b}")


class BypassIdentity:
    """Accepts ANY key -> fixed account. Auth bypassed."""
    def validate(self, api_key: str) -> dict[str, Any]:
        return {"account_id": "acc_local", "country": "US"}


class AllowBilling:
    def check_quota(self, account_id: str, size_bytes: int) -> bool:
        return True


class FakeS3:
    """In-memory S3 covering the paths all services touch."""
    def __init__(self, ready: bool = True, tarball: bytes = b"") -> None:
        self.objects: dict[str, bytes] = {}
        self.ready = ready
        self.tarball = tarball

    def put_object(self, Bucket, Key, Body, StorageClass=None):  # type: ignore[no-untyped-def]  # noqa: N803
        self.objects[Key] = Body if isinstance(Body, bytes) else Body.encode()

    def get_object(self, Bucket, Key, Range=None):  # type: ignore[no-untyped-def]  # noqa: N803
        if Key.endswith(".tar"):
            data = self.tarball
            if Range:
                se = Range.replace("bytes=", "").split("-")
                return {"Body": io.BytesIO(data[int(se[0]):int(se[1]) + 1])}
            return {"Body": io.BytesIO(data)}
        return {"Body": io.BytesIO(self.objects[Key])}

    def head_object(self, Bucket, Key):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Restore": f'ongoing-request="{"false" if self.ready else "true"}"'}

    def restore_object(self, Bucket, Key, RestoreRequest):  # type: ignore[no-untyped-def]  # noqa: N803
        return None

    def list_objects_v2(self, Bucket, Prefix):  # type: ignore[no-untyped-def]  # noqa: N803
        return {"Contents": [{"Key": k} for k in self.objects if k.startswith(Prefix)]}

    def generate_presigned_url(self, op, Params, ExpiresIn):  # type: ignore[no-untyped-def]  # noqa: N803
        return f"https://s3.local/{Params['Key']}"


def _storage(s3: FakeS3):  # type: ignore[no-untyped-def]
    return lambda c: Storage(regions.resolve(c), s3=s3)


def _manifest() -> Manifest:
    return Manifest(
        pack_id="pk1", org_id="acc_local", created_at="2026-01-01T00:00:00Z",
        tarball_key="data/acc_local/7y/pk1.tar", tarball_sha256="a" * 64,
        tarball_bytes=2048, retention_class=RetentionClass.SEVEN_YEAR,
        legal_hold=False,
        files=[FileEntry("docs/report.pdf", 512, 1024, "b" * 64, "2026-01-01T00:00:00Z")],
    )


def test_identity() -> None:
    print("\n== IDENTITY (real in-memory) ==")
    c = TestClient(build_identity_app())
    r = c.get("/v1/health"); check("GET /v1/health", r.status_code, 200, r.json())
    r = c.post("/v1/orgs", json={"name": "T", "country": "US", "admin_user_ref": "a@x"})
    check("POST /v1/orgs (register)", r.status_code, 200, r.json())
    key = r.json()["api_key"]
    r = c.get("/v1/accounts/me", headers={"Authorization": f"Bearer {key}"})
    check("GET /v1/accounts/me", r.status_code, 200, r.json())
    r = c.post("/v1/orgs", json={"name": "X", "country": "NG", "admin_user_ref": "x@x"})
    check("POST /v1/orgs (NG -> 422)", r.status_code, 422, r.json())
    r = c.post("/internal/validate", json={"api_key": key})
    check("POST /internal/validate", r.status_code, 200, r.json())


def test_ingest() -> None:
    print("\n== INGEST (auth bypassed) ==")
    s3 = FakeS3()
    c = TestClient(build_ingest_app(
        identity=BypassIdentity(), billing=AllowBilling(),  # type: ignore[arg-type]
        storage_for_country=_storage(s3)))  # type: ignore[arg-type]
    r = c.get("/v1/files?path=docs/report.pdf", headers=AUTH)
    check("GET /v1/files (before, 404)", r.status_code, 404, r.json())
    r = c.post("/v1/packs/upload-url", json={"tarball_key": "data/acc_local/7y/pk1.tar"}, headers=AUTH)
    check("POST /v1/packs/upload-url", r.status_code, 200, r.json())
    r = c.post("/v1/packs/complete", json={"manifest_json": _manifest().to_json()}, headers=AUTH)
    check("POST /v1/packs/complete", r.status_code, 200, r.json())
    r = c.get("/v1/files?path=docs/report.pdf", headers=AUTH)
    check("GET /v1/files (after, 200)", r.status_code, 200, r.json())
    r = c.post("/v1/packs/complete", json={"manifest_json": "{}"}, headers=AUTH)
    check("POST /v1/packs/complete (bad -> 400)", r.status_code, 400, r.json())


def test_metadata() -> None:
    print("\n== METADATA (auth bypassed) ==")
    s3 = FakeS3(ready=True, tarball=b"X" * 512 + b"J" * 1024 + b"Z" * 100)
    s3.objects["db/acc_local/pk1.json"] = _manifest().to_json().encode()
    c = TestClient(build_metadata_app(
        identity=BypassIdentity(),  # type: ignore[arg-type]
        storage_for_country=_storage(s3)))  # type: ignore[arg-type]
    r = c.get("/v1/catalog", headers=AUTH)
    check("GET /v1/catalog", r.status_code, 200, r.json())
    r = c.get("/v1/folders", headers=AUTH)
    check("GET /v1/folders", r.status_code, 200, r.json())
    r = c.get("/v1/files/docs/report.pdf/content", headers=AUTH)
    check("GET /v1/files/{p}/content (restored)", r.status_code, 200,
          f"{len(r.content)} bytes")
    r = c.get("/v1/files/ghost.pdf/content", headers=AUTH)
    check("GET /v1/files/{p}/content (404)", r.status_code, 404, r.json())


def test_restore() -> None:
    print("\n== RESTORE (auth bypassed) ==")
    s3 = FakeS3(ready=True)
    c = TestClient(build_restore_app(
        identity=BypassIdentity(),  # type: ignore[arg-type]
        storage_for_country=_storage(s3)))  # type: ignore[arg-type]
    key = "data/acc_local/7y/pk1.tar"
    r = c.post("/v1/restore", json={"tarball_key": key}, headers=AUTH)
    check("POST /v1/restore", r.status_code, 200, r.json())
    r = c.get(f"/v1/restore/{key}", headers=AUTH)
    check("GET /v1/restore/{k} (status)", r.status_code, 200, r.json())
    r = c.get(f"/v1/restore/{key}/download", headers=AUTH)
    check("GET /v1/restore/{k}/download", r.status_code, 200, r.json())


def test_billing() -> None:
    print("\n== BILLING (auth bypassed via identity_validate) ==")
    c = TestClient(build_billing_app(identity_validate=lambda k: "acc_local"))
    r = c.get("/v1/billing/account", headers=AUTH)
    check("GET /v1/billing/account (pre)", r.status_code, 200, r.json())
    r = c.post("/v1/billing/purchase",
               json={"plan_id": "individual-100-30y", "payment_token": "tok"}, headers=AUTH)
    check("POST /v1/billing/purchase", r.status_code, 200, r.json())
    r = c.get("/v1/billing/account", headers=AUTH)
    check("GET /v1/billing/account (post)", r.status_code, 200, r.json())
    r = c.post("/internal/quota", json={"account_id": "acc_local", "size_bytes": 1000})
    check("POST /internal/quota", r.status_code, 200, r.json())


def main() -> None:
    print("=== NO-AUTH LOCAL HARNESS — ALL SERVICES ===")
    test_identity()
    test_ingest()
    test_metadata()
    test_restore()
    test_billing()
    print(f"\n\033[1mRESULT: {PASS} passed, {FAIL} failed\033[0m")


if __name__ == "__main__":
    main()
