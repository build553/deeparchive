#!/usr/bin/env bash
# Boot all 5 DeepArchive microservices locally, each as its own uvicorn process
# on its own port (see deeparchive/services/topology.py). Ctrl-C stops all.
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

pids=()
cleanup() { echo; echo "stopping..."; for p in "${pids[@]}"; do kill "$p" 2>/dev/null || true; done; }
trap cleanup EXIT INT TERM

boot() {  # boot <module:app> <port> <name>
  uvicorn "$1" --port "$2" --host 127.0.0.1 --log-level warning &
  pids+=($!)
  echo "  started $3 on :$2 (pid ${pids[-1]})"
}

echo "Booting DeepArchive microservices..."
boot "deeparchive.services.identity.main:app"    8001 identity
boot "deeparchive.services.billing_svc.asgi:app" 8002 billing
boot "deeparchive.services.ingest_svc.asgi:app"  8003 ingest
boot "deeparchive.services.restore_svc.asgi:app" 8004 restore
boot "deeparchive.services.metadata_svc.asgi:app" 8005 metadata
boot "deeparchive.services.gateway.asgi:app"     8000 gateway

echo
echo "All up. Gateway: http://127.0.0.1:8000/v1/health"
echo "Ctrl-C to stop."
wait
