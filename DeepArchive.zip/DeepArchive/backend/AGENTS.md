# AGENTS.md

Minimal, curated context for agentic development on DeepArchive.
(Mantle model: keep this small. Examples over rules. Small modules.)

## What this is
Ultra-low-cost archival storage on S3 Glacier Deep Archive. Pack many files into
~256MB tarballs (cold), keep a warm JSON index (which tarball + offset + hash),
retrieve within a 48h SLA.

## Rules of the codebase
- Small, single-purpose modules. Each understandable at a glance.
- Straight-line, obvious code. Avoid deep class hierarchies / clever indirection.
- Make illegal states hard: use dataclasses + Enums, not loose strings/dicts.
- Every new module mirrors the style of the last (examples > rules).
- Human reads, understands, and owns every line. Not vibe coding.

## Feedback loop (run after every change)
`bash scripts/check.sh` = ruff (lint) + mypy (strict types) + pytest.
Must be ALL GREEN before moving on. This is our "if it compiles, it works."

## Key settings
All in `deeparchive/config.py`: bucket, prefixes (data/ cold, db/ warm),
256MB packs, Bulk tier / 48h SLA.

## Layout
- `deeparchive/` core library (shared by CLI, SDK, server)
- `tests/` unit tests, one per module
- `server/` Axum-equivalent API (FastAPI), later
- `docs/api-contract.md` SDK + server API + manifest schema
