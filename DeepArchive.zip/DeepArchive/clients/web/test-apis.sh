#!/usr/bin/env bash
# API test harness — auto-provisions a key, then exercises every endpoint the
# live deployment supports, printing PASS/FAIL per call. No manual auth needed.
#
#   ./test-apis.sh                 # uses the baked-in endpoint
#   ALB=http://other-host ./test-apis.sh
set -uo pipefail

ALB="${ALB:-http://DeepAr-Alb16-5Y2jiGGVXJ3a-252734301.us-east-1.elb.amazonaws.com}"
PASS=0; FAIL=0

hdr() { printf "\n\033[1m== %s ==\033[0m\n" "$1"; }
check() { # check <label> <expected-code> <actual-code> [body]
  if [ "$2" = "$3" ]; then printf "  \033[32mPASS\033[0m %-34s %s\n" "$1" "$3"; PASS=$((PASS+1));
  else printf "  \033[31mFAIL\033[0m %-34s got %s want %s  %s\n" "$1" "$3" "$2" "${4:-}"; FAIL=$((FAIL+1)); fi
}
code() { curl -s -m 15 -o /tmp/da_body -w "%{http_code}" "$@"; }
body() { cat /tmp/da_body; }

hdr "Unauthenticated"
check "GET /v1/health" 200 "$(code "$ALB/v1/health")"

hdr "Register (provision a key)"
c=$(code -X POST "$ALB/v1/orgs" -H "Content-Type: application/json" \
  -d "{\"name\":\"apitest-$(date +%s)\",\"country\":\"US\",\"admin_user_ref\":\"t@x.com\"}")
check "POST /v1/orgs" 200 "$c" "$(body)"
KEY=$(body | python3 -c "import sys,json;print(json.load(sys.stdin).get('api_key',''))" 2>/dev/null)
ACCT=$(body | python3 -c "import sys,json;print(json.load(sys.stdin).get('account_id',''))" 2>/dev/null)
echo "  key=${KEY:0:14}…  acct=$ACCT"
AUTH=(-H "Authorization: Bearer $KEY")

hdr "Identity"
check "GET /v1/accounts/me" 200 "$(code "${AUTH[@]}" "$ALB/v1/accounts/me")"

hdr "Metadata (browse)"
check "GET /v1/catalog" 200 "$(code "${AUTH[@]}" "$ALB/v1/catalog")"
check "GET /v1/folders" 200 "$(code "${AUTH[@]}" "$ALB/v1/folders")"

hdr "Billing"
check "GET /v1/billing/account (pre)" 200 "$(code "${AUTH[@]}" "$ALB/v1/billing/account")"
check "POST /v1/billing/purchase" 200 \
  "$(code -X POST "${AUTH[@]}" -H "Content-Type: application/json" \
     -d '{"plan_id":"individual-100-30y","payment_token":"tok"}' "$ALB/v1/billing/purchase")" "$(body)"
check "GET /v1/billing/account (post)" 200 "$(code "${AUTH[@]}" "$ALB/v1/billing/account")"
echo "  after purchase: $(body)"

hdr "Ingest"
check "POST /v1/packs/upload-url" 200 \
  "$(code -X POST "${AUTH[@]}" -H "Content-Type: application/json" \
     -d "{\"tarball_key\":\"data/$ACCT/7y/p1.tar\"}" "$ALB/v1/packs/upload-url")"

hdr "Restore"
check "POST /v1/restore" 409 \
  "$(code -X POST "${AUTH[@]}" -H "Content-Type: application/json" \
     -d "{\"tarball_key\":\"data/$ACCT/7y/nope.tar\"}" "$ALB/v1/restore")"
# ^ 409 expected: object not yet in Deep Archive (nothing uploaded). Proves the
#   endpoint reached the restore service and handled it (not a 401/500).

hdr "Auth enforcement (should REJECT without key)"
check "GET /v1/catalog (no key)" 401 "$(code "$ALB/v1/catalog")"

printf "\n\033[1mRESULT: %d passed, %d failed\033[0m\n" "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
