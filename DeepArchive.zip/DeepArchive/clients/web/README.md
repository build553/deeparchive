# DeepArchive — Web UI

A single-file web console for DeepArchive. No build step, no dependencies —
just open `index.html` in a browser.

## What it does (all against the live API)
- **Sign in / register** — create an org (returns an API key, stored in the
  browser's localStorage) or paste an existing key.
- **Browse** — navigate folders and files in your archive (catalog + folders).
- **Restore** — click a file to request a 48h Glacier restore.
- **Account** — view plan status, quota, usage.
- **Purchase** — buy a plan (real plan IDs wired to the billing service).

## Run it

Just open the file:
```bash
open ~/deeparchive-web/index.html      # macOS
```

Then in the UI:
1. **Org name / email:** anything (e.g. "My Backups" / "me@example.com")
2. Click **Create / Access**.

The server endpoint is **baked into the app** (`API_ENDPOINT` constant at the top
of the `<script>`) — users never see or enter it. To point the app at a different
deployment, change that one constant.

## Important: HTTP vs HTTPS
The ALB currently serves **HTTP** (no cert yet). Browsers block "mixed content",
so:
- ✅ Opening this file via `file://` (double-click / `open`) → works, can call HTTP.
- ❌ Serving this page over `https://` → the browser blocks the HTTP API calls.

Once the ALB has HTTPS, this works from any https origin too.

## Endpoints used (all verified live)
- `POST /v1/orgs` — register
- `GET /v1/catalog?prefix=` — files
- `GET /v1/folders?prefix=` — folders
- `GET /v1/accounts/me` — account
- `GET /v1/billing/account` — plan/usage
- `POST /v1/billing/purchase` — buy plan
- `POST /v1/restore` — request restore
