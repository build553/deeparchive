// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "deeparchive-cli",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(
            name: "deeparchive",
            path: "Sources/deeparchive"
        )
    ]
)
