import Foundation

enum APIError: LocalizedError {
    case badURL
    case http(Int, String)
    case decoding(String)
    case transport(String)

    var errorDescription: String? {
        switch self {
        case .badURL: return "Invalid server URL."
        case let .http(code, body):
            if code == 401 { return "Not signed in or invalid API key (401)." }
            if code == 402 { return "No active plan or quota exceeded (402)." }
            if code == 409 { return "File not restored yet — request a restore first (409)." }
            return "Server error (\(code)): \(body)"
        case let .decoding(m): return "Could not read server response: \(m)"
        case let .transport(m): return "Network error: \(m)"
        }
    }
}

struct APIClient {
    let baseURL: URL
    let apiKey: String?

    init(endpoint: String, apiKey: String?) throws {
        guard let url = URL(string: endpoint) else { throw APIError.badURL }
        self.baseURL = url
        self.apiKey = apiKey
    }

    func register(name: String, country: String, adminRef: String) async throws -> RegisterResponse {
        try await send("POST", "/v1/orgs",
                       body: RegisterRequest(name: name, country: country, admin_user_ref: adminRef),
                       authed: false)
    }

    func catalog(prefix: String = "") async throws -> CatalogResponse {
        try await send("GET", "/v1/catalog\(query(prefix))")
    }

    func folders(prefix: String = "") async throws -> FoldersResponse {
        try await send("GET", "/v1/folders\(query(prefix))")
    }

    func requestRestore(tarballKey: String) async throws -> RestoreResponse {
        try await send("POST", "/v1/restore", body: RestoreRequest(tarball_key: tarballKey))
    }

    func account() async throws -> AccountResponse {
        try await send("GET", "/v1/billing/account")
    }

    func health() async throws -> [String: String] {
        try await send("GET", "/v1/health", authed: false)
    }

    // MARK: transport

    private func query(_ prefix: String) -> String {
        guard !prefix.isEmpty else { return "" }
        let enc = prefix.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return "?prefix=\(enc)"
    }

    private func send<T: Decodable>(_ method: String, _ path: String, authed: Bool = true) async throws -> T {
        try await send(method, path, body: Optional<Int>.none, authed: authed)
    }

    private func send<B: Encodable, T: Decodable>(_ method: String, _ path: String, body: B?, authed: Bool = true) async throws -> T {
        guard let url = URL(string: path, relativeTo: baseURL) else { throw APIError.badURL }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if authed, let key = apiKey, !key.isEmpty {
            req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        }
        if let body = body { req.httpBody = try JSONEncoder().encode(body) }

        let data: Data, response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: req)
        } catch {
            throw APIError.transport(error.localizedDescription)
        }
        guard let http = response as? HTTPURLResponse else { throw APIError.transport("no HTTP response") }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.http(http.statusCode, String(data: data, encoding: .utf8) ?? "")
        }
        do { return try JSONDecoder().decode(T.self, from: data) }
        catch { throw APIError.decoding("\(error)") }
    }
}
