import Foundation

/// DeepArchive CLI — runs today with `swift run` (no Xcode). Talks to the live ALB.
///
/// Usage:
///   deeparchive config <endpoint> [apiKey]     set server + optional key
///   deeparchive health                          check the server is up
///   deeparchive register <name> <country> <email>   create/resolve an org
///   deeparchive catalog [prefix]                list files
///   deeparchive folders [prefix]                list sub-folders
///   deeparchive restore <tarballKey>            request a 48h restore
///   deeparchive account                         show quota/usage
enum CLI {
    static func run() async {
        let args = Array(CommandLine.arguments.dropFirst())
        guard let cmd = args.first else { usage(); exit(1) }
        let rest = Array(args.dropFirst())
        var cfg = Config.load()

        do {
            switch cmd {
            case "config":
                guard let ep = rest.first else { print("usage: deeparchive config <endpoint> [apiKey]"); exit(1) }
                cfg.endpoint = ep
                if rest.count > 1 { cfg.apiKey = rest[1] }
                cfg.save()
                print("Saved. endpoint=\(cfg.endpoint) apiKey=\(cfg.apiKey.isEmpty ? "(none)" : "set")")

            case "health":
                let c = try client(cfg, authed: false)
                let h = try await c.health()
                print("OK: \(h)")

            case "register":
                guard rest.count >= 3 else { print("usage: deeparchive register <name> <country> <email>"); exit(1) }
                let c = try client(cfg, authed: false)
                let r = try await c.register(name: rest[0], country: rest[1], adminRef: rest[2])
                print("account_id: \(r.account_id)  new: \(r.new_account)")
                if let key = r.api_key {
                    cfg.apiKey = key; cfg.save()
                    print("API key saved to config.")
                } else {
                    print("Org already exists; set your key with: deeparchive config \(cfg.endpoint) <apiKey>")
                }

            case "catalog":
                let c = try client(cfg)
                let r = try await c.catalog(prefix: rest.first ?? "")
                print("\(r.count) file(s) under '\(r.prefix)':")
                for f in r.files { print("  \(f.fileName)  (\(f.humanSize))  [\(f.path)]") }

            case "folders":
                let c = try client(cfg)
                let r = try await c.folders(prefix: rest.first ?? "")
                print("folders under '\(r.prefix)': \(r.folders.isEmpty ? "(none)" : r.folders.joined(separator: ", "))")

            case "restore":
                guard let key = rest.first else { print("usage: deeparchive restore <tarballKey>"); exit(1) }
                let c = try client(cfg)
                let r = try await c.requestRestore(tarballKey: key)
                print("state: \(r.state)" + (r.sla_hours.map { "  sla: \($0)h" } ?? ""))
                if let rid = r.request_id { print("pending approval, request_id: \(rid)") }

            case "account":
                let c = try client(cfg)
                let a = try await c.account()
                func b(_ v: Int?) -> String { v.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) } ?? "—" }
                print("quota: \(b(a.quota_bytes))  used: \(b(a.used_bytes))  remaining: \(b(a.remaining_bytes))  egress: \(b(a.egress_bytes))")

            case "-h", "--help", "help":
                usage()

            default:
                print("Unknown command: \(cmd)"); usage(); exit(1)
            }
        } catch {
            let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
            FileHandle.standardError.write(Data(("Error: " + msg + "\n").utf8))
            exit(1)
        }
    }

    static func client(_ cfg: Config, authed: Bool = true) throws -> APIClient {
        guard !cfg.endpoint.isEmpty else {
            throw APIError.transport("No endpoint set. Run: deeparchive config <endpoint> [apiKey]")
        }
        return try APIClient(endpoint: cfg.endpoint, apiKey: authed ? cfg.apiKey : nil)
    }

    static func usage() {
        print("""
        DeepArchive CLI
          deeparchive config <endpoint> [apiKey]
          deeparchive health
          deeparchive register <name> <country> <email>
          deeparchive catalog [prefix]
          deeparchive folders [prefix]
          deeparchive restore <tarballKey>
          deeparchive account
        """)
    }
}

// Top-level entry (main.swift supports top-level code + await).
await CLI.run()
