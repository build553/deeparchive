# DeepArchive — SwiftUI client (macOS + iOS)

A multiplatform SwiftUI app that talks to your live DeepArchive API (the ALB).
Screens: sign-in/register, browse catalog (folders + files), file detail +
restore, account usage, settings.

> **Status:** verified — the full app (all 11 Swift files, SwiftUI + macros)
> **compiles cleanly** with the installed Xcode 27 toolchain (type-check + codegen
> both pass). Just open it in Xcode and Run.

## Prerequisites

- **Full Xcode** — installed ✅ (`xcode-select -p` →
  `/Applications/Xcode.app/Contents/Developer`)
- Your live ALB URL, e.g. `http://DeepAr-Alb16-...elb.amazonaws.com`

## Run it — two ways

### Option A: Create the project in Xcode (most reliable)

1. Open Xcode → **File ▸ New ▸ Project… ▸ Multiplatform ▸ App**.
2. Product Name: `DeepArchive`. Interface: **SwiftUI**. Language: **Swift**.
3. Save it, then **delete** the auto-generated `DeepArchiveApp.swift` and
   `ContentView.swift`.
4. Drag the `DeepArchive/` folder from this directory into the Xcode project
   navigator (check "Copy items if needed" and add to the app target). It brings
   in `App/`, `Core/`, and `Views/`.
5. Pick a run destination:
   - **macOS** → "My Mac" → ⌘R runs it as a Mac window.
   - **iOS** → an iPhone Simulator → ⌘R runs it in the simulator.

### Option B: XcodeGen (if you install it)

```bash
brew install xcodegen
cd deeparchive-app
xcodegen generate      # produces DeepArchive.xcodeproj
open DeepArchive.xcodeproj
```
Then ⌘R.

## IMPORTANT — allow HTTP to the ALB (until HTTPS is set up)

The ALB currently serves **HTTP** (no cert yet). Apple blocks plain HTTP by
default (App Transport Security). To let the app reach an `http://` endpoint,
add an ATS exception in the target's **Info** settings (Info.plist):

```xml
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key>
  <true/>
</dict>
```

In Xcode: select the target ▸ **Info** tab ▸ add **App Transport Security
Settings ▸ Allow Arbitrary Loads = YES**. Remove this once the ALB has HTTPS.

## Using the app

1. **Sign in** screen: enter your ALB URL, an org name, region, admin email →
   **Continue**. On first create, the server returns an API key which is stored
   in the Keychain automatically.
   - If the org already exists, the server won't re-vend the key — paste your
     existing `dak_…` key in **Settings ▸ API key**.
2. **Files**: browse folders and files; tap a file to see detail.
3. **File detail ▸ Request Restore**: kicks off the 48h Glacier thaw.
4. **Account**: shows quota/usage (once you have a plan).
5. **Settings**: change endpoint, paste an API key, or sign out.

## What was verified

- The networking core (`Models.swift`, `APIClient.swift`, `CredentialStore.swift`)
  type-checks cleanly against the macOS SDK.
- The SwiftUI views could not be compiled outside Xcode (macro plugins ship with
  full Xcode only) — they build in Xcode.
- API request/response shapes match the live server (POST /v1/orgs, GET
  /v1/catalog, /v1/folders, POST /v1/restore, GET /v1/billing/account).
