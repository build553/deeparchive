import SwiftUI

/// Clean, modern signup in the familiar cloud-storage style: a friendly
/// heading, social sign-in buttons, a divider, and a minimal name/email form.
/// DeepArchive-branded (not a copy of any other product's page).
struct SignInView: View {
    @EnvironmentObject var session: Session

    @State private var mode: Mode = .create
    @State private var country = "US"
    @State private var email = ""
    @State private var apiKeyField = ""
    @State private var busy = false
    @State private var error: String?
    @State private var info: String?
    @State private var devEndpoint = ""
    @State private var showDev = false

    private enum Mode: String, CaseIterable { case create = "Sign up", access = "Sign in" }
    private let countries = ["US", "IN", "DE", "FR", "IE"]

    var body: some View {
        #if os(macOS)
        HStack(spacing: 0) { brandPanel; formPanel }
        #else
        ScrollView { VStack(spacing: 0) { brandHeaderCompact; formPanel } }
            .background(Theme.bg)
        #endif
    }

    // MARK: Left brand panel (macOS) — the marketing side.
    private var brandPanel: some View {
        ZStack {
            Theme.heroGradient
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 10) {
                    Image(systemName: "archivebox.fill").font(.title)
                    Text("DeepArchive").font(.title2.bold())
                }
                .foregroundStyle(.white)
                Spacer()
                Text("Keep everything.\nForever.")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("Your photos and files, safely archived for 30 years — at a fraction of the cost of consumer cloud.")
                    .font(.title3).foregroundStyle(.white.opacity(0.9))
                Spacer()
                ForEach(["Encrypted end to end", "Region-resident storage", "30-year durability"], id: \.self) { line in
                    Label(line, systemImage: "checkmark.circle.fill").foregroundStyle(.white.opacity(0.95))
                }
                Spacer()
            }
            .padding(40)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(width: 380)
    }

    private var brandHeaderCompact: some View {
        ZStack {
            Theme.heroGradient
            VStack(spacing: 8) {
                Image(systemName: "archivebox.fill").font(.system(size: 40)).foregroundStyle(.white)
                Text("DeepArchive").font(.title.bold()).foregroundStyle(.white)
                Text("Keep everything. Forever.").foregroundStyle(.white.opacity(0.9))
            }.padding(.vertical, 40)
        }
    }

    // MARK: Right form panel — the signup.
    private var formPanel: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(mode == .create ? "Create your account" : "Welcome back")
                    .font(.largeTitle.bold())
                Text(mode == .create ? "Start archiving in seconds." : "Sign in to your archive.")
                    .foregroundStyle(.secondary)

                // Social sign-in (visual; wire real providers later).
                VStack(spacing: 10) {
                    socialButton("Continue with Apple", "apple.logo", .primary, Theme.bg)
                    socialButton("Continue with Google", "g.circle.fill", Theme.bg, .primary, bordered: true)
                }

                dividerOr

                if mode == .create {
                    labeledField("Email") {
                        TextField("you@example.com", text: $email)
                            .textFieldStyle(.plain).autocorrectionDisabled()
                            #if os(iOS)
                            .textInputAutocapitalization(.never).keyboardType(.emailAddress)
                            #endif
                    }
                    labeledField("Region") {
                        Picker("", selection: $country) {
                            ForEach(countries, id: \.self) { Text($0) }
                        }.labelsHidden()
                    }
                } else {
                    labeledField("API key") {
                        SecureField("dak_…", text: $apiKeyField).textFieldStyle(.plain)
                    }
                }

                if let error { note(error, .red, "exclamationmark.triangle.fill") }
                if let info { note(info, Theme.brand, "info.circle.fill") }

                PrimaryButton(
                    title: mode == .create ? "Create account" : "Sign in",
                    loading: busy, action: submit
                )
                .disabled(!canSubmit).opacity(canSubmit ? 1 : 0.6)

                // Toggle between sign up / sign in.
                HStack(spacing: 4) {
                    Text(mode == .create ? "Already have a key?" : "New here?")
                        .foregroundStyle(.secondary)
                    Button(mode == .create ? "Sign in" : "Sign up") {
                        withAnimation { mode = mode == .create ? .access : .create; error = nil; info = nil }
                    }
                    .buttonStyle(.plain).foregroundStyle(Theme.brand).fontWeight(.semibold)
                }
                .font(.subheadline)

                if AppConfig.allowEndpointOverride {
                    DisclosureGroup("Developer", isExpanded: $showDev) {
                        labeledField("Server (dev only)") {
                            TextField(AppConfig.defaultEndpoint, text: $devEndpoint)
                                .textFieldStyle(.plain).autocorrectionDisabled()
                                #if os(iOS)
                                .textInputAutocapitalization(.never).keyboardType(.URL)
                                #endif
                        }
                    }.font(.caption).tint(.secondary)
                }
            }
            .padding(40)
            .frame(maxWidth: 460)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .background(Theme.bg)
    }

    private var dividerOr: some View {
        HStack {
            Rectangle().fill(.secondary.opacity(0.25)).frame(height: 1)
            Text("or").font(.caption).foregroundStyle(.secondary)
            Rectangle().fill(.secondary.opacity(0.25)).frame(height: 1)
        }
    }

    private func socialButton(_ title: String, _ icon: String, _ fg: Color, _ bg: Color, bordered: Bool = false) -> some View {
        Button {
            // Placeholder: real Apple/Google sign-in wires here later.
            info = "Social sign-in coming soon — use Sign up (email) for now."
        } label: {
            HStack {
                Image(systemName: icon)
                Text(title).fontWeight(.medium)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 13)
            .foregroundStyle(fg).background(bg)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(.secondary.opacity(bordered ? 0.3 : 0), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func labeledField<C: View>(_ title: String, width: CGFloat? = nil, @ViewBuilder content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            content()
                .padding(12).background(Theme.subtle)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(.secondary.opacity(0.15), lineWidth: 1))
        }
        .frame(width: width)
    }

    private func note(_ text: String, _ color: Color, _ icon: String) -> some View {
        Label(text, systemImage: icon).font(.footnote).foregroundStyle(color)
    }

    private var canSubmit: Bool {
        mode == .create ? !email.isEmpty : !apiKeyField.isEmpty
    }

    private func submit() {
        error = nil; info = nil; busy = true
        if AppConfig.allowEndpointOverride && !devEndpoint.isEmpty { session.setEndpoint(devEndpoint) }
        Task {
            defer { busy = false }
            if mode == .access {
                session.signIn(apiKey: apiKeyField, accountId: session.accountId ?? "")
                return
            }
            guard let client = session.client(authed: false) else { error = "Something went wrong."; return }
            do {
                // Derive the account name from the email local-part (backend
                // still stores a name; the customer no longer types one).
                let derivedName = email.split(separator: "@").first.map(String.init) ?? "My Archive"
                let resp = try await client.register(name: derivedName, country: country, adminRef: email)
                if let key = resp.api_key {
                    session.signIn(apiKey: key, accountId: resp.account_id)
                } else {
                    info = "This workspace already exists. Switch to Sign in and paste your API key."
                }
            } catch {
                self.error = (error as? APIError)?.errorDescription ?? error.localizedDescription
            }
        }
    }
}
