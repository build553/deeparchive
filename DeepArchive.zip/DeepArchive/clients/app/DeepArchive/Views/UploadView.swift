import SwiftUI
import UniformTypeIdentifiers

/// Upload flow: pick a file, then archive it. Shows progress and result.
/// (Client-side packing is simplified here — it uploads the chosen file's bytes
/// to a presigned S3 URL under the account's data prefix.)
struct UploadView: View {
    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss

    @State private var picking = false
    @State private var fileName: String?
    @State private var fileData: Data?
    @State private var busy = false
    @State private var done = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 24) {
            Capsule().fill(.secondary.opacity(0.4)).frame(width: 40, height: 5).padding(.top, 8)

            VStack(spacing: 8) {
                ZStack {
                    Circle().fill(Theme.brand.opacity(0.12)).frame(width: 88, height: 88)
                    Image(systemName: done ? "checkmark.circle.fill" : "arrow.up.doc.fill")
                        .font(.system(size: 38))
                        .foregroundStyle(done ? Theme.mint : Theme.brand)
                }
                Text(done ? "Archived!" : "Upload to DeepArchive")
                    .font(.title2.bold())
                Text(done
                     ? "Your file is safely stored in cold archival."
                     : "Choose a file to archive. It’s encrypted and kept for 30 years.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            if let fileName {
                Card {
                    HStack(spacing: 12) {
                        let g = FileGlyph.icon(for: fileName)
                        Image(systemName: g.name).foregroundStyle(g.color).font(.title2)
                        VStack(alignment: .leading) {
                            Text(fileName).lineLimit(1).fontWeight(.medium)
                            if let d = fileData {
                                Text(ByteCountFormatter.string(fromByteCount: Int64(d.count), countStyle: .file))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                    }
                }
            }

            if let error {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .font(.footnote).foregroundStyle(.red)
            }

            Spacer()

            VStack(spacing: 12) {
                if !done {
                    Button {
                        picking = true
                    } label: {
                        Label(fileName == nil ? "Choose file" : "Choose a different file", systemImage: "folder")
                            .frame(maxWidth: .infinity).padding(.vertical, 12)
                            .background(Theme.subtle).clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)

                    PrimaryButton(title: "Archive now", systemImage: "lock.fill", loading: busy, action: upload)
                        .disabled(fileData == nil || busy)
                        .opacity(fileData == nil ? 0.6 : 1)
                } else {
                    PrimaryButton(title: "Done", action: { dismiss() })
                }
            }
            .frame(maxWidth: 420)
        }
        .padding(24)
        .fileImporter(isPresented: $picking, allowedContentTypes: [.item]) { result in
            if case let .success(url) = result { loadFile(url) }
        }
    }

    private func loadFile(_ url: URL) {
        error = nil
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            fileData = try Data(contentsOf: url)
            fileName = url.lastPathComponent
        } catch {
            self.error = "Could not read file: \(error.localizedDescription)"
        }
    }

    private func upload() {
        guard let data = fileData, let name = fileName,
              let client = session.client(), let acct = session.accountId, !acct.isEmpty
        else { error = "Not ready to upload."; return }
        busy = true; error = nil
        Task {
            defer { busy = false }
            do {
                // Key under the account's data prefix (matches server ownership check).
                let key = "data/\(acct)/uploads/\(name).tar"
                let presigned = try await client.uploadURL(tarballKey: key)
                try await client.putToPresigned(presigned.url, data: data)
                done = true
            } catch {
                self.error = (error as? APIError)?.errorDescription ?? error.localizedDescription
            }
        }
    }
}
