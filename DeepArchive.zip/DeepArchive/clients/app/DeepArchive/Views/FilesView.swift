import SwiftUI

/// Dropbox-style file browser: folder + file rows with type icons, a breadcrumb
/// path, drill-down into folders, and navigation to file detail.
struct FilesView: View {
    @EnvironmentObject var session: Session
    @StateObject private var store = LibraryStore(session: Session())
    @State private var prefix = ""
    @State private var showUpload = false

    var body: some View {
        List {
            if !prefix.isEmpty {
                breadcrumb
            }
            if !store.folders.isEmpty {
                Section("Folders") {
                    ForEach(store.folders, id: \.self) { folder in
                        Button { drill(into: folder) } label: { folderRow(folder) }
                            .buttonStyle(.plain)
                    }
                }
            }
            Section(store.documents.isEmpty ? "" : "Files") {
                if store.documents.isEmpty && !store.loading {
                    EmptyState(
                        icon: "folder",
                        title: "Nothing here yet",
                        message: "Tap + to upload documents and files to your archive."
                    )
                    .listRowSeparator(.hidden)
                }
                ForEach(store.documents) { file in
                    NavigationLink(value: file) { fileRow(file) }
                }
            }
        }
        .listStyle(.inset)
        .navigationTitle(prefix.isEmpty ? "Files" : folderName(prefix))
        .navigationDestination(for: CatalogEntry.self) { FileDetailView(file: $0) }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showUpload = true } label: {
                    Image(systemName: "plus.circle.fill").font(.title2).foregroundStyle(Theme.brand)
                }
            }
        }
        .sheet(isPresented: $showUpload) { UploadView().environmentObject(session) }
        .overlay { if store.loading { ProgressView() } }
        .refreshable { await store.load(prefix: prefix) }
        .task { store.attach(session); await store.load(prefix: prefix) }
    }

    private var breadcrumb: some View {
        HStack(spacing: 6) {
            Button { prefix = ""; Task { await store.load() } } label: {
                Image(systemName: "house.fill")
            }
            .buttonStyle(.plain).foregroundStyle(Theme.brand)
            Text("/ " + prefix).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            Spacer()
            Button("Up") { goUp() }.font(.caption).foregroundStyle(Theme.brand)
        }
        .listRowBackground(Color.clear)
    }

    private func folderRow(_ folder: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "folder.fill").foregroundStyle(Theme.accent).font(.title3)
            Text(folder).fontWeight(.medium)
            Spacer()
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 4)
    }

    private func fileRow(_ file: CatalogEntry) -> some View {
        let glyph = FileGlyph.icon(for: file.path)
        return HStack(spacing: 12) {
            Image(systemName: glyph.name).foregroundStyle(glyph.color).font(.title3).frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(file.fileName).lineLimit(1)
                Text(file.humanSize).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "snowflake").font(.caption2).foregroundStyle(.blue.opacity(0.6))
        }
        .padding(.vertical, 4)
    }

    private func drill(into folder: String) {
        prefix = prefix.isEmpty ? "\(folder)/" : "\(prefix)\(folder)/"
        Task { await store.load(prefix: prefix) }
    }
    private func goUp() {
        var parts = prefix.split(separator: "/").map(String.init)
        if !parts.isEmpty { parts.removeLast() }
        prefix = parts.isEmpty ? "" : parts.joined(separator: "/") + "/"
        Task { await store.load(prefix: prefix) }
    }
    private func folderName(_ p: String) -> String {
        p.split(separator: "/").last.map(String.init) ?? "Files"
    }
}
