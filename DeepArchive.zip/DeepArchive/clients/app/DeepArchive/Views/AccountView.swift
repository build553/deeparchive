import SwiftUI

/// Polished account screen: usage ring/bar, plan info, endpoint, sign out.
struct AccountView: View {
    @EnvironmentObject var session: Session
    @State private var account: AccountResponse?
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                profileHeader
                usageCard
                Card {
                    VStack(spacing: 0) {
                        infoRow("Plan", "30-year archival", "calendar")
                        Divider()
                        infoRow("Workspace", session.accountId ?? "—", "number")
                    }
                }
                Button(role: .destructive) { session.signOut() } label: {
                    Label("Sign out", systemImage: "rectangle.portrait.and.arrow.right")
                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(Color.red.opacity(0.1))
                        .foregroundStyle(.red)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                if let error {
                    Text(error).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .padding()
            .frame(maxWidth: 480)
            .frame(maxWidth: .infinity)
        }
        .background(Theme.bg)
        .navigationTitle("Account")
        .task { await load() }
        .refreshable { await load() }
    }

    private var profileHeader: some View {
        VStack(spacing: 10) {
            ZStack {
                Circle().fill(Theme.brandGradient).frame(width: 84, height: 84)
                Image(systemName: "person.fill").font(.system(size: 38)).foregroundStyle(.white)
            }
            Text(session.accountId ?? "Your workspace")
                .font(.headline).lineLimit(1)
            Text("30-year archival · encrypted")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding(.top, 8)
    }

    private var usageCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Label("Storage", systemImage: "internaldrive.fill")
                    .font(.headline)
                if let a = account, let q = a.quota_bytes, q > 0 {
                    let used = a.used_bytes ?? 0
                    let frac = min(1.0, Double(used) / Double(q))
                    ProgressView(value: frac)
                        .tint(frac > 0.9 ? .red : Theme.brand)
                    HStack {
                        Text("\(bytes(used)) used").font(.caption)
                        Spacer()
                        Text("\(bytes(q)) total").font(.caption).foregroundStyle(.secondary)
                    }
                } else if busy {
                    ProgressView()
                } else {
                    Text("No active plan yet. Purchase storage to start archiving.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
        }
    }

    private func infoRow(_ k: String, _ v: String, _ icon: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).foregroundStyle(Theme.brand).frame(width: 24)
            Text(k).foregroundStyle(.secondary)
            Spacer()
            Text(v).lineLimit(1).truncationMode(.middle)
        }
        .font(.subheadline).padding(.vertical, 8)
    }

    private func bytes(_ v: Int?) -> String {
        guard let v else { return "—" }
        return ByteCountFormatter.string(fromByteCount: Int64(v), countStyle: .file)
    }

    private func load() async {
        guard let client = session.client() else { return }
        busy = true; error = nil
        defer { busy = false }
        do { account = try await client.account() }
        catch { self.error = (error as? APIError)?.errorDescription ?? error.localizedDescription }
    }
}
