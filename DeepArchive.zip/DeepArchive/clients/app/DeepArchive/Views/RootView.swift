import SwiftUI

/// Routes between onboarding and the main app.
struct RootView: View {
    @EnvironmentObject var session: Session
    var body: some View {
        if session.isSignedIn {
            HomeView()
        } else {
            SignInView()
        }
    }
}

/// Main app shell: Photos grid + Files browser + Account, with a branded bar
/// and a prominent upload button. Tabs on iOS, a clean tabbed layout on macOS.
struct HomeView: View {
    @EnvironmentObject var session: Session
    @State private var showUpload = false

    var body: some View {
        TabView {
            NavigationStack { PhotosView() }
                .tabItem { Label("Photos", systemImage: "photo.on.rectangle.angled") }

            NavigationStack { FilesView() }
                .tabItem { Label("Files", systemImage: "folder.fill") }

            NavigationStack { AccountView() }
                .tabItem { Label("Account", systemImage: "person.crop.circle.fill") }
        }
        .tint(Theme.brand)
    }
}
