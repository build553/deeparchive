import SwiftUI

/// Polished file detail: a hero preview header, metadata cards, and a restore
/// action styled as a clear call-to-action.
struct FileDetailView: View {
    @EnvironmentObject var session: Session
    let file: CatalogEntry

    @State private var busy = false
    @State private var state: String?
    @State private var message: String?
    @State private var error: String?

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                hero
                metadata
                restoreCard
                if let error {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote).foregroundStyle(.red)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding()
            .frame(maxWidth: 520)
            .frame(maxWidth: .infinity)
        }
        .background(Theme.bg)
        .navigationTitle(file.fileName)
        #if os(iOS)
        .navigationBarTitleDisplayMode(.inline)
        #endif
    }

    private var hero: some View {
        let glyph = FileGlyph.icon(for: file.path)
        return ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(FileGlyph.isImage(file.path) ? AnyShapeStyle(Theme.heroGradient) : AnyShapeStyle(glyph.color.opacity(0.15)))
                .frame(height: 200)
            Image(systemName: glyph.name)
                .font(.system(size: 72))
                .foregroundStyle(FileGlyph.isImage(file.path) ? .white : glyph.color)
        }
    }

    private var metadata: some View {
        Card {
            VStack(spacing: 0) {
                row("Name", file.fileName)
                Divider()
                row("Size", file.humanSize)
                Divider()
                row("Location", file.path)
                if let r = file.retention { Divider(); row("Retention", r) }
                Divider()
                row("Encrypted", (file.encrypted ?? false) ? "Yes" : "No")
            }
        }
    }

    private var restoreCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 12) {
                Label("Cold storage", systemImage: "snowflake")
                    .font(.headline).foregroundStyle(.blue)
                Text("This file is archived in Glacier Deep Archive. Request a restore to make it downloadable within ~48 hours.")
                    .font(.subheadline).foregroundStyle(.secondary)
                if let state {
                    Label("State: \(state)", systemImage: "clock.fill")
                        .font(.subheadline).foregroundStyle(Theme.brand)
                }
                if let message {
                    Text(message).font(.footnote).foregroundStyle(.secondary)
                }
                PrimaryButton(title: "Request Restore", systemImage: "clock.arrow.circlepath", loading: busy, action: restore)
            }
        }
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack {
            Text(k).foregroundStyle(.secondary)
            Spacer()
            Text(v).multilineTextAlignment(.trailing).lineLimit(2)
        }
        .font(.subheadline)
        .padding(.vertical, 8)
    }

    private func restore() {
        guard let client = session.client() else { return }
        busy = true; error = nil; message = nil
        Task {
            defer { busy = false }
            do {
                let resp = try await client.requestRestore(tarballKey: file.tarball_key)
                state = resp.state
                message = resp.state == "PENDING_APPROVAL"
                    ? "This restore is large and needs admin approval before it starts."
                    : "Restore requested. Check back in up to \(resp.sla_hours ?? 48) hours."
            } catch {
                self.error = (error as? APIError)?.errorDescription ?? error.localizedDescription
            }
        }
    }
}
