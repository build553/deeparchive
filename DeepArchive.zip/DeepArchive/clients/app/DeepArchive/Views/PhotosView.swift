import SwiftUI

/// Google-Photos-style grid of image thumbnails. Because files live in cold
/// Glacier storage, thumbnails show a placeholder tile with the file name and a
/// "restore to view" affordance — honest about the archival model while still
/// giving the visual grid experience.
struct PhotosView: View {
    @EnvironmentObject var session: Session
    @StateObject private var store: LibraryStore
    @State private var showUpload = false

    init() {
        // StateObject needs a value at init; real session is injected via env,
        // so we build the store lazily in .task using the environment session.
        _store = StateObject(wrappedValue: LibraryStore(session: Session()))
    }

    private let columns = [GridItem(.adaptive(minimum: 110), spacing: 4)]

    var body: some View {
        ScrollView {
            if store.photos.isEmpty && !store.loading {
                EmptyState(
                    icon: "photo.on.rectangle.angled",
                    title: "No photos yet",
                    message: "Upload photos to keep them safe. They’re archived to ultra-low-cost cold storage."
                )
            } else {
                LazyVGrid(columns: columns, spacing: 4) {
                    ForEach(store.photos) { photo in
                        NavigationLink(value: photo) {
                            PhotoTile(entry: photo)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(4)
            }
        }
        .background(Theme.bg)
        .navigationTitle("Photos")
        .navigationDestination(for: CatalogEntry.self) { FileDetailView(file: $0) }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showUpload = true } label: {
                    Image(systemName: "plus.circle.fill").font(.title2).foregroundStyle(Theme.brand)
                }
            }
        }
        .sheet(isPresented: $showUpload) { UploadView().environmentObject(session) }
        .overlay { if store.loading { ProgressView() } }
        .refreshable { await store.load() }
        .task { store.attach(session); await store.load() }
    }
}

/// One square photo tile — gradient placeholder + filename, with a small cold
/// badge (real thumbnails would come from the warm thumbnail store later).
struct PhotoTile: View {
    let entry: CatalogEntry
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Rectangle()
                .fill(Theme.heroGradient.opacity(0.85))
                .aspectRatio(1, contentMode: .fill)
            Image(systemName: "photo.fill")
                .font(.system(size: 30))
                .foregroundStyle(.white.opacity(0.55))
            LinearGradient(colors: [.clear, .black.opacity(0.45)], startPoint: .center, endPoint: .bottom)
            HStack(spacing: 4) {
                Image(systemName: "snowflake").font(.system(size: 9))
                Text(entry.fileName).lineLimit(1).font(.system(size: 10, weight: .medium))
            }
            .foregroundStyle(.white)
            .padding(6)
        }
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}
