import SwiftUI

/// DeepArchive client — ultra-low-cost 30-year archival, in your pocket.
///
/// Multiplatform SwiftUI app (macOS + iOS). Talks to the live DeepArchive ALB.
@main
struct DeepArchiveApp: App {
    @StateObject private var session = Session()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
        }
        #if os(macOS)
        .defaultSize(width: 900, height: 640)
        #endif
    }
}
