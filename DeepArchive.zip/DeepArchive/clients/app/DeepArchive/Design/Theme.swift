import SwiftUI

/// The DeepArchive design system: brand colors, gradients, typography, spacing.
/// One place to tune the look so the whole app stays consistent and polished.
enum Theme {
    // Brand palette — a deep "archival" indigo/teal with warm accent.
    static let brand = Color(red: 0.30, green: 0.36, blue: 0.92)      // indigo
    static let brandDark = Color(red: 0.16, green: 0.20, blue: 0.55)
    static let accent = Color(red: 0.98, green: 0.62, blue: 0.30)     // warm amber
    static let mint = Color(red: 0.20, green: 0.78, blue: 0.66)

    static let brandGradient = LinearGradient(
        colors: [brand, brandDark],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    static let heroGradient = LinearGradient(
        colors: [brand, Color(red: 0.55, green: 0.30, blue: 0.88), mint],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    // Surfaces
    #if os(iOS)
    static let card = Color(.secondarySystemBackground)
    static let bg = Color(.systemBackground)
    static let subtle = Color(.tertiarySystemBackground)
    #else
    static let card = Color(nsColor: .controlBackgroundColor)
    static let bg = Color(nsColor: .windowBackgroundColor)
    static let subtle = Color(nsColor: .underPageBackgroundColor)
    #endif

    static let corner: CGFloat = 16
    static let spacing: CGFloat = 16
}

// MARK: - Reusable components

/// A primary, full-width branded button.
struct PrimaryButton: View {
    let title: String
    var systemImage: String? = nil
    var loading: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if loading {
                    ProgressView().tint(.white)
                } else {
                    if let systemImage { Image(systemName: systemImage) }
                    Text(title).fontWeight(.semibold)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Theme.brandGradient)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
        .disabled(loading)
    }
}

/// A soft card container.
struct Card<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(Theme.spacing)
            .background(Theme.card)
            .clipShape(RoundedRectangle(cornerRadius: Theme.corner))
            .shadow(color: .black.opacity(0.06), radius: 8, y: 2)
    }
}

/// A friendly empty-state placeholder.
struct EmptyState: View {
    let icon: String
    let title: String
    let message: String
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 44))
                .foregroundStyle(Theme.brand.opacity(0.7))
            Text(title).font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: 320)
        .padding(.vertical, 40)
    }
}

/// Maps a file path to an SF Symbol + tint by extension.
enum FileGlyph {
    static func icon(for path: String) -> (name: String, color: Color) {
        let ext = (path as NSString).pathExtension.lowercased()
        switch ext {
        case "jpg", "jpeg", "png", "gif", "heic", "webp":
            return ("photo.fill", Theme.mint)
        case "mp4", "mov", "avi", "mkv":
            return ("video.fill", Theme.accent)
        case "pdf": return ("doc.richtext.fill", .red)
        case "zip", "tar", "gz", "7z": return ("archivebox.fill", .brown)
        case "doc", "docx", "txt", "md", "rtf": return ("doc.text.fill", Theme.brand)
        case "xls", "xlsx", "csv": return ("tablecells.fill", .green)
        case "mp3", "wav", "flac", "aac": return ("music.note", .purple)
        default: return ("doc.fill", .gray)
        }
    }

    static func isImage(_ path: String) -> Bool {
        let ext = (path as NSString).pathExtension.lowercased()
        return ["jpg", "jpeg", "png", "gif", "heic", "webp"].contains(ext)
    }
}
