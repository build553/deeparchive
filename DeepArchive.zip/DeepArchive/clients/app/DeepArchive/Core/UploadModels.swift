import Foundation

/// POST /v1/packs/upload-url  ->  a presigned S3 URL to PUT the tarball to.
struct UploadUrlRequest: Encodable {
    let tarball_key: String
}

struct UploadUrlResponse: Decodable {
    let url: String
    let tarball_key: String
}

extension APIClient {
    /// Ask the ingest service for a presigned upload URL for a given key.
    func uploadURL(tarballKey: String) async throws -> UploadUrlResponse {
        try await postJSON("/v1/packs/upload-url", body: UploadUrlRequest(tarball_key: tarballKey))
    }

    /// PUT raw bytes to a presigned S3 URL (no auth header — the URL is signed).
    func putToPresigned(_ urlString: String, data: Data) async throws {
        guard let url = URL(string: urlString) else { throw APIError.badURL }
        var req = URLRequest(url: url)
        req.httpMethod = "PUT"
        req.httpBody = data
        let (_, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError.transport("upload failed")
        }
    }
}
