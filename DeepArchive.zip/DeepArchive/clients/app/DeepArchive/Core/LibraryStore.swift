import Combine
import Foundation

/// Loads the catalog and exposes it split into photos (images) and everything
/// else, plus folder navigation. Shared by the Photos and Files screens.
@MainActor
final class LibraryStore: ObservableObject {
    @Published var entries: [CatalogEntry] = []
    @Published var folders: [String] = []
    @Published var loading = false
    @Published var error: String?

    private var session: Session

    init(session: Session) { self.session = session }

    /// Re-point at the environment's real session (StateObject is built before
    /// the environment is available, so views call this in .task).
    func attach(_ session: Session) { self.session = session }

    var photos: [CatalogEntry] { entries.filter { FileGlyph.isImage($0.path) } }
    var documents: [CatalogEntry] { entries.filter { !FileGlyph.isImage($0.path) } }

    func load(prefix: String = "") async {
        guard let client = session.client() else { return }
        loading = true; error = nil
        defer { loading = false }
        do {
            async let f = client.folders(prefix: prefix)
            async let c = client.catalog(prefix: prefix)
            folders = try await f.folders
            entries = try await c.files
        } catch {
            self.error = (error as? APIError)?.errorDescription ?? error.localizedDescription
        }
    }
}
