import Foundation

// MARK: - Request / response models matching the live DeepArchive API.

/// POST /v1/orgs  ->  register or resolve an org account.
struct RegisterRequest: Encodable {
    let name: String
    let country: String
    let admin_user_ref: String
}

struct RegisterResponse: Decodable {
    let account_id: String
    let api_key: String?      // present only when a NEW account is created
    let new_account: Bool
}

/// GET /v1/catalog?prefix=  ->  browsable file listing.
struct CatalogEntry: Decodable, Identifiable, Hashable {
    let path: String
    let size: Int
    let modified: String?
    let retention: String?
    let legal_hold: Bool?
    let encrypted: Bool?
    let tarball_key: String
    let offset: Int
    let pack_id: String

    var id: String { path }

    var fileName: String { (path as NSString).lastPathComponent }
    var humanSize: String {
        ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }
}

struct CatalogResponse: Decodable {
    let prefix: String
    let count: Int
    let files: [CatalogEntry]
}

/// GET /v1/folders?prefix=  ->  immediate sub-folders (tree navigation).
struct FoldersResponse: Decodable {
    let prefix: String
    let folders: [String]
}

/// POST /v1/restore  ->  request a 48h Glacier restore.
struct RestoreRequest: Encodable {
    let tarball_key: String
}

struct RestoreResponse: Decodable {
    let tarball_key: String
    let state: String
    let sla_hours: Int?
    let request_id: String?   // present when the restore is PENDING_APPROVAL
}

/// GET /v1/billing/account  ->  plan + usage.
struct AccountResponse: Decodable {
    let quota_bytes: Int?
    let used_bytes: Int?
    let remaining_bytes: Int?
    let egress_bytes: Int?
    let expires_at: Double?
}
