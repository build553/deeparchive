import Foundation

/// App configuration baked in at build time. Customers never see or set this —
/// the server address is our concern, not theirs (like every real app).
enum AppConfig {
    /// The production API base URL. Point this at your real domain once the ALB
    /// has HTTPS + a custom domain (e.g. https://api.deeparchive.com).
    /// For now it targets the live ALB over HTTP.
    static let defaultEndpoint =
        "http://DeepAr-Alb16-5Y2jiGGVXJ3a-252734301.us-east-1.elb.amazonaws.com"

    /// Whether to expose the hidden developer endpoint override (debug only).
    #if DEBUG
    static let allowEndpointOverride = true
    #else
    static let allowEndpointOverride = false
    #endif
}
