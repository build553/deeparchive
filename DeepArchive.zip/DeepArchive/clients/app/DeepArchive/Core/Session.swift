import Combine
import Foundation
import SwiftUI

/// App-wide session: holds the endpoint + API key, exposes a configured client,
/// and drives whether the UI shows sign-in or the main app.
@MainActor
final class Session: ObservableObject {
    @Published var endpoint: String
    @Published var apiKey: String?
    @Published var accountId: String?

    init() {
        // Endpoint is baked in (customers never set it). A stored override
        // (dev only) wins if present.
        let stored = CredentialStore.endpoint
        self.endpoint = stored.isEmpty ? AppConfig.defaultEndpoint : stored
        self.apiKey = CredentialStore.loadAPIKey()
    }

    var isSignedIn: Bool { apiKey?.isEmpty == false && !endpoint.isEmpty }

    /// A client configured with the current endpoint + key (nil if endpoint bad).
    func client(authed: Bool = true) -> APIClient? {
        try? APIClient(endpoint: endpoint, apiKey: authed ? apiKey : nil)
    }

    func setEndpoint(_ e: String) {
        let trimmed = e.trimmingCharacters(in: .whitespaces)
        endpoint = trimmed
        CredentialStore.endpoint = trimmed
    }

    func signIn(apiKey: String, accountId: String) {
        self.apiKey = apiKey
        self.accountId = accountId
        CredentialStore.saveAPIKey(apiKey)
    }

    func signOut() {
        apiKey = nil
        accountId = nil
        CredentialStore.clear()
    }
}
