# DeepArchive

Ultra-low-cost 30-year archival storage on AWS S3 Glacier Deep Archive.
Pack many files into ~256 MB tarballs (cold), keep a warm JSON index, retrieve
within a 48h SLA. Priced far below consumer cloud.

## Folder layout

```
DeepArchive/
├── backend/          The service — Python. The archival engine + 6 API
│                     microservices + AWS deployment (CDK). This is what runs
│                     live on EC2.
│
└── clients/          Apps that talk to the backend's API:
    ├── web/          Web app  — single-page browser UI (HTML/JS, no build)
    ├── cli/          CLI      — terminal client (Swift)
    └── app/          Mobile/desktop app — iOS + macOS (SwiftUI)
```

## What each client is

| Client | What it is | How to run |
|--------|-----------|-----------|
| **web** | Browser UI: sign in, browse archive, restore, buy a plan | `open clients/web/index.html` |
| **cli** | Terminal tool: `deeparchive catalog`, `restore`, etc. | `cd clients/cli && swift build` |
| **app** | Native iOS/macOS GUI | open `clients/app` in Xcode, Run |

All three point at the backend's live API endpoint (baked into each client's config).

## Where the actual model/engine code is

`backend/deeparchive/` — see `backend/STRUCTURE.md` for the full map of the
engine (packing, storage, restore, crypto) and the microservices.
